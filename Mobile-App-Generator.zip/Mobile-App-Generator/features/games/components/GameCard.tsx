// src/features/games/components/GameCard.tsx

import { Feather } from "@expo/vector-icons";
import { LinearGradient } from "expo-linear-gradient";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { GameConfig } from "../types";

interface GameCardProps {
  game: GameConfig;
  onPress: (game: GameConfig) => void;
  lang: "fr" | "en";
  highScore?: number;
  disabled?: boolean;
}

export function GameCard({ game, onPress, lang, highScore, disabled }: GameCardProps) {
  const [color1, color2] = game.iconGradient;

  return (
    <Pressable
      style={[styles.card, { opacity: disabled ? 0.5 : 1 }]}
      onPress={() => onPress(game)}
      disabled={disabled}
    >
      <LinearGradient colors={[color1, color2]} style={styles.iconContainer}>
        <Feather name={game.icon as any} size={28} color="#fff" />
      </LinearGradient>

      <View style={styles.info}>
        <Text style={styles.title}>
          {lang === "fr" ? game.title : game.titleEn}
        </Text>
        <Text style={styles.description} numberOfLines={2}>
          {lang === "fr" ? game.description : game.descriptionEn}
        </Text>

        <View style={styles.meta}>
          <View style={styles.categoryBadge}>
            <Text style={styles.categoryText}>
              {game.category === "vocabulary" && (lang === "fr" ? "Vocabulaire" : "Vocabulary")}
              {game.category === "grammar" && (lang === "fr" ? "Grammaire" : "Grammar")}
              {game.category === "pronunciation" && (lang === "fr" ? "Prononciation" : "Pronunciation")}
              {game.category === "culture" && (lang === "fr" ? "Culture" : "Culture")}
              {game.category === "mixed" && (lang === "fr" ? "Mixte" : "Mixed")}
            </Text>
          </View>

          {highScore !== undefined && highScore > 0 && (
            <View style={styles.scoreBadge}>
              <Feather name="star" size={10} color="#f59e0b" />
              <Text style={styles.scoreText}>{highScore}</Text>
            </View>
          )}
        </View>
      </View>

      <Feather name="chevron-right" size={18} color="#9ca3af" />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    borderRadius: 16,
    padding: 16,
    gap: 14,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 8,
    elevation: 2,
  },
  iconContainer: {
    width: 56,
    height: 56,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  info: {
    flex: 1,
    gap: 4,
  },
  title: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1f2937",
  },
  description: {
    fontSize: 12,
    color: "#6b7280",
    lineHeight: 16,
  },
  meta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginTop: 4,
  },
  categoryBadge: {
    backgroundColor: "#f3f4f6",
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 6,
  },
  categoryText: {
    fontSize: 10,
    fontWeight: "600",
    color: "#6b7280",
    textTransform: "uppercase",
  },
  scoreBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 2,
    backgroundColor: "#fef3c7",
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  scoreText: {
    fontSize: 10,
    fontWeight: "700",
    color: "#92400e",
  },
});