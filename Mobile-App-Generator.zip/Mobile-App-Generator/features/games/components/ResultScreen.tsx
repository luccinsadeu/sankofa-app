// src/features/games/components/ResultScreen.tsx

import { Feather } from "@expo/vector-icons";
import React from "react";
import { Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

interface ResultScreenProps {
  score: number;
  maxScore: number;
  accuracy?: number;
  timeSpent?: number;
  onReplay: () => void;
  onMenu: () => void;
  lang: "fr" | "en";
}

export function ResultScreen({ score, maxScore, accuracy, timeSpent, onReplay, onMenu, lang }: ResultScreenProps) {
  const percentage = Math.round((score / maxScore) * 100);

  const getEmoji = () => {
    if (percentage >= 90) return "🏆";
    if (percentage >= 70) return "⭐";
    if (percentage >= 50) return "👍";
    return "💪";
  };

  const getMessage = () => {
    if (percentage >= 90) return lang === "fr" ? "Excellent !" : "Excellent!";
    if (percentage >= 70) return lang === "fr" ? "Très bien !" : "Very good!";
    if (percentage >= 50) return lang === "fr" ? "Bien joué !" : "Well done!";
    return lang === "fr" ? "Continue d'apprendre !" : "Keep learning!";
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.emoji}>{getEmoji()}</Text>
      <Text style={styles.message}>{getMessage()}</Text>

      <LinearGradient
        colors={percentage >= 70 ? ["#10b981", "#059669"] : ["#f59e0b", "#d97706"]}
        style={styles.scoreCircle}
      >
        <Text style={styles.scoreValue}>{score}</Text>
        <Text style={styles.scoreMax}>/ {maxScore}</Text>
      </LinearGradient>

      {accuracy !== undefined && (
        <View style={styles.statRow}>
          <Feather name="target" size={16} color="#6b7280" />
          <Text style={styles.statText}>
            {lang === "fr" ? "Précision" : "Accuracy"}: {accuracy}%
          </Text>
        </View>
      )}

      {timeSpent !== undefined && (
        <View style={styles.statRow}>
          <Feather name="clock" size={16} color="#6b7280" />
          <Text style={styles.statText}>
            {lang === "fr" ? "Temps" : "Time"}: {timeSpent}s
          </Text>
        </View>
      )}

      <View style={styles.buttonRow}>
        <Pressable style={[styles.btn, { backgroundColor: "#10b981" }]} onPress={onReplay}>
          <Feather name="refresh-cw" size={16} color="#fff" />
          <Text style={styles.btnText}>{lang === "fr" ? "Rejouer" : "Replay"}</Text>
        </Pressable>
        <Pressable style={[styles.btn, { backgroundColor: "#6b7280" }]} onPress={onMenu}>
          <Feather name="home" size={16} color="#fff" />
          <Text style={styles.btnText}>{lang === "fr" ? "Menu" : "Menu"}</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: "center",
    padding: 20,
    gap: 16,
  },
  emoji: { fontSize: 64 },
  message: {
    fontSize: 24,
    fontWeight: "700",
    color: "#1f2937",
  },
  scoreCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
  },
  scoreValue: {
    color: "#fff",
    fontSize: 36,
    fontWeight: "800",
  },
  scoreMax: {
    color: "rgba(255,255,255,0.7)",
    fontSize: 18,
  },
  statRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  statText: {
    fontSize: 14,
    color: "#6b7280",
  },
  buttonRow: {
    flexDirection: "row",
    gap: 12,
    marginTop: 8,
  },
  btn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
  },
  btnText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 14,
  },
});