// src/features/games/components/GameHeader.tsx

import { Feather } from "@expo/vector-icons";
import React from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

interface GameHeaderProps {
  title: string;
  score: number;
  onExit: () => void;
  colors: any;
  lives?: number;
  maxLives?: number;
}

export function GameHeader({ title, score, onExit, colors, lives, maxLives }: GameHeaderProps) {
  return (
    <View style={styles.container}>
      <Pressable onPress={onExit} style={[styles.exitBtn, { backgroundColor: colors.muted }]}>
        <Feather name="x" size={18} color={colors.foreground} />
      </Pressable>

      <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>

      <View style={styles.right}>
        {lives !== undefined && maxLives !== undefined && (
          <View style={styles.lives}>
            {Array.from({ length: maxLives }).map((_, i) => (
              <Feather
                key={i}
                name={i < lives ? "heart" : "heart"}
                size={14}
                color={i < lives ? "#ef4444" : colors.muted}
              />
            ))}
          </View>
        )}
        <View style={[styles.scoreBadge, { backgroundColor: "#f59e0b" }]}>
          <Text style={styles.scoreText}>{score}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  exitBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  title: {
    fontSize: 16,
    fontWeight: "700",
  },
  right: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  lives: {
    flexDirection: "row",
    gap: 3,
  },
  scoreBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  scoreText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 13,
  },
});