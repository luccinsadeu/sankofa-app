// features/games/gameData.ts

// ============================================
// VOCABULAIRE ÉTENDU (30+ mots par langue)
// ============================================

export const VOCABULARY: Record<string, {
  word: string;
  translation: string;
  pronunciation?: string;
  example?: string;
  exampleTranslation?: string;
}[]> = {
  sw: [
    // Salutations et formules de politesse (8)
    { word: "habari", translation: "bonjour", pronunciation: "ha-ba-ri", example: "Habari gani?", exampleTranslation: "Comment allez-vous ?" },
    { word: "asante", translation: "merci", pronunciation: "a-san-te", example: "Asante sana!", exampleTranslation: "Merci beaucoup !" },
    { word: "shikamoo", translation: "bonjour (respectueux)", pronunciation: "shi-ka-moo", example: "Shikamoo, mzee.", exampleTranslation: "Bonjour, monsieur." },
    { word: "marahaba", translation: "réponse à shikamoo", pronunciation: "ma-ra-ha-ba", example: "Marahaba, binti.", exampleTranslation: "Bonjour, mademoiselle." },
    { word: "tafadhali", translation: "s'il vous plaît", pronunciation: "ta-fa-dha-li", example: "Maji, tafadhali.", exampleTranslation: "De l'eau, s'il vous plaît." },
    { word: "karibu", translation: "bienvenue", pronunciation: "ka-ri-bu", example: "Karibu Tanzania!", exampleTranslation: "Bienvenue en Tanzanie !" },
    { word: "kwaheri", translation: "au revoir", pronunciation: "kwa-he-ri", example: "Kwaheri, tutaonana.", exampleTranslation: "Au revoir, nous nous reverrons." },
    { word: "pole", translation: "désolé", pronunciation: "po-le", example: "Pole kwa kukusumbua.", exampleTranslation: "Désolé de vous déranger." },

    // Nourriture et boissons (6)
    { word: "chakula", translation: "nourriture", pronunciation: "cha-ku-la", example: "Chakula kiko tayari.", exampleTranslation: "La nourriture est prête." },
    { word: "maji", translation: "eau", pronunciation: "ma-ji", example: "Nataka maji baridi.", exampleTranslation: "Je veux de l'eau froide." },
    { word: "chai", translation: "thé", pronunciation: "cha-i", example: "Chai ya asubuhi.", exampleTranslation: "Le thé du matin." },
    { word: "kahawa", translation: "café", pronunciation: "ka-ha-wa", example: "Kahawa nyeusi.", exampleTranslation: "Café noir." },
    { word: "nyama", translation: "viande", pronunciation: "nya-ma", example: "Nyama ya kuchoma.", exampleTranslation: "Viande grillée." },
    { word: "samaki", translation: "poisson", pronunciation: "sa-ma-ki", example: "Samaki safi.", exampleTranslation: "Poisson frais." },

    // Personnes et famille (6)
    { word: "rafiki", translation: "ami", pronunciation: "ra-fi-ki", example: "Rafiki yangu.", exampleTranslation: "Mon ami." },
    { word: "mama", translation: "mère/maman", pronunciation: "ma-ma", example: "Mama anakuja.", exampleTranslation: "Maman arrive." },
    { word: "baba", translation: "père/papa", pronunciation: "ba-ba", example: "Baba yangu ni daktari.", exampleTranslation: "Mon père est médecin." },
    { word: "mtoto", translation: "enfant", pronunciation: "m-to-to", example: "Mtoto analala.", exampleTranslation: "L'enfant dort." },
    { word: "mwalimu", translation: "professeur", pronunciation: "mwa-li-mu", example: "Mwalimu wetu.", exampleTranslation: "Notre professeur." },
    { word: "daktari", translation: "médecin", pronunciation: "dak-ta-ri", example: "Nataka kuona daktari.", exampleTranslation: "Je veux voir un médecin." },

    // Animaux (4)
    { word: "paka", translation: "chat", pronunciation: "pa-ka", example: "Paka mweusi.", exampleTranslation: "Chat noir." },
    { word: "mbwa", translation: "chien", pronunciation: "m-bwa", example: "Mbwa mkubwa.", exampleTranslation: "Gros chien." },
    { word: "simba", translation: "lion", pronunciation: "sim-ba", example: "Simba ni mfalme.", exampleTranslation: "Le lion est le roi." },
    { word: "ndege", translation: "oiseau", pronunciation: "n-de-ge", example: "Ndege anaruka.", exampleTranslation: "L'oiseau vole." },

    // Lieux (4)
    { word: "shule", translation: "école", pronunciation: "shu-le", example: "Nakwenda shule.", exampleTranslation: "Je vais à l'école." },
    { word: "nyumba", translation: "maison", pronunciation: "nyu-mba", example: "Nyumba yangu.", exampleTranslation: "Ma maison." },
    { word: "kanisa", translation: "église", pronunciation: "ka-ni-sa", example: "Kanisa kubwa.", exampleTranslation: "Grande église." },
    { word: "soko", translation: "marché", pronunciation: "so-ko", example: "Nakwenda sokoni.", exampleTranslation: "Je vais au marché." },

    // Nature et météo (4)
    { word: "jua", translation: "soleil", pronunciation: "ju-a", example: "Jua kali.", exampleTranslation: "Soleil brûlant." },
    { word: "mvua", translation: "pluie", pronunciation: "m-vu-a", example: "Mvua inanyesha.", exampleTranslation: "Il pleut." },
    { word: "upepo", translation: "vent", pronunciation: "u-pe-po", example: "Upepo mkali.", exampleTranslation: "Vent fort." },
    { word: "bahari", translation: "mer/océan", pronunciation: "ba-ha-ri", example: "Bahari ya Hindi.", exampleTranslation: "L'océan Indien." },
  ],

  ln: [
    // Salutations (8)
    { word: "mbote", translation: "bonjour", example: "Mbote, ozali malamu?", exampleTranslation: "Bonjour, comment allez-vous ?" },
    { word: "malamu", translation: "bien/bon", example: "Nazali malamu.", exampleTranslation: "Je vais bien." },
    { word: "botondi", translation: "merci", example: "Botondi mingi!", exampleTranslation: "Merci beaucoup !" },
    { word: "merci mingi", translation: "merci beaucoup", example: "Merci mingi, mama.", exampleTranslation: "Merci beaucoup, madame." },
    { word: "svp", translation: "s'il vous plaît", example: "Mai, svp.", exampleTranslation: "De l'eau, s'il vous plaît." },
    { word: "boyei bolamu", translation: "bienvenue", example: "Boyei bolamu na Kinshasa!", exampleTranslation: "Bienvenue à Kinshasa !" },
    { word: "tikala malamu", translation: "au revoir", example: "Tikala malamu, moninga.", exampleTranslation: "Au revoir, mon ami." },
    { word: "limbisa ngai", translation: "désolé/excusez-moi", example: "Limbisa ngai, nazui liboso.", exampleTranslation: "Excusez-moi, je suis en retard." },

    // Nourriture (6)
    { word: "bilei", translation: "nourriture", example: "Bilei bizali tayari.", exampleTranslation: "La nourriture est prête." },
    { word: "mai", translation: "eau", example: "Pesa ngai mai.", exampleTranslation: "Donne-moi de l'eau." },
    { word: "losango", translation: "riz", example: "Nalingi kolya losango.", exampleTranslation: "Je veux manger du riz." },
    { word: "nyama", translation: "viande", example: "Nyama ya ngombe.", exampleTranslation: "Viande de bœuf." },
    { word: "mbisi", translation: "poisson", example: "Mbisi ya mai.", exampleTranslation: "Poisson d'eau." },
    { word: "makemba", translation: "bananes", example: "Makemba matamasi.", exampleTranslation: "Bananes sucrées." },

    // Personnes (6)
    { word: "moninga", translation: "ami", example: "Moninga na ngai.", exampleTranslation: "Mon ami." },
    { word: "mama", translation: "mère", example: "Mama na ngai azali malamu.", exampleTranslation: "Ma mère va bien." },
    { word: "tata", translation: "père", example: "Tata akomi.", exampleTranslation: "Papa est arrivé." },
    { word: "mwana", translation: "enfant", example: "Mwana moke.", exampleTranslation: "Petit enfant." },
    { word: "mobali", translation: "homme", example: "Mobali monene.", exampleTranslation: "Grand homme." },
    { word: "mwasi", translation: "femme", example: "Mwasi kitoko.", exampleTranslation: "Belle femme." },

    // Animaux (4)
    { word: "pussi", translation: "chat", example: "Pussi ya ndako.", exampleTranslation: "Chat domestique." },
    { word: "mbwa", translation: "chien", example: "Mbwa azali konganga.", exampleTranslation: "Le chien aboie." },
    { word: "nkosi", translation: "lion", example: "Nkosi ezali na nguya.", exampleTranslation: "Le lion est puissant." },
    { word: "ndeke", translation: "oiseau", example: "Ndeke ezali kopumbwa.", exampleTranslation: "L'oiseau vole." },

    // Lieux (4)
    { word: "ndako", translation: "maison", example: "Ndako na ngai.", exampleTranslation: "Ma maison." },
    { word: "ekolo", translation: "pays", example: "Ekolo Congo.", exampleTranslation: "Le pays Congo." },
    { word: "zando", translation: "marché", example: "Nakei zando.", exampleTranslation: "Je vais au marché." },
    { word: "lopitalo", translation: "hôpital", example: "Nakei lopitalo.", exampleTranslation: "Je vais à l'hôpital." },

    // Nature (4)
    { word: "moyi", translation: "soleil", example: "Moyi mokasi.", exampleTranslation: "Soleil fort." },
    { word: "mbula", translation: "pluie", example: "Mbula ezali kobeta.", exampleTranslation: "La pluie tombe." },
    { word: "mopepe", translation: "vent", example: "Mopepe makasi.", exampleTranslation: "Vent fort." },
    { word: "ebale", translation: "fleuve/rivière", example: "Ebale Congo.", exampleTranslation: "Le fleuve Congo." },
  ],

  yo: [
    // Salutations (8)
    { word: "ẹ káàárọ̀", translation: "bonjour (matin)" },
    { word: "ẹ káàsán", translation: "bonjour (après-midi)" },
    { word: "ẹ kúùrọ̀lẹ́", translation: "bonsoir" },
    { word: "o ṣe", translation: "merci" },
    { word: "o ṣeun", translation: "merci (reconnaissance)" },
    { word: "ẹ jọ̀ọ́", translation: "s'il vous plaît" },
    { word: "kò tọ́pẹ", translation: "de rien" },
    { word: "ó dàbò", translation: "au revoir" },

    // Nourriture (6)
    { word: "omi", translation: "eau" },
    { word: "oúnjẹ", translation: "nourriture" },
    { word: "ìrẹsì", translation: "riz" },
    { word: "ẹran", translation: "viande" },
    { word: "ẹja", translation: "poisson" },
    { word: "ọ̀gẹ̀dẹ̀", translation: "banane" },

    // Personnes (6)
    { word: "ọ̀rẹ́", translation: "ami" },
    { word: "ìyá", translation: "mère" },
    { word: "bàbá", translation: "père" },
    { word: "ọmọ", translation: "enfant" },
    { word: "ọkùnrin", translation: "homme" },
    { word: "obìnrin", translation: "femme" },

    // Animaux (4)
    { word: "ológbò", translation: "chat" },
    { word: "ajá", translation: "chien" },
    { word: "kìnnìún", translation: "lion" },
    { word: "ẹyẹ", translation: "oiseau" },

    // Lieux (4)
    { word: "ilé", translation: "maison" },
    { word: "ilé-ìwé", translation: "école" },
    { word: "ọjà", translation: "marché" },
    { word: "ilé-ìwòsàn", translation: "hôpital" },

    // Nature (4)
    { word: "oòrùn", translation: "soleil" },
    { word: "òjò", translation: "pluie" },
    { word: "afẹ́fẹ́", translation: "vent" },
    { word: "òkun", translation: "mer/océan" },
  ],

  ha: [
    // Salutations (8)
    { word: "sannu", translation: "bonjour" },
    { word: "ina kwana", translation: "bonjour (matin)" },
    { word: "barka da yamma", translation: "bonsoir" },
    { word: "na gode", translation: "merci" },
    { word: "don Allah", translation: "s'il vous plaît" },
    { word: "maraba", translation: "bienvenue" },
    { word: "sai an jima", translation: "au revoir" },
    { word: "yi hakuri", translation: "désolé" },

    // Nourriture (6)
    { word: "ruwa", translation: "eau" },
    { word: "abinci", translation: "nourriture" },
    { word: "shinkafa", translation: "riz" },
    { word: "nama", translation: "viande" },
    { word: "kifi", translation: "poisson" },
    { word: "ayaba", translation: "banane" },

    // Personnes (6)
    { word: "aboki", translation: "ami" },
    { word: "uwa", translation: "mère" },
    { word: "uba", translation: "père" },
    { word: "yaro", translation: "enfant" },
    { word: "mutum", translation: "homme" },
    { word: "mace", translation: "femme" },

    // Animaux (4)
    { word: "kare", translation: "chien" },
    { word: "mata", translation: "chat" },
    { word: "zaki", translation: "lion" },
    { word: "tsuntsu", translation: "oiseau" },

    // Lieux (4)
    { word: "gida", translation: "maison" },
    { word: "makaranta", translation: "école" },
    { word: "kasuwa", translation: "marché" },
    { word: "asibiti", translation: "hôpital" },

    // Nature (4)
    { word: "rana", translation: "soleil/jour" },
    { word: "ruwan sama", translation: "pluie" },
    { word: "iska", translation: "vent" },
    { word: "teku", translation: "mer/océan" },
  ],

  zu: [
    // Salutations (8)
    { word: "sawubona", translation: "bonjour" },
    { word: "sanibonani", translation: "bonjour (pluriel)" },
    { word: "ngiyabonga", translation: "merci" },
    { word: "ngiyacela", translation: "s'il vous plaît" },
    { word: "wamukelekile", translation: "bienvenue" },
    { word: "hamba kahle", translation: "au revoir" },
    { word: "uxolo", translation: "désolé" },
    { word: "yebo", translation: "oui" },

    // Nourriture (6)
    { word: "amanzi", translation: "eau" },
    { word: "ukudla", translation: "nourriture" },
    { word: "ilayisi", translation: "riz" },
    { word: "inyama", translation: "viande" },
    { word: "inhlanzi", translation: "poisson" },
    { word: "ubhanana", translation: "banane" },

    // Personnes (6)
    { word: "umngane", translation: "ami" },
    { word: "umama", translation: "mère" },
    { word: "ubaba", translation: "père" },
    { word: "ingane", translation: "enfant" },
    { word: "indoda", translation: "homme" },
    { word: "umfazi", translation: "femme" },

    // Animaux (4)
    { word: "ikati", translation: "chat" },
    { word: "inja", translation: "chien" },
    { word: "ibhubesi", translation: "lion" },
    { word: "inyoni", translation: "oiseau" },

    // Lieux (4)
    { word: "indlu", translation: "maison" },
    { word: "isikole", translation: "école" },
    { word: "imakethe", translation: "marché" },
    { word: "isibhedlela", translation: "hôpital" },

    // Nature (4)
    { word: "ilanga", translation: "soleil" },
    { word: "imvula", translation: "pluie" },
    { word: "umoya", translation: "vent" },
    { word: "ulwandle", translation: "mer/océan" },
  ],

  fr: [
    { word: "bonjour", translation: "hello" },
    { word: "bonsoir", translation: "good evening" },
    { word: "merci", translation: "thank you" },
    { word: "merci beaucoup", translation: "thank you very much" },
    { word: "s'il vous plaît", translation: "please" },
    { word: "de rien", translation: "you're welcome" },
    { word: "au revoir", translation: "goodbye" },
    { word: "désolé", translation: "sorry" },
    { word: "eau", translation: "water" },
    { word: "nourriture", translation: "food" },
    { word: "riz", translation: "rice" },
    { word: "viande", translation: "meat" },
    { word: "poisson", translation: "fish" },
    { word: "banane", translation: "banana" },
    { word: "ami", translation: "friend" },
    { word: "mère", translation: "mother" },
    { word: "père", translation: "father" },
    { word: "enfant", translation: "child" },
    { word: "homme", translation: "man" },
    { word: "femme", translation: "woman" },
    { word: "chat", translation: "cat" },
    { word: "chien", translation: "dog" },
    { word: "lion", translation: "lion" },
    { word: "oiseau", translation: "bird" },
    { word: "maison", translation: "house" },
    { word: "école", translation: "school" },
    { word: "marché", translation: "market" },
    { word: "hôpital", translation: "hospital" },
    { word: "soleil", translation: "sun" },
    { word: "pluie", translation: "rain" },
    { word: "vent", translation: "wind" },
    { word: "mer", translation: "sea" },
  ],

  en: [
    { word: "hello", translation: "bonjour" },
    { word: "good evening", translation: "bonsoir" },
    { word: "thank you", translation: "merci" },
    { word: "thank you very much", translation: "merci beaucoup" },
    { word: "please", translation: "s'il vous plaît" },
    { word: "you're welcome", translation: "de rien" },
    { word: "goodbye", translation: "au revoir" },
    { word: "sorry", translation: "désolé" },
    { word: "water", translation: "eau" },
    { word: "food", translation: "nourriture" },
    { word: "rice", translation: "riz" },
    { word: "meat", translation: "viande" },
    { word: "fish", translation: "poisson" },
    { word: "banana", translation: "banane" },
    { word: "friend", translation: "ami" },
    { word: "mother", translation: "mère" },
    { word: "father", translation: "père" },
    { word: "child", translation: "enfant" },
    { word: "man", translation: "homme" },
    { word: "woman", translation: "femme" },
    { word: "cat", translation: "chat" },
    { word: "dog", translation: "chien" },
    { word: "lion", translation: "lion" },
    { word: "bird", translation: "oiseau" },
    { word: "house", translation: "maison" },
    { word: "school", translation: "école" },
    { word: "market", translation: "marché" },
    { word: "hospital", translation: "hôpital" },
    { word: "sun", translation: "soleil" },
    { word: "rain", translation: "pluie" },
    { word: "wind", translation: "vent" },
    { word: "sea", translation: "mer" },
  ],
};

// ============================================
// QUESTIONS CULTURELLES (10+ par langue)
// ============================================

export const CULTURE_QUESTIONS: Record<string, {
  question: string;
  questionEn: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
  explanationEn?: string;
}[]> = {
  sw: [
    { question: "Dans quel pays le swahili est-il langue officielle ?", questionEn: "In which country is Swahili an official language?", options: ["Tanzanie", "Nigeria", "Ghana", "Sénégal"], correctIndex: 0, explanation: "Le swahili est langue officielle en Tanzanie, au Kenya, en Ouganda et en RDC.", explanationEn: "Swahili is official in Tanzania, Kenya, Uganda, and DRC." },
    { question: "Que signifie 'Hakuna Matata' ?", questionEn: "What does 'Hakuna Matata' mean?", options: ["Pas de problème", "Au revoir", "Bon appétit", "Bonne nuit"], correctIndex: 0 },
    { question: "Quel océan borde la Tanzanie ?", questionEn: "Which ocean borders Tanzania?", options: ["Indien", "Atlantique", "Pacifique", "Arctique"], correctIndex: 0 },
    { question: "Quel est le plus haut sommet d'Afrique ?", questionEn: "What is Africa's highest peak?", options: ["Kilimandjaro", "Mont Kenya", "Rwenzori", "Elgon"], correctIndex: 0 },
    { question: "Combien de pays ont le swahili comme langue officielle ?", questionEn: "How many countries have Swahili as an official language?", options: ["5", "2", "10", "1"], correctIndex: 0, explanation: "Tanzanie, Kenya, Ouganda, RDC, Rwanda (en tant que langue nationale).", explanationEn: "Tanzania, Kenya, Uganda, DRC, Rwanda (as national language)." },
    { question: "Quel est le plat traditionnel tanzanien ?", questionEn: "What is the traditional Tanzanian dish?", options: ["Ugali", "Sushi", "Pizza", "Tacos"], correctIndex: 0 },
    { question: "Quelle est la capitale de la Tanzanie ?", questionEn: "What is the capital of Tanzania?", options: ["Dodoma", "Dar es Salaam", "Nairobi", "Kampala"], correctIndex: 0 },
    { question: "Que signifie le mot 'Swahili' ?", questionEn: "What does the word 'Swahili' mean?", options: ["Côte", "Montagne", "Lac", "Rivière"], correctIndex: 0, explanation: "Swahili vient de l'arabe 'sawahil' qui signifie 'côte'.", explanationEn: "Swahili comes from Arabic 'sawahil' meaning 'coast'." },
    { question: "Quel est le plus grand lac d'Afrique ?", questionEn: "What is Africa's largest lake?", options: ["Victoria", "Tanganyika", "Malawi", "Turkana"], correctIndex: 0 },
    { question: "Quel instrument de musique swahili traditionnel ?", questionEn: "Which is a traditional Swahili musical instrument?", options: ["Zeze", "Guitare", "Piano", "Violon"], correctIndex: 0 },
  ],
  ln: [
    { question: "Dans quel pays le lingala est-il principalement parlé ?", questionEn: "In which country is Lingala primarily spoken?", options: ["RDC", "Cameroun", "Sénégal", "Côte d'Ivoire"], correctIndex: 0 },
    { question: "Quel fleuve traverse Kinshasa ?", questionEn: "Which river flows through Kinshasa?", options: ["Congo", "Nil", "Niger", "Zambèze"], correctIndex: 0 },
    { question: "Que signifie 'Mbote' en lingala ?", questionEn: "What does 'Mbote' mean in Lingala?", options: ["Bonjour", "Merci", "Au revoir", "Eau"], correctIndex: 0 },
    { question: "Quelle est la capitale de la RDC ?", questionEn: "What is the capital of DRC?", options: ["Kinshasa", "Brazzaville", "Lagos", "Nairobi"], correctIndex: 0 },
    { question: "Le lingala appartient à quelle famille de langues ?", questionEn: "Lingala belongs to which language family?", options: ["Bantoue", "Romane", "Germanique", "Slave"], correctIndex: 0 },
    { question: "Quel est le plat traditionnel congolais ?", questionEn: "What is the traditional Congolese dish?", options: ["Pondu", "Sushi", "Pizza", "Tacos"], correctIndex: 0 },
    { question: "Qui est considéré comme le père de la musique congolaise ?", questionEn: "Who is considered the father of Congolese music?", options: ["Franco Luambo", "Fela Kuti", "Bob Marley", "Meek Mill"], correctIndex: 0 },
    { question: "Quelle est l'espérance de vie moyenne en RDC ?", questionEn: "What is the average life expectancy in DRC?", options: ["48 ans", "60 ans", "75 ans", "30 ans"], correctIndex: 1 },
    { question: "Quel est le principal minerai exporté par la RDC ?", questionEn: "What is the main mineral exported by DRC?", options: ["Cobalt", "Or", "Diamant", "Pétrole"], correctIndex: 0 },
    { question: "Que signifie 'Bolingo' en lingala ?", questionEn: "What does 'Bolingo' mean in Lingala?", options: ["Amour", "Haine", "Joie", "Tristesse"], correctIndex: 0 },
  ],
};

// ============================================
// PHRASES À RECONSTRUIRE (8+ par langue)
// ============================================

export const PHRASES: Record<string, {
  words: string[];
  correctOrder: number[];
  translation: string;
  hint?: string;
}[]> = {
  sw: [
    { words: ["Nakupenda", "sana"], correctOrder: [0, 1], translation: "Je t'aime beaucoup" },
    { words: ["Nataka", "maji", "tafadhali"], correctOrder: [0, 1, 2], translation: "Je veux de l'eau s'il vous plaît" },
    { words: ["Asante", "sana"], correctOrder: [0, 1], translation: "Merci beaucoup" },
    { words: ["Habari", "gani"], correctOrder: [0, 1], translation: "Comment allez-vous ?" },
    { words: ["Nazali", "mzuri"], correctOrder: [0, 1], translation: "Je vais bien" },
    { words: ["Mimi", "ni", "daktari"], correctOrder: [0, 1, 2], translation: "Je suis médecin" },
    { words: ["Nyumba", "yangu", "ni", "kubwa"], correctOrder: [0, 1, 2, 3], translation: "Ma maison est grande" },
    { words: ["Tafadhali", "njoo"], correctOrder: [0, 1], translation: "S'il te plaît, viens" },
  ],
  ln: [
    { words: ["Nalingi", "yo"], correctOrder: [0, 1], translation: "Je t'aime" },
    { words: ["Pesa", "ngai", "mai"], correctOrder: [0, 1, 2], translation: "Donne-moi de l'eau" },
    { words: ["Nazali", "malamu"], correctOrder: [0, 1], translation: "Je vais bien" },
    { words: ["Mbote", "mingi"], correctOrder: [0, 1], translation: "Bonjour beaucoup" },
    { words: ["Nakei", "zando"], correctOrder: [0, 1], translation: "Je vais au marché" },
    { words: ["Nalingi", "kolya", "losango"], correctOrder: [0, 1, 2], translation: "Je veux manger du riz" },
    { words: ["Ndako", "na", "ngai", "ezali", "monene"], correctOrder: [0, 1, 2, 3, 4], translation: "Ma maison est grande" },
    { words: ["Sv", "pesa", "ngai", "mbongo"], correctOrder: [0, 1, 2, 3], translation: "S'il vous plaît, donnez-moi de l'argent" },
  ],
};