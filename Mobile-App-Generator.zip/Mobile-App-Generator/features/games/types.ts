// src/features/games/types.ts

export type GameType = 
  | "quiz" 
  | "flashcards" 
  | "matching" 
  | "spelling" 
  | "listening" 
  | "speedrace"
  | "fillblank"
  | "scramble"
  | "culturequiz"
  | "wordhunt"
  | "phrasebuilder";

export type DifficultyLevel = "easy" | "medium" | "hard";

export interface GameConfig {
  id: string;
  type: GameType;
  title: string;
  titleEn: string;
  description: string;
  descriptionEn: string;
  icon: string;
  iconGradient: [string, string];
  category: "vocabulary" | "grammar" | "pronunciation" | "culture" | "speed";
}

export interface GameResult {
  score: number;
  maxScore: number;
  accuracy?: number;
  timeSpent?: number;
  language: string;
  gameType: GameType;
}

export interface VocabularyItem {
  id: string;
  word: string;
  translation: string;
  pronunciation?: string;
  example?: string;
  exampleTranslation?: string;
  category: string;
  difficulty: DifficultyLevel;
}

export interface CultureQuestion {
  id: string;
  question: string;
  questionEn: string;
  options: string[];
  correctIndex: number;
  explanation?: string;
  explanationEn?: string;
  language: string;
}

export interface PhraseItem {
  id: string;
  words: string[];
  correctOrder: number[];
  translation: string;
  hint?: string;
}