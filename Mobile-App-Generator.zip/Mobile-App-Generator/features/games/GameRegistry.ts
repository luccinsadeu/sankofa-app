// src/features/games/GameRegistry.ts

import { GameConfig } from "./types";

/**
 * Registre central de tous les jeux disponibles.
 * Pour ajouter un nouveau jeu, il suffit de l'ajouter ici !
 */
export const GAME_REGISTRY: GameConfig[] = [
  {
    id: "quiz",
    type: "quiz",
    title: "Quiz",
    titleEn: "Quiz",
    description: "Testez vos connaissances avec des questions à choix multiples",
    descriptionEn: "Test your knowledge with multiple choice questions",
    icon: "award",
    iconGradient: ["#f59e0b", "#d97706"],
    minPlayers: 1,
    category: "vocabulary",
  },
  {
    id: "flashcards",
    type: "flashcards",
    title: "Flashcards",
    titleEn: "Flashcards",
    description: "Apprenez du vocabulaire avec des cartes mémoire",
    descriptionEn: "Learn vocabulary with memory cards",
    icon: "layers",
    iconGradient: ["#3b82f6", "#2563eb"],
    minPlayers: 1,
    category: "vocabulary",
  },
  {
    id: "spelling",
    type: "spelling",
    title: "Orthographe",
    titleEn: "Spelling Bee",
    description: "Épelez correctement les mots dans la langue cible",
    descriptionEn: "Spell words correctly in the target language",
    icon: "edit-3",
    iconGradient: ["#10b981", "#059669"],
    minPlayers: 1,
    category: "vocabulary",
  },
  {
    id: "matching",
    type: "matching",
    title: "Paires",
    titleEn: "Matching",
    description: "Associez les mots à leurs traductions",
    descriptionEn: "Match words with their translations",
    icon: "grid",
    iconGradient: ["#8b5cf6", "#7c3aed"],
    minPlayers: 1,
    category: "vocabulary",
  },
  {
    id: "fillblank",
    type: "fillblank",
    title: "Texte à trous",
    titleEn: "Fill in the Blank",
    description: "Complétez les phrases avec le bon mot",
    descriptionEn: "Complete sentences with the correct word",
    icon: "file-text",
    iconGradient: ["#f59e0b", "#d97706"],
    minPlayers: 1,
    category: "grammar",
  },
  {
    id: "speedrace",
    type: "speedrace",
    title: "Course de vitesse",
    titleEn: "Speed Race",
    description: "Répondez le plus vite possible pour marquer des points",
    descriptionEn: "Answer as fast as possible to score points",
    icon: "zap",
    iconGradient: ["#ef4444", "#dc2626"],
    minPlayers: 1,
    category: "speed",
  },
  {
    id: "scramble",
    type: "scramble",
    title: "Mots mélangés",
    titleEn: "Word Scramble",
    description: "Remettez les lettres dans l'ordre pour former le mot",
    descriptionEn: "Rearrange letters to form the correct word",
    icon: "shuffle",
    iconGradient: ["#ec4899", "#db2777"],
    minPlayers: 1,
    category: "vocabulary",
  },
  {
    id: "culturequiz",
    type: "culturequiz",
    title: "Quiz Culturel",
    titleEn: "Culture Quiz",
    description: "Testez vos connaissances sur les cultures africaines",
    descriptionEn: "Test your knowledge of African cultures",
    icon: "globe",
    iconGradient: ["#14b8a6", "#0d9488"],
    minPlayers: 1,
    category: "culture",
  },
  {
    id: "wordhunt",
    type: "wordhunt",
    title: "Chasse aux mots",
    titleEn: "Word Hunt",
    description: "Trouvez les mots cachés dans la grille",
    descriptionEn: "Find hidden words in the grid",
    icon: "search",
    iconGradient: ["#6366f1", "#4f46e5"],
    minPlayers: 1,
    category: "vocabulary",
  },
  {
    id: "phrasebuilder",
    type: "phrasebuilder",
    title: "Constructeur de phrases",
    titleEn: "Phrase Builder",
    description: "Organisez les mots pour former une phrase correcte",
    descriptionEn: "Arrange words to form a correct sentence",
    icon: "list",
    iconGradient: ["#f97316", "#ea580c"],
    minPlayers: 1,
    category: "grammar",
  },
  {
    id: "listening",
    type: "listening",
    title: "Écoute",
    titleEn: "Listening",
    description: "Écoutez et trouvez la bonne traduction",
    descriptionEn: "Listen and find the correct translation",
    icon: "volume-2",
    iconGradient: ["#06b6d4", "#0891b2"],
    minPlayers: 1,
    category: "pronunciation",
  },
];

/**
 * Récupère un jeu par son ID
 */
export function getGameById(id: string): GameConfig | undefined {
  return GAME_REGISTRY.find(game => game.id === id);
}

/**
 * Récupère les jeux par catégorie
 */
export function getGamesByCategory(category: GameConfig["category"]): GameConfig[] {
  return GAME_REGISTRY.filter(game => game.category === category);
}

/**
 * Récupère tous les IDs de jeux
 */
export function getAllGameIds(): string[] {
  return GAME_REGISTRY.map(game => game.id);
}

/**
 * Récupère les catégories disponibles
 */
export function getCategories(): GameConfig["category"][] {
  return [...new Set(GAME_REGISTRY.map(game => game.category))];
}