import React, { useState, useMemo } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

export function PhraseBuilderGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<string[]>([]);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  const phrases = [
    { words: ["Nakupenda", "sana"], correct: [0, 1], translation: "Je t'aime beaucoup" },
    { words: ["Nataka", "maji"], correct: [0, 1], translation: "Je veux de l'eau" },
    { words: ["Asante", "sana"], correct: [0, 1], translation: "Merci beaucoup" },
  ];

  const current = phrases[currentIndex];
  const available = useMemo(() => current.words.filter(w => !selected.includes(w)), [selected, currentIndex]);

  function handleValidate() {
    const isCorrect = selected.join(" ") === current.correct.map(i => current.words[i]).join(" ");
    if (isCorrect) setScore(s => s + 5);
    if (currentIndex + 1 >= phrases.length) onComplete(score + (isCorrect ? 5 : 0), phrases.length * 5);
    else { setCurrentIndex(i => i + 1); setSelected([]); }
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.progress, { color: fg }]}>{currentIndex + 1}/{phrases.length}</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <View style={styles.card}>
        <Text style={styles.hintLabel}>Traduction</Text>
        <Text style={[styles.hint, { color: fg }]}>{current.translation}</Text>
      </View>
      <View style={styles.buildZone}>
        {selected.map((w, i) => (
          <Pressable key={i} style={[styles.wordBubble, { backgroundColor: "#10b981" }]} onPress={() => setSelected(prev => prev.filter(x => x !== w))}>
            <Text style={styles.wordText}>{w}</Text>
          </Pressable>
        ))}
      </View>
      <View style={styles.wordOptions}>
        {available.map((w, i) => (
          <Pressable key={i} style={[styles.wordBubble, { backgroundColor: "#1f2937", borderColor: "#374151" }]} onPress={() => setSelected(prev => [...prev, w])}>
            <Text style={[styles.wordText, { color: fg }]}>{w}</Text>
          </Pressable>
        ))}
      </View>
      <Pressable style={[styles.btn, { backgroundColor: "#10b981", marginHorizontal: 20 }]} onPress={handleValidate}>
        <Text style={styles.btnText}>Valider</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  progress: { fontSize: 14, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  card: { alignItems: "center", padding: 20, gap: 4 },
  hintLabel: { color: "#9ca3af", fontSize: 11, textTransform: "uppercase" },
  hint: { fontSize: 22, fontWeight: "700" },
  buildZone: { minHeight: 50, flexDirection: "row", flexWrap: "wrap", gap: 8, padding: 16, marginHorizontal: 20, borderWidth: 2, borderColor: "#374151", borderStyle: "dashed", borderRadius: 12 },
  wordOptions: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 8, padding: 16 },
  wordBubble: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, borderWidth: 1 },
  wordText: { color: "#fff", fontWeight: "600", fontSize: 14 },
  btn: { paddingVertical: 14, borderRadius: 12, alignItems: "center", marginTop: 8 },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 14 },
});