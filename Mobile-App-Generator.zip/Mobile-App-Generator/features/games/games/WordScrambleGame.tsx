import React, { useState, useMemo } from "react";
import { Pressable, StyleSheet, Text, View, TextInput } from "react-native";
import { Feather } from "@expo/vector-icons";

function shuffle(str: string) {
  const arr = str.split("");
  for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [arr[i], arr[j]] = [arr[j], arr[i]]; }
  if (arr.join("") === str) return shuffle(str);
  return arr.join("");
}

export function WordScrambleGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [answer, setAnswer] = useState("");
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  const words = [
    { word: "habari", translation: "bonjour" },
    { word: "asante", translation: "merci" },
    { word: "maji", translation: "eau" },
    { word: "rafiki", translation: "ami" },
  ];

  const currentWord = words[currentIndex];
  const scrambled = useMemo(() => shuffle(currentWord.word), [currentIndex]);

  function handleSubmit() {
    if (answer.toLowerCase() === currentWord.word.toLowerCase()) {
      setScore(s => s + 3);
      if (currentIndex + 1 >= words.length) onComplete(score + 3, words.length * 3);
      else { setCurrentIndex(i => i + 1); setAnswer(""); }
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.progress, { color: fg }]}>{currentIndex + 1}/{words.length}</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <View style={styles.card}>
        <Text style={styles.hintLabel}>Traduction</Text>
        <Text style={[styles.hint, { color: fg }]}>{currentWord.translation}</Text>
        <Text style={[styles.scrambled, { color: "#f59e0b" }]}>{scrambled.toUpperCase()}</Text>
      </View>
      <TextInput style={styles.input} value={answer} onChangeText={setAnswer} placeholder="Votre réponse..." placeholderTextColor="#6b7280" onSubmitEditing={handleSubmit} />
      <Pressable style={[styles.btn, { backgroundColor: "#10b981", marginHorizontal: 20 }]} onPress={handleSubmit}>
        <Text style={styles.btnText}>Valider</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  progress: { fontSize: 14, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  card: { alignItems: "center", padding: 30, gap: 8 },
  hintLabel: { color: "#9ca3af", fontSize: 11, textTransform: "uppercase" },
  hint: { fontSize: 24, fontWeight: "700" },
  scrambled: { fontSize: 32, fontWeight: "800", letterSpacing: 8, marginTop: 12 },
  input: { marginHorizontal: 20, backgroundColor: "#1f2937", borderRadius: 12, padding: 14, fontSize: 18, color: "#fff", textAlign: "center", borderWidth: 2, borderColor: "#374151" },
  btn: { paddingVertical: 14, borderRadius: 12, alignItems: "center", marginTop: 16 },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 14 },
});