import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

export function ListeningGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showWord, setShowWord] = useState(false);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  const words = [
    { word: "habari", translation: "bonjour" },
    { word: "asante", translation: "merci" },
    { word: "maji", translation: "eau" },
  ];

  const currentWord = words[currentIndex];
  const options = [currentWord.translation, ...words.filter(w => w.word !== currentWord.word).slice(0, 3).map(w => w.translation)].sort(() => Math.random() - 0.5);

  function handleAnswer(opt: string) {
    if (opt === currentWord.translation) setScore(s => s + 5);
    if (currentIndex + 1 >= words.length) onComplete(score + (opt === currentWord.translation ? 5 : 0), words.length * 5);
    else { setCurrentIndex(i => i + 1); setShowWord(false); }
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.progress, { color: fg }]}>{currentIndex + 1}/{words.length}</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <Pressable style={[styles.listenBtn, { backgroundColor: "#06b6d4" }]} onPress={() => setShowWord(true)}>
        <Feather name="volume-2" size={40} color="#fff" />
        <Text style={styles.listenText}>Écouter</Text>
      </Pressable>
      {showWord && <Text style={[styles.reveal, { color: fg }]}>{currentWord.word}</Text>}
      <Text style={[styles.question, { color: fg }]}>Quelle est la traduction ?</Text>
      <View style={styles.options}>
        {options.map((opt, i) => (
          <Pressable key={i} style={styles.option} onPress={() => handleAnswer(opt)}>
            <Text style={[styles.optionText, { color: fg }]}>{opt}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  progress: { fontSize: 14, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  listenBtn: { width: 100, height: 100, borderRadius: 50, alignSelf: "center", alignItems: "center", justifyContent: "center", marginVertical: 20 },
  listenText: { color: "#fff", fontWeight: "600", fontSize: 12, marginTop: 4 },
  reveal: { fontSize: 28, fontWeight: "800", textAlign: "center", marginBottom: 12 },
  question: { textAlign: "center", fontSize: 16, marginBottom: 16 },
  options: { gap: 10, paddingHorizontal: 20 },
  option: { backgroundColor: "#1f2937", padding: 16, borderRadius: 14, borderWidth: 2, borderColor: "#374151", alignItems: "center" },
  optionText: { fontSize: 16, fontWeight: "600" },
});