import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

export function CultureQuizGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  const questions = [
    { q: "Dans quel pays parle-t-on le swahili ?", opts: ["Tanzanie", "Nigeria", "Ghana", "Sénégal"], correct: 0 },
    { q: "Que signifie 'Hakuna Matata' ?", opts: ["Pas de problème", "Au revoir", "Bonjour", "Merci"], correct: 0 },
    { q: "Quelle est la capitale de la RDC ?", opts: ["Kinshasa", "Lagos", "Nairobi", "Accra"], correct: 0 },
  ];

  const q = questions[currentIndex];

  function handleAnswer(idx: number) {
    setSelected(idx);
    if (idx === q.correct) setScore(s => s + 10);
    setTimeout(() => {
      if (currentIndex + 1 >= questions.length) onComplete(score + (idx === q.correct ? 10 : 0), questions.length * 10);
      else { setCurrentIndex(i => i + 1); setSelected(null); }
    }, 1000);
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.progress, { color: fg }]}>{currentIndex + 1}/{questions.length}</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <View style={styles.card}>
        <Text style={[styles.question, { color: fg }]}>{q.q}</Text>
      </View>
      <View style={styles.options}>
        {q.opts.map((opt, i) => {
          let bgColor = "#1f2937", borderColor = "#374151";
          if (selected !== null) {
            if (i === q.correct) { bgColor = "#10b98120"; borderColor = "#10b981"; }
            else if (i === selected) { bgColor = "#ef444420"; borderColor = "#ef4444"; }
          }
          return (
            <Pressable key={i} style={[styles.option, { backgroundColor: bgColor, borderColor }]} onPress={() => handleAnswer(i)} disabled={selected !== null}>
              <Text style={[styles.optionText, { color: fg }]}>{opt}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  progress: { fontSize: 14, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  card: { padding: 30, alignItems: "center" },
  question: { fontSize: 18, fontWeight: "600", textAlign: "center" },
  options: { gap: 10, paddingHorizontal: 20 },
  option: { padding: 16, borderRadius: 14, borderWidth: 2, alignItems: "center" },
  optionText: { fontSize: 15, fontWeight: "600" },
});