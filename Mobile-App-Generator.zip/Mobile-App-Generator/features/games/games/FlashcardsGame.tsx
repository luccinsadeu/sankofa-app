import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

export function FlashcardsGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [score, setScore] = useState(0);

  const words = [
    { word: "habari", translation: "bonjour" },
    { word: "asante", translation: "merci" },
    { word: "maji", translation: "eau" },
    { word: "rafiki", translation: "ami" },
    { word: "shule", translation: "école" },
  ];

  const currentWord = words[currentIndex];
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  function handleResponse(known: boolean) {
    if (known) setScore(s => s + 1);
    if (currentIndex + 1 >= words.length) {
      onComplete(score + (known ? 1 : 0), words.length);
    } else {
      setCurrentIndex(i => i + 1);
      setIsFlipped(false);
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={styles.progress}>{currentIndex + 1}/{words.length}</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <Pressable style={styles.cardContainer} onPress={() => setIsFlipped(!isFlipped)}>
        <View style={[styles.card, { borderColor: isFlipped ? "#3b82f6" : "#374151" }]}>
          <Text style={styles.cardLabel}>{isFlipped ? "Traduction" : "Mot"}</Text>
          <Text style={[styles.cardText, { color: fg }]}>{isFlipped ? currentWord.translation : currentWord.word}</Text>
        </View>
      </Pressable>
      <Text style={styles.tapHint}>Tapez pour retourner</Text>
      {isFlipped && (
        <View style={styles.responseRow}>
          <Pressable style={[styles.responseBtn, { backgroundColor: "#ef4444" }]} onPress={() => handleResponse(false)}>
            <Text style={styles.responseText}>❌ À réviser</Text>
          </Pressable>
          <Pressable style={[styles.responseBtn, { backgroundColor: "#10b981" }]} onPress={() => handleResponse(true)}>
            <Text style={styles.responseText}>✅ Je sais</Text>
          </Pressable>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  progress: { color: "#9ca3af", fontSize: 14, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  cardContainer: { flex: 1, justifyContent: "center", paddingHorizontal: 20 },
  card: { minHeight: 250, borderRadius: 20, borderWidth: 2, justifyContent: "center", alignItems: "center", padding: 30, backgroundColor: "#1f2937" },
  cardLabel: { color: "#9ca3af", fontSize: 11, textTransform: "uppercase", letterSpacing: 1, marginBottom: 12 },
  cardText: { fontSize: 32, fontWeight: "800", textAlign: "center" },
  tapHint: { color: "#6b7280", textAlign: "center", fontSize: 13, marginVertical: 12 },
  responseRow: { flexDirection: "row", gap: 16, paddingHorizontal: 20, paddingBottom: 30 },
  responseBtn: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 16, borderRadius: 14 },
  responseText: { color: "#fff", fontWeight: "700", fontSize: 15 },
});