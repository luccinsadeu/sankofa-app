import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

export function FillBlankGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  const questions = [
    { sentence: "______ signifie bonjour en swahili", options: ["Habari", "Asante", "Maji", "Rafiki"], correct: 0 },
    { sentence: "______ signifie merci en swahili", options: ["Habari", "Asante", "Maji", "Shule"], correct: 1 },
    { sentence: "______ signifie eau en swahili", options: ["Rafiki", "Asante", "Maji", "Habari"], correct: 2 },
    { sentence: "______ signifie ami en swahili", options: ["Shule", "Maji", "Asante", "Rafiki"], correct: 3 },
  ];

  const q = questions[currentIndex];

  function handleAnswer(idx: number) {
    setSelected(idx);
    if (idx === q.correct) setScore(s => s + 10);
    setTimeout(() => {
      if (currentIndex + 1 >= questions.length) onComplete(score + (idx === q.correct ? 10 : 0), questions.length * 10);
      else { setCurrentIndex(i => i + 1); setSelected(null); }
    }, 800);
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.progress, { color: fg }]}>{currentIndex + 1}/{questions.length}</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <View style={styles.card}>
        <Text style={[styles.sentence, { color: fg }]}>{q.sentence}</Text>
      </View>
      <View style={styles.options}>
        {q.options.map((opt, i) => {
          let bgColor = "#1f2937", borderColor = "#374151";
          if (selected !== null) {
            if (i === q.correct) { bgColor = "#10b98120"; borderColor = "#10b981"; }
            else if (i === selected) { bgColor = "#ef444420"; borderColor = "#ef4444"; }
          }
          return (
            <Pressable key={i} style={[styles.option, { backgroundColor: bgColor, borderColor }]} onPress={() => handleAnswer(i)} disabled={selected !== null}>
              <Text style={[styles.optionText, { color: fg }]}>{opt}</Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  progress: { fontSize: 14, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  card: { padding: 30, alignItems: "center" },
  sentence: { fontSize: 20, fontWeight: "600", textAlign: "center" },
  options: { gap: 10, paddingHorizontal: 20 },
  option: { padding: 16, borderRadius: 14, borderWidth: 2, alignItems: "center" },
  optionText: { fontSize: 16, fontWeight: "600" },
});