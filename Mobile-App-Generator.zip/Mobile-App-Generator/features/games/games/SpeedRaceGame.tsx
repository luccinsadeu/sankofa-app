import React, { useState, useEffect, useRef } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

export function SpeedRaceGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [combo, setCombo] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout>();

  const words = [
    { word: "habari", translation: "bonjour" },
    { word: "asante", translation: "merci" },
    { word: "maji", translation: "eau" },
    { word: "rafiki", translation: "ami" },
    { word: "shule", translation: "école" },
    { word: "ndiyo", translation: "oui" },
    { word: "hapana", translation: "non" },
    { word: "chakula", translation: "nourriture" },
  ];

  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  useEffect(() => {
    if (!gameOver && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(t => { if (t <= 1) { clearInterval(intervalRef.current); setGameOver(true); onComplete(score, words.length * 3); return 0; } return t - 1; });
      }, 1000);
    }
    return () => clearInterval(intervalRef.current);
  }, [gameOver]);

  const currentWord = words[currentIndex % words.length];
  const isCorrect = Math.random() > 0.5;
  const displayedTranslation = isCorrect ? currentWord.translation : words[Math.floor(Math.random() * words.length)].translation;

  function handleAnswer(userSaysCorrect: boolean) {
    if (userSaysCorrect === isCorrect) {
      const newCombo = combo + 1;
      setScore(s => s + (newCombo >= 5 ? 3 : 1));
      setCombo(newCombo);
    } else {
      setCombo(0);
    }
    setCurrentIndex(i => i + 1);
  }

  if (gameOver) {
    return (
      <View style={[styles.container, { backgroundColor: bg, justifyContent: "center", alignItems: "center" }]}>
        <Text style={{ fontSize: 48 }}>⚡</Text>
        <Text style={[styles.resultScore, { color: fg }]}>{score} pts</Text>
        <View style={{ flexDirection: "row", gap: 12, marginTop: 20 }}>
          <Pressable style={[styles.btn, { backgroundColor: "#10b981" }]} onPress={() => { setScore(0); setTimeLeft(30); setGameOver(false); setCombo(0); }}>
            <Text style={styles.btnText}>↻ Rejouer</Text>
          </Pressable>
          <Pressable style={[styles.btn, { backgroundColor: "#6b7280" }]} onPress={onBack}>
            <Text style={styles.btnText}>Menu</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.timer, { color: timeLeft > 10 ? "#10b981" : "#ef4444" }]}>{timeLeft}s</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      {combo >= 3 && <Text style={styles.comboText}>🔥 Combo x{combo}!</Text>}
      <View style={styles.card}>
        <Text style={[styles.word, { color: fg }]}>{currentWord.word}</Text>
        <Text style={[styles.translation, { color: fg }]}>{displayedTranslation}</Text>
      </View>
      <Text style={[styles.question, { color: fg }]}>Bonne traduction ?</Text>
      <View style={styles.responseRow}>
        <Pressable style={[styles.responseBtn, { backgroundColor: "#10b981" }]} onPress={() => handleAnswer(true)}>
          <Text style={styles.responseText}>✅ OUI</Text>
        </Pressable>
        <Pressable style={[styles.responseBtn, { backgroundColor: "#ef4444" }]} onPress={() => handleAnswer(false)}>
          <Text style={styles.responseText}>❌ NON</Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  timer: { fontSize: 28, fontWeight: "800" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  comboText: { textAlign: "center", color: "#f59e0b", fontSize: 16, fontWeight: "700", marginTop: 8 },
  card: { alignItems: "center", padding: 30, gap: 12 },
  word: { fontSize: 32, fontWeight: "800" },
  translation: { fontSize: 22 },
  question: { textAlign: "center", fontSize: 16, marginVertical: 12 },
  responseRow: { flexDirection: "row", gap: 16, paddingHorizontal: 20 },
  responseBtn: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 18, borderRadius: 14 },
  responseText: { color: "#fff", fontWeight: "800", fontSize: 16 },
  resultScore: { fontSize: 36, fontWeight: "800", marginTop: 16 },
  btn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10 },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 14 },
});