import React, { useState, useMemo } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

const GRID = [
  ["h", "a", "b", "a", "r", "i", "x", "y"],
  ["a", "s", "a", "n", "t", "e", "z", "w"],
  ["m", "a", "j", "i", "k", "l", "p", "q"],
  ["r", "a", "f", "i", "k", "i", "m", "n"],
  ["s", "h", "u", "l", "e", "o", "v", "u"],
  ["x", "y", "z", "a", "b", "c", "d", "e"],
  ["f", "g", "h", "i", "j", "k", "l", "m"],
  ["n", "o", "p", "q", "r", "s", "t", "u"],
];

const WORDS = ["habari", "asante", "maji", "rafiki", "shule"];

export function WordHuntGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [found, setFound] = useState<Set<string>>(new Set());
  const [selected, setSelected] = useState<[number, number][]>([]);
  const [score, setScore] = useState(0);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  function handleCell(r: number, c: number) {
    const newSelected = [...selected, [r, c] as [number, number]];
    setSelected(newSelected);
    const word = newSelected.map(([rr, cc]) => GRID[rr][cc]).join("");
    if (WORDS.includes(word) && !found.has(word)) {
      setFound(new Set([...found, word]));
      setScore(s => s + 10);
      setSelected([]);
      if (found.size + 1 >= WORDS.length) onComplete(score + 10, WORDS.length * 10);
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.stats, { color: fg }]}>Trouvés: {found.size}/{WORDS.length}</Text>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <View style={styles.wordList}>
        {WORDS.map(w => (
          <Text key={w} style={[styles.wordChip, { color: found.has(w) ? "#10b981" : "#6b7280" }]}>{w} {found.has(w) ? "✓" : ""}</Text>
        ))}
      </View>
      <View style={styles.grid}>
        {GRID.map((row, r) => (
          <View key={r} style={styles.gridRow}>
            {row.map((letter, c) => (
              <Pressable key={c} style={[styles.gridCell, { backgroundColor: selected.some(([rr, cc]) => rr === r && cc === c) ? "#f59e0b" : "#1f2937", borderColor: selected.some(([rr, cc]) => rr === r && cc === c) ? "#f59e0b" : "#374151" }]} onPress={() => handleCell(r, c)}>
                <Text style={styles.gridLetter}>{letter.toUpperCase()}</Text>
              </Pressable>
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  stats: { fontSize: 13, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  wordList: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 8, paddingHorizontal: 16, marginBottom: 16 },
  wordChip: { fontSize: 14, fontWeight: "600" },
  grid: { paddingHorizontal: 4, gap: 3 },
  gridRow: { flexDirection: "row", gap: 3 },
  gridCell: { width: 40, height: 40, borderRadius: 6, borderWidth: 1, alignItems: "center", justifyContent: "center" },
  gridLetter: { color: "#fff", fontSize: 16, fontWeight: "700" },
});