import React, { useState, useMemo } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { Feather } from "@expo/vector-icons";

export function MatchingGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  const words = [
    { word: "habari", translation: "bonjour" },
    { word: "asante", translation: "merci" },
    { word: "maji", translation: "eau" },
    { word: "rafiki", translation: "ami" },
  ];

  const cards = useMemo(() => {
    const pairs = words.flatMap((w, i) => [
      { id: i * 2, text: w.word, pairId: i, type: "word", flipped: false, matched: false },
      { id: i * 2 + 1, text: w.translation, pairId: i, type: "trans", flipped: false, matched: false },
    ]);
    return pairs.sort(() => Math.random() - 0.5);
  }, []);

  const [gameCards, setGameCards] = useState(cards);
  const [flipped, setFlipped] = useState<number[]>([]);
  const [matches, setMatches] = useState(0);
  const [attempts, setAttempts] = useState(0);

  function handlePress(id: number) {
    const card = gameCards.find(c => c.id === id);
    if (!card || card.flipped || card.matched || flipped.length >= 2) return;
    const newCards = gameCards.map(c => c.id === id ? { ...c, flipped: true } : c);
    setGameCards(newCards);
    const newFlipped = [...flipped, id];
    setFlipped(newFlipped);
    if (newFlipped.length === 2) {
      setAttempts(a => a + 1);
      const [a, b] = newFlipped.map(id => newCards.find(c => c.id === id)!);
      if (a.pairId === b.pairId && a.type !== b.type) {
        setTimeout(() => {
          setGameCards(prev => prev.map(c => c.id === a.id || c.id === b.id ? { ...c, matched: true } : c));
          setFlipped([]);
          setMatches(m => { if (m + 1 >= words.length) onComplete((m + 1) * 10, words.length * 10); return m + 1; });
        }, 500);
      } else {
        setTimeout(() => {
          setGameCards(prev => prev.map(c => c.id === a.id || c.id === b.id ? { ...c, flipped: false } : c));
          setFlipped([]);
        }, 800);
      }
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.stats, { color: fg }]}>Paires: {matches}/{words.length}</Text>
        <Text style={[styles.stats, { color: fg }]}>Coups: {attempts}</Text>
      </View>
      <View style={styles.grid}>
        {gameCards.map(card => (
          <Pressable key={card.id} style={[styles.gridCard, { backgroundColor: card.matched ? "#10b981" : card.flipped ? "#3b82f6" : "#1f2937", borderColor: card.flipped || card.matched ? "transparent" : "#374151" }]} onPress={() => handlePress(card.id)}>
            <Text style={styles.gridText}>{card.flipped || card.matched ? card.text : "?"}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  stats: { fontSize: 13, fontWeight: "600" },
  grid: { flexDirection: "row", flexWrap: "wrap", padding: 12, gap: 8 },
  gridCard: { width: "22%", aspectRatio: 0.75, borderRadius: 12, borderWidth: 2, alignItems: "center", justifyContent: "center", padding: 4 },
  gridText: { color: "#fff", fontWeight: "700", fontSize: 12, textAlign: "center" },
});