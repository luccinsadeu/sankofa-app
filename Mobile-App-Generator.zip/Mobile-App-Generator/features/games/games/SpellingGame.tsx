import React, { useState } from "react";
import { Pressable, StyleSheet, Text, View, TextInput } from "react-native";
import { Feather } from "@expo/vector-icons";

export function SpellingGame({ language, difficulty, onComplete, onBack, colors, lang: appLang }: any) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [answer, setAnswer] = useState("");
  const [lives, setLives] = useState(3);
  const [showWord, setShowWord] = useState(true);

  const words = [
    { word: "habari", translation: "bonjour" },
    { word: "asante", translation: "merci" },
    { word: "maji", translation: "eau" },
    { word: "rafiki", translation: "ami" },
    { word: "shule", translation: "école" },
  ];

  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";
  const currentWord = words[currentIndex];

  useState(() => { setTimeout(() => setShowWord(false), 2000); });

  function handleSubmit() {
    if (answer.toLowerCase() === currentWord.word.toLowerCase()) {
      setScore(s => s + 5);
      if (currentIndex + 1 >= words.length) {
        onComplete(score + 5, words.length * 5);
      } else {
        setCurrentIndex(i => i + 1);
        setAnswer("");
        setShowWord(true);
        setTimeout(() => setShowWord(false), 2000);
      }
    } else {
      setLives(l => l - 1);
      if (lives <= 1) {
        if (currentIndex + 1 >= words.length) onComplete(score, words.length * 5);
        else { setCurrentIndex(i => i + 1); setAnswer(""); setLives(3); setShowWord(true); setTimeout(() => setShowWord(false), 2000); }
      }
    }
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <View style={{ flexDirection: "row", gap: 4 }}>{Array.from({ length: 3 }).map((_, i) => <Feather key={i} name="heart" size={16} color={i < lives ? "#ef4444" : "#374151"} />)}</View>
        <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
      </View>
      <View style={styles.card}>
        <Text style={styles.hintLabel}>Traduction</Text>
        <Text style={[styles.hint, { color: fg }]}>{currentWord.translation}</Text>
        {showWord && <Text style={[styles.reveal, { color: "#10b981" }]}>{currentWord.word}</Text>}
      </View>
      <TextInput style={styles.input} value={answer} onChangeText={setAnswer} placeholder="Épelez le mot..." placeholderTextColor="#6b7280" onSubmitEditing={handleSubmit} />
      <Pressable style={[styles.btn, { backgroundColor: "#10b981", marginHorizontal: 20 }]} onPress={handleSubmit}>
        <Text style={styles.btnText}>Valider</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingVertical: 50 },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "#374151" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  card: { alignItems: "center", padding: 30, gap: 8 },
  hintLabel: { color: "#9ca3af", fontSize: 11, textTransform: "uppercase" },
  hint: { fontSize: 24, fontWeight: "700" },
  reveal: { fontSize: 28, fontWeight: "800", marginTop: 8 },
  input: { marginHorizontal: 20, backgroundColor: "#1f2937", borderRadius: 12, padding: 14, fontSize: 18, color: "#fff", textAlign: "center", borderWidth: 2, borderColor: "#374151" },
  btn: { paddingVertical: 14, borderRadius: 12, alignItems: "center", marginTop: 16 },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 14 },
});