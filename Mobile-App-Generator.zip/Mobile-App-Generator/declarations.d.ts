// Déclaration pour le module welcome
declare module "./welcome" {
  import { ComponentType } from "react";
  
  interface WelcomeScreenProps {
    onComplete?: () => void;
  }
  
  const WelcomeScreen: ComponentType<WelcomeScreenProps>;
  export default WelcomeScreen;
}

// Déclaration pour les fichiers .tsx génériques
declare module "*.tsx" {
  const content: any;
  export default content;
}

// Déclaration pour les hooks personnalisés si nécessaire
declare module "@/hooks/useColors" {
  export function useColors(): any;
}

declare module "@/context/AppContext" {
  export function useApp(): any;
}
