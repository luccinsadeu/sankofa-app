# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (ESM bundle)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — build + run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Artifacts

### Sankofa Translate (Mobile App)
- **Directory**: `artifacts/sankofa-translate/`
- **Type**: Expo (React Native) SDK 54
- **Preview**: `/` (root path)
- **Description**: African language translation and learning app

#### Features
- **Translation** via Groq API (llama-3.3-70b-versatile) — 11 African languages
- **Quiz System** — 3 tiers per language × 10 questions × 8 languages = 240 questions; need ≥70% to unlock next tier
- **Social feed** with posts, likes, comments backed by PostgreSQL (universal across devices)
- **Auth** — signup/login backed by PostgreSQL `sankofa_users` table; session persisted in AsyncStorage
- **Cumulative score system** with tier progress persisted in AsyncStorage
- **Animations** (react-native-reanimated ~4.1.1): FadeIn, FadeInDown, FadeInUp, SlideIn, ZoomIn on all major screens
- **Haptics hook** (`hooks/useHaptics.ts`): toggle stored in AsyncStorage
- **Push Notifications** (`services/notificationService.ts`): daily/weekly reminders with time picker
- **Messages tab** + **Chat screen** with simulated friend responses
- Deep green + gold + terracotta African-inspired color theme
- FR/EN bilingual UI via I18nContext

#### Key Files
- `app/_layout.tsx` — Root layout with AppProvider + I18nProvider, auth redirect
- `app/(tabs)/_layout.tsx` — 6-tab navigation (Accueil, Traduire, Quiz, Social, Messages, Profil)
- `context/AppContext.tsx` — Global state; calls API for posts/users with optimistic UI; API base = `https://$REPLIT_DEV_DOMAIN/api`
- `context/I18nContext.tsx` — FR/EN translation system
- `services/groqService.ts` — Groq API translation service
- `theme/quiz.ts` — 240 quiz questions across 8 languages × 3 tiers
- `components/ui.tsx` — Shared UI (GradientButton, Card, Toast, FloatingOrbs…)
- `constants/colors.ts` — African-inspired color palette

### API Server
- **Directory**: `artifacts/api-server/`
- **Port**: 3000 (localPort in artifact.toml; Replit proxy routes `/api` → port 3000)
- **Dev script**: builds with esbuild then starts `dist/index.mjs`
- **Routes**:
  - `GET /api/healthz` — Health check
  - `GET /api/posts` — List all posts (auto-seeds 20 posts if DB empty)
  - `POST /api/posts` — Create post
  - `PATCH /api/posts/:id` — Update likes/comments
  - `DELETE /api/posts/:id` — Delete post
  - `POST /api/users` — Signup (name+email) or login (email only)
  - `GET /api/users/:id` — Get user
  - `PATCH /api/users/:id` — Update score/name/avatar
  - `GET /api/messages/:userId/:friendId` — Get chat messages
  - `POST /api/messages` — Send message
  - `PATCH /api/messages/:id/read` — Mark read
  - `GET /api/posts/:postId/comments` — Get comments
  - `POST /api/posts/:postId/comments` — Add comment
  - `DELETE /api/comments/:id` — Delete comment

### Database (PostgreSQL)
- **Tables**: `sankofa_users`, `sankofa_posts` (jsonb `likes`/`comments`), `sankofa_messages`, `sankofa_comments`
- **Schema**: `lib/db/src/schema/index.ts`
- **Connection**: `lib/db/src/index.ts` (Drizzle + pg Pool)

## Architecture decisions

- API server uses port **3000** (not 8080) — Replit's port detection fails on 8080 but works on 3000.
- Posts and users are stored in PostgreSQL (universal across devices). Auth/session still uses AsyncStorage for fast offline access; DB is the source of truth.
- AppContext uses optimistic UI: updates local state immediately, then syncs to DB in background. Falls back gracefully if API is unreachable.
- `EXPO_PUBLIC_DOMAIN=$REPLIT_DEV_DOMAIN` is injected by the Expo dev script so the mobile app can call `https://${domain}/api`.

## Gotchas

- API server must be on port 3000 — port 8080 causes "DIDNT_OPEN_A_PORT" in Replit workflow even though the server actually starts.
- After any `src/` change to api-server, run `pnpm --filter @workspace/api-server run build` before restarting the workflow.
- `pnpm --filter @workspace/db run push` requires a TTY; run it in the shell, not via bash tool.
