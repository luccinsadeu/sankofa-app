import { pgTable, text, uuid, timestamp, integer, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

// ─── Comment type stored inside posts ─────────────────────────────────────────
export type CommentData = {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
};

// ─── Messages ─────────────────────────────────────────────────────────────────
export const messagesTable = pgTable("sankofa_messages", {
  id: uuid("id").primaryKey().defaultRandom(),
  senderId: text("sender_id").notNull(),
  receiverId: text("receiver_id").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  readAt: timestamp("read_at", { withTimezone: true }),
});

// ─── Comments (standalone) ────────────────────────────────────────────────────
export const commentsTable = pgTable("sankofa_comments", {
  id: uuid("id").primaryKey().defaultRandom(),
  postId: text("post_id").notNull(),
  authorId: text("author_id").notNull(),
  authorName: text("author_name").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

// ─── Users ────────────────────────────────────────────────────────────────────
export const usersTable = pgTable("sankofa_users", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  avatar: text("avatar"),
  joinedAt: timestamp("joined_at", { withTimezone: true }).defaultNow(),
  totalScore: integer("total_score").default(0).notNull(),
});

// ─── Posts ────────────────────────────────────────────────────────────────────
export const postsTable = pgTable("sankofa_posts", {
  id: text("id").primaryKey(),
  authorId: text("author_id").notNull(),
  authorName: text("author_name").notNull(),
  content: text("content").notNull(),
  language: text("language").notNull().default("fr"),
  translation: text("translation"),
  imageUri: text("image_uri"),
  likes: jsonb("likes").$type<string[]>().default([]).notNull(),
  comments: jsonb("comments").$type<CommentData[]>().default([]).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
});

// ─── Schemas & types ──────────────────────────────────────────────────────────
export const insertMessageSchema = createInsertSchema(messagesTable).omit({ id: true, createdAt: true, readAt: true });
export const insertCommentSchema = createInsertSchema(commentsTable).omit({ id: true, createdAt: true });

export type DbMessage = typeof messagesTable.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type DbComment = typeof commentsTable.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type DbUser = typeof usersTable.$inferSelect;
export type DbPost = typeof postsTable.$inferSelect;
