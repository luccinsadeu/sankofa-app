#!/usr/bin/env node
// Fixes expo-modules-core for Node 24 compatibility.
// expo-modules-core@3.x ships only TypeScript source (src/index.ts) — no compiled JS.
// Node 24 tries to strip types when it loads .ts files, but fails for node_modules.
// Fix: create a build/index.js stub so imports resolve to JS, not TS.
const fs = require("fs");
const path = require("path");

const storeDir = path.join(__dirname, "..", "node_modules", ".pnpm");
if (!fs.existsSync(storeDir)) process.exit(0);

const STUB = `'use strict';
// Node 24 compatibility stub — expo-modules-core native functionality
// is provided at runtime by the compiled native module, not this file.
try { module.exports = require('./index.native.js'); } catch (e) {
  module.exports = {
    requireNativeModule: () => ({}),
    requireOptionalNativeModule: () => null,
    NativeModule: class NativeModule {},
    SharedObject: class SharedObject {},
    EventEmitter: class EventEmitter { addListener() {}; removeListener() {} },
  };
}
`;

let patched = 0;

function patchInstance(pkgDir) {
  const pkgJsonPath = path.join(pkgDir, "package.json");
  if (!fs.existsSync(pkgJsonPath)) return;

  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(pkgJsonPath, "utf8")); } catch { return; }

  const root = pkg?.exports?.["."];
  if (!root || typeof root !== "object") return;

  // Create build/index.js stub if missing
  const buildDir = path.join(pkgDir, "build");
  const stubPath = path.join(buildDir, "index.js");
  if (!fs.existsSync(stubPath)) {
    fs.mkdirSync(buildDir, { recursive: true });
    fs.writeFileSync(stubPath, STUB);
    patched++;
  }

  // Point default export to JS stub instead of .ts source
  if (root.default?.endsWith(".ts")) {
    root.default = "./build/index.js";
    fs.writeFileSync(pkgJsonPath, JSON.stringify(pkg, null, 2));
    patched++;
  }
}

// Versioned instances: .pnpm/expo-modules-core@.../node_modules/expo-modules-core
for (const entry of fs.readdirSync(storeDir)) {
  if (!entry.startsWith("expo-modules-core@")) continue;
  patchInstance(path.join(storeDir, entry, "node_modules", "expo-modules-core"));
}

// Hoisted instance: .pnpm/node_modules/expo-modules-core
patchInstance(path.join(storeDir, "node_modules", "expo-modules-core"));

if (patched) console.log(`[patch-expo-modules] Applied ${patched} fix(es) for Node 24 compatibility`);
