import app from "./app";
import { logger } from "./lib/logger";
import { pool } from "@workspace/db";

pool.on("error", (err) => {
  process.stderr.write(`[pg pool error] ${err.message}\n${err.stack ?? ""}\n`);
});

process.on("unhandledRejection", (reason) => {
  process.stderr.write(`[unhandledRejection] ${String(reason)}\n`);
});

process.on("uncaughtException", (err) => {
  process.stderr.write(`[uncaughtException] ${err.message}\n${err.stack ?? ""}\n`);
  process.exit(1);
});

process.on("SIGTERM", () => {
  process.stderr.write("[SIGTERM received] shutting down gracefully\n");
  process.exit(0);
});

const port = Number(process.env["PORT"] ?? 3000);

if (Number.isNaN(port) || port <= 0) {
  process.stderr.write(`Invalid PORT value: "${process.env["PORT"]}"\n`);
  process.exit(1);
}

const server = app.listen(port, "0.0.0.0", () => {
  logger.info({ port, pid: process.pid }, "Server listening");
});

server.on("error", (err: NodeJS.ErrnoException) => {
  process.stderr.write(`[server error] ${err.message} (code=${err.code})\n`);
  process.exit(1);
});
