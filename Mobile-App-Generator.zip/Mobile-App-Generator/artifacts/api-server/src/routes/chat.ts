import { Router } from "express";
import { db, messagesTable } from "@workspace/db";
import { eq, or, and, asc } from "drizzle-orm";
import { insertMessageSchema } from "@workspace/db";

const router = Router();

// GET /api/messages/:userId/:friendId
router.get("/:userId/:friendId", async (req, res) => {
  const { userId, friendId } = req.params;
  const messages = await db
    .select()
    .from(messagesTable)
    .where(
      or(
        and(eq(messagesTable.senderId, userId), eq(messagesTable.receiverId, friendId)),
        and(eq(messagesTable.senderId, friendId), eq(messagesTable.receiverId, userId)),
      ),
    )
    .orderBy(asc(messagesTable.createdAt));
  res.json(messages);
});

// POST /api/messages
router.post("/", async (req, res) => {
  const parsed = insertMessageSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error });
  }
  const [msg] = await db.insert(messagesTable).values(parsed.data).returning();
  res.status(201).json(msg);
});

// PATCH /api/messages/:id/read
router.patch("/:id/read", async (req, res) => {
  const { id } = req.params;
  const [updated] = await db
    .update(messagesTable)
    .set({ readAt: new Date() })
    .where(eq(messagesTable.id, id))
    .returning();
  res.json(updated);
});

export default router;
