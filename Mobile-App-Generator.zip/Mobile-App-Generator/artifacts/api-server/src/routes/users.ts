import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

// POST /api/users — create (signup) or get (login) by email
router.post("/", async (req, res) => {
  try {
    const { name, email } = req.body;
    if (!email) return res.status(400).json({ success: false, error: "Email requis" });

    const [existing] = await db.select().from(usersTable).where(eq(usersTable.email, email));

    if (existing) {
      // Login — user found
      return res.json({ success: true, user: existing });
    }

    // Signup — create new user
    if (!name) {
      return res.status(404).json({ success: false, error: "Aucun compte trouvé avec cet email" });
    }

    const [user] = await db.insert(usersTable).values({
      id: `user_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      name,
      email,
      avatar: null,
      totalScore: 0,
    }).returning();

    res.status(201).json({ success: true, user });
  } catch (err) {
    req.log.error({ err }, "POST /users failed");
    res.status(500).json({ success: false, error: "Internal server error" });
  }
});

// GET /api/users/:id
router.get("/:id", async (req, res) => {
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, req.params.id));
    if (!user) return res.status(404).json({ error: "User not found" });
    res.json(user);
  } catch (err) {
    req.log.error({ err }, "GET /users/:id failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// PATCH /api/users/:id — update score
router.patch("/:id", async (req, res) => {
  try {
    const { totalScore, name, avatar } = req.body;
    const updateData: Partial<typeof usersTable.$inferInsert> = {};
    if (totalScore !== undefined) updateData.totalScore = totalScore;
    if (name !== undefined) updateData.name = name;
    if (avatar !== undefined) updateData.avatar = avatar;

    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({ error: "Nothing to update" });
    }

    const [updated] = await db.update(usersTable).set(updateData).where(eq(usersTable.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ error: "User not found" });
    res.json({ success: true, user: updated });
  } catch (err) {
    req.log.error({ err }, "PATCH /users/:id failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
