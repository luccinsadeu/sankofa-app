import { Router } from "express";
import { db, commentsTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { insertCommentSchema } from "@workspace/db";

const router = Router();

router.get("/posts/:postId/comments", async (req, res) => {
  const { postId } = req.params;
  const comments = await db
    .select()
    .from(commentsTable)
    .where(eq(commentsTable.postId, postId))
    .orderBy(asc(commentsTable.createdAt));
  res.json(comments);
});

router.post("/posts/:postId/comments", async (req, res) => {
  const { postId } = req.params;
  const parsed = insertCommentSchema.safeParse({ ...req.body, postId });
  if (!parsed.success) {
    return res.status(400).json({ error: parsed.error });
  }
  const [comment] = await db.insert(commentsTable).values(parsed.data).returning();
  res.status(201).json(comment);
});

router.delete("/comments/:id", async (req, res) => {
  const { id } = req.params;
  await db.delete(commentsTable).where(eq(commentsTable.id, id));
  res.status(204).end();
});

export default router;
