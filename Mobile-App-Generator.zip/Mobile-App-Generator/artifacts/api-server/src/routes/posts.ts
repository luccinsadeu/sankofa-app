import { Router } from "express";
import { db, postsTable } from "@workspace/db";
import type { CommentData } from "@workspace/db";
import { eq, desc, sql } from "drizzle-orm";

const router = Router();

// ─── Default seed posts ───────────────────────────────────────────────────────
const SEED_POSTS = [
  { id: "seed_1", authorId: "system", authorName: "Amina Diallo", content: "🇸🇳 'Sankofa' - Retourner chercher ce qu'on a oublié pour mieux avancer.", language: "fr", translation: "Go back to fetch what you forgot to move forward.", daysAgo: 7 },
  { id: "seed_2", authorId: "system", authorName: "Kwame Asante", content: "🇬🇭 'Akwaaba' signifie 'Bienvenue' en Twi. Au Ghana, l'hospitalité est sacrée !", language: "fr", translation: "'Akwaaba' means 'Welcome' in Twi. In Ghana, hospitality is sacred!", daysAgo: 6 },
  { id: "seed_3", authorId: "system", authorName: "Zuri Okonkwo", content: "🇳🇬 'Oya' en Yoruba - 'Allez, c'est parti !' Une expression pleine d'énergie !", language: "fr", translation: "'Oya' in Yoruba - 'Let's go!' An energetic expression!", daysAgo: 5 },
  { id: "seed_4", authorId: "system", authorName: "Juma Mwangi", content: "🇰🇪 'Hakuna Matata' - 'Il n'y a pas de souci'. Une philosophie de vie positive.", language: "sw", translation: "'Hakuna Matata' - 'No worries'. A positive life philosophy.", daysAgo: 4 },
  { id: "seed_5", authorId: "system", authorName: "Fatima Benali", content: "🇲🇦 'Saha' - On dit 'Saha' pour souhaiter santé et joie, ou 'Bon appétit' !", language: "fr", translation: "'Saha' - A word to wish health, joy, or 'Enjoy your meal!'", daysAgo: 3 },
  { id: "seed_6", authorId: "system", authorName: "Thabo Nkosi", content: "🇿🇦 'Ubuntu' - 'Je suis parce que nous sommes'. L'humanité partagée.", language: "zu", translation: "'Ubuntu' - 'I am because we are'. Shared humanity.", daysAgo: 2 },
  { id: "seed_7", authorId: "system", authorName: "Yara Mansour", content: "🇪🇬 'Yalla' - 'Allons-y !', 'Vite !', 'Dépêche-toi !' Un mot magique égyptien.", language: "ar", translation: "'Yalla' - 'Let's go!', 'Hurry up!' A magic Egyptian word.", daysAgo: 1 },
  { id: "seed_8", authorId: "system", authorName: "Idriss Mahamat", content: "🇹🇩 'Salam Alaikum' - 'Paix sur vous'. Une salutation universelle.", language: "ar", translation: "'Salam Alaikum' - 'Peace be upon you'. A universal greeting.", hoursAgo: 20 },
  { id: "seed_9", authorId: "system", authorName: "Amina Diallo", content: "🇸🇳 'Teranga' - L'art de l'hospitalité sénégalaise. Un mode de vie !", language: "fr", translation: "'Teranga' - The Senegalese art of hospitality. A way of life!", hoursAgo: 18 },
  { id: "seed_10", authorId: "system", authorName: "Kwame Asante", content: "🇬🇭 'Kente' - Ce tissu traditionnel ghanéen raconte des histoires. Chaque motif a une signification !", language: "fr", translation: "'Kente' - This traditional Ghanaian fabric tells stories. Each pattern has a meaning!", hoursAgo: 16 },
  { id: "seed_11", authorId: "system", authorName: "Zuri Okonkwo", content: "🇳🇬 'Naija' - Le surnom affectueux du Nigeria. 'No wahala' ! 🇳🇬💚", language: "yo", translation: "'Naija' - The affectionate nickname for Nigeria. 'No wahala'!", hoursAgo: 14 },
  { id: "seed_12", authorId: "system", authorName: "Juma Mwangi", content: "🇰🇪 'Pole Pole' - Lentement, doucement... Tout vient à point à qui sait attendre.", language: "sw", translation: "'Pole Pole' - Slowly, gently... Good things come to those who wait.", hoursAgo: 12 },
  { id: "seed_13", authorId: "system", authorName: "Fatima Benali", content: "🇲🇦 'Beslama' - 'Au revoir' en darija marocain, en espérant se revoir en paix.", language: "ar", translation: "'Beslama' - 'Goodbye' in Moroccan Arabic.", hoursAgo: 10 },
  { id: "seed_14", authorId: "system", authorName: "Thabo Nkosi", content: "🇿🇦 'Shap shap' - 'Ça roule !', 'Tout va bien !' Une expression sud-africaine.", language: "zu", translation: "'Shap shap' - 'All good!', 'Everything is fine!'", hoursAgo: 8 },
  { id: "seed_15", authorId: "system", authorName: "Yara Mansour", content: "🇪🇬 'Habibi/Habibti' - 'Mon cher/Ma chère'. Un mot d'affection très utilisé !", language: "ar", translation: "'Habibi/Habibti' - 'My dear'. A very common word of endearment!", hoursAgo: 6 },
  { id: "seed_16", authorId: "system", authorName: "Idriss Mahamat", content: "🎶 La musique tchadienne est riche ! Découvrez le 'Soukous' et la 'Sara' 🎶", language: "fr", translation: "Chadian music is rich! Discover 'Soukous' and 'Sara' 🎶", hoursAgo: 5 },
  { id: "seed_17", authorId: "system", authorName: "Amina Diallo", content: "🎶 L'Afrobeat de Fela Kuti au Mbalax sénégalais, la musique africaine voyage !", language: "fr", translation: "From Fela Kuti's Afrobeat to Senegalese Mbalax, African music travels!", hoursAgo: 4 },
  { id: "seed_18", authorId: "system", authorName: "Kwame Asante", content: "🍲 Jollof Rice - Le grand débat ! Ghana ou Nigeria ? À vous de juger !", language: "fr", translation: "Jollof Rice - The great debate! Ghana or Nigeria? You decide!", hoursAgo: 3 },
  { id: "seed_19", authorId: "system", authorName: "Juma Mwangi", content: "🦁 'Safari' vient du swahili et signifie 'voyage'. Chaque jour est une aventure !", language: "sw", translation: "'Safari' comes from Swahili and means 'journey'. Every day is an adventure!", hoursAgo: 2 },
  { id: "seed_20", authorId: "system", authorName: "Fatima Benali", content: "🌍 L'Afrique compte plus de 2000 langues ! Quelle richesse culturelle incroyable !", language: "fr", translation: "Africa has over 2000 languages! What incredible cultural richness!", hoursAgo: 1 },
];

async function seedIfEmpty() {
  const count = await db.select({ c: sql<number>`count(*)` }).from(postsTable);
  if (Number(count[0]?.c) > 0) return;
  const now = Date.now();
  await db.insert(postsTable).values(
    SEED_POSTS.map((p) => ({
      id: p.id,
      authorId: p.authorId,
      authorName: p.authorName,
      content: p.content,
      language: p.language,
      translation: p.translation ?? null,
      imageUri: null,
      likes: [] as string[],
      comments: [] as CommentData[],
      createdAt: new Date(now - ((p as any).daysAgo ? (p as any).daysAgo * 86400_000 : (p as any).hoursAgo * 3600_000)),
    }))
  ).onConflictDoNothing();
}

// ─── Serialize ─────────────────────────────────────────────────────────────────
function serializePost(p: typeof postsTable.$inferSelect) {
  return {
    id: p.id,
    authorId: p.authorId,
    authorName: p.authorName,
    content: p.content,
    language: p.language,
    translation: p.translation ?? undefined,
    imageUri: p.imageUri ?? undefined,
    likes: (p.likes as string[]) ?? [],
    comments: (p.comments as CommentData[]) ?? [],
    createdAt: p.createdAt instanceof Date ? p.createdAt.toISOString() : String(p.createdAt),
  };
}

// GET /api/posts
router.get("/", async (req, res) => {
  try {
    await seedIfEmpty();
    const posts = await db.select().from(postsTable).orderBy(desc(postsTable.createdAt));
    res.json(posts.map(serializePost));
  } catch (err) {
    req.log.error({ err }, "GET /posts failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// POST /api/posts
router.post("/", async (req, res) => {
  try {
    const { id, authorId, authorName, content, language, translation, imageUri, likes, comments, createdAt } = req.body;
    if (!authorId || !authorName || !content) {
      return res.status(400).json({ error: "authorId, authorName and content are required" });
    }
    const [post] = await db.insert(postsTable).values({
      id: id || `post_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      authorId,
      authorName,
      content,
      language: language || "fr",
      translation: translation || null,
      imageUri: imageUri || null,
      likes: (likes as string[]) || [],
      comments: (comments as CommentData[]) || [],
      createdAt: createdAt ? new Date(createdAt) : new Date(),
    }).onConflictDoNothing().returning();
    if (!post) {
      const [existing] = await db.select().from(postsTable).where(eq(postsTable.id, id));
      return res.status(201).json(serializePost(existing));
    }
    res.status(201).json(serializePost(post));
  } catch (err) {
    req.log.error({ err }, "POST /posts failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// PATCH /api/posts/:id
router.patch("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const { likes, comments } = req.body;
    const updateData: Partial<typeof postsTable.$inferInsert> = {};
    if (likes !== undefined) updateData.likes = likes as string[];
    if (comments !== undefined) updateData.comments = comments as CommentData[];
    if (Object.keys(updateData).length === 0) {
      return res.status(400).json({ error: "Nothing to update" });
    }
    const [updated] = await db.update(postsTable).set(updateData).where(eq(postsTable.id, id)).returning();
    if (!updated) return res.status(404).json({ error: "Post not found" });
    res.json(serializePost(updated));
  } catch (err) {
    req.log.error({ err }, "PATCH /posts/:id failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

// DELETE /api/posts/:id
router.delete("/:id", async (req, res) => {
  try {
    await db.delete(postsTable).where(eq(postsTable.id, req.params.id));
    res.json({ success: true });
  } catch (err) {
    req.log.error({ err }, "DELETE /posts/:id failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
