import { Router, type IRouter } from "express";
import healthRouter from "./health";
import chatRouter from "./chat";
import commentsRouter from "./comments";
import postsRouter from "./posts";
import usersRouter from "./users";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/messages", chatRouter);
router.use("/posts", postsRouter);
router.use("/users", usersRouter);
router.use(commentsRouter);

export default router;
