
import express, { Request, Response } from 'express';
import cors from 'cors';
import pg from 'pg';

const { Pool } = pg;

// Types pour notre application
interface User {
  id: number;
  name: string;
  email: string;
  created_at: Date;
}

interface Post {
  id: number;
  author_id: number;
  author_name: string;
  content: string;
  language: string;
  translation?: string;
  image_uri?: string;
  created_at: Date;
  like_count?: number;
}

interface Like {
  post_id: number;
  user_id: number;
  liked_at: Date;
}

interface Comment {
  id: number;
  post_id: number;
  author_id: number;
  author_name: string;
  content: string;
  created_at: Date;
}

const pool = new Pool({
  connectionString: 'postgresql://postgres:password@helium/heliumdb?sslmode=disable'
});

const app = express();
app.use(cors());
app.use(express.json());

// ============================================
// ROUTES POUR LES POSTS
// ============================================

// GET /posts - Récupérer tous les posts
app.get('/posts', async (req: Request, res: Response) => {
  try {
    const result = await pool.query(`
      SELECT p.*, 
             COALESCE((SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id), 0) as like_count
      FROM posts p 
      ORDER BY p.created_at DESC
    `);
    res.json(result.rows as Post[]);
  } catch (error) {
    console.error('Erreur GET /posts:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des posts' });
  }
});

// POST /posts - Créer un nouveau post
app.post('/posts', async (req: Request, res: Response) => {
  try {
    const { author_id, author_name, content, language, translation, image_uri } = req.body;

    // Validation
    if (!author_id || !author_name || !content) {
      return res.status(400).json({ error: 'author_id, author_name et content sont requis' });
    }

    const result = await pool.query(
      `INSERT INTO posts (author_id, author_name, content, language, translation, image_uri, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, NOW())
       RETURNING *`,
      [author_id, author_name, content, language || 'fr', translation || null, image_uri || null]
    );

    const newPost = result.rows[0] as Post;
    res.status(201).json({ ...newPost, like_count: 0 });
  } catch (error) {
    console.error('Erreur POST /posts:', error);
    res.status(500).json({ error: 'Erreur lors de la création du post' });
  }
});

// ============================================
// ROUTES POUR LES LIKES
// ============================================

// POST /posts/:id/like - Liker ou unliker un post
app.post('/posts/:id/like', async (req: Request, res: Response) => {
  const postId = parseInt(req.params.id);
  const { user_id } = req.body;

  if (isNaN(postId)) {
    return res.status(400).json({ error: 'ID du post invalide' });
  }

  if (!user_id) {
    return res.status(400).json({ error: 'user_id est requis' });
  }

  try {
    // Vérifier si le post existe
    const postExists = await pool.query('SELECT id FROM posts WHERE id = $1', [postId]);
    if (postExists.rows.length === 0) {
      return res.status(404).json({ error: 'Post non trouvé' });
    }

    // Vérifier si déjà liké
    const likeExists = await pool.query(
      'SELECT * FROM likes WHERE post_id = $1 AND user_id = $2',
      [postId, user_id]
    );

    let action: 'liked' | 'unliked';

    if (likeExists.rows.length > 0) {
      // Unlike
      await pool.query('DELETE FROM likes WHERE post_id = $1 AND user_id = $2', [postId, user_id]);
      action = 'unliked';
    } else {
      // Like
      await pool.query('INSERT INTO likes (post_id, user_id, liked_at) VALUES ($1, $2, NOW())', [postId, user_id]);
      action = 'liked';
    }

    // Compter les likes du post
    const likeCount = await pool.query('SELECT COUNT(*) FROM likes WHERE post_id = $1', [postId]);

    res.json({ 
      action, 
      likes: parseInt(likeCount.rows[0].count),
      post_id: postId,
      user_id
    });
  } catch (error) {
    console.error('Erreur POST /posts/:id/like:', error);
    res.status(500).json({ error: 'Erreur lors du like/unlike' });
  }
});

// ============================================
// ROUTES POUR LES COMMENTAIRES
// ============================================

// POST /posts/:id/comments - Ajouter un commentaire
app.post('/posts/:id/comments', async (req: Request, res: Response) => {
  const postId = parseInt(req.params.id);
  const { author_id, author_name, content } = req.body;

  if (isNaN(postId)) {
    return res.status(400).json({ error: 'ID du post invalide' });
  }

  if (!author_id || !author_name || !content) {
    return res.status(400).json({ error: 'author_id, author_name et content sont requis' });
  }

  try {
    // Vérifier si le post existe
    const postExists = await pool.query('SELECT id FROM posts WHERE id = $1', [postId]);
    if (postExists.rows.length === 0) {
      return res.status(404).json({ error: 'Post non trouvé' });
    }

    const result = await pool.query(
      `INSERT INTO comments (post_id, author_id, author_name, content, created_at)
       VALUES ($1, $2, $3, $4, NOW())
       RETURNING *`,
      [postId, author_id, author_name, content]
    );

    res.status(201).json(result.rows[0] as Comment);
  } catch (error) {
    console.error('Erreur POST /posts/:id/comments:', error);
    res.status(500).json({ error: 'Erreur lors de l\'ajout du commentaire' });
  }
});

// GET /posts/:id/comments - Récupérer les commentaires d'un post
app.get('/posts/:id/comments', async (req: Request, res: Response) => {
  const postId = parseInt(req.params.id);

  if (isNaN(postId)) {
    return res.status(400).json({ error: 'ID du post invalide' });
  }

  try {
    const result = await pool.query(
      'SELECT * FROM comments WHERE post_id = $1 ORDER BY created_at DESC',
      [postId]
    );
    res.json(result.rows as Comment[]);
  } catch (error) {
    console.error('Erreur GET /posts/:id/comments:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération des commentaires' });
  }
});

// ============================================
// ROUTES POUR LES UTILISATEURS
// ============================================

// POST /users - Inscription ou connexion
app.post('/users', async (req: Request, res: Response) => {
  const { name, email } = req.body;

  if (!email) {
    return res.status(400).json({ error: 'email est requis' });
  }

  try {
    // Chercher l'utilisateur existant
    let result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    let user = result.rows[0] as User | undefined;

    // Créer un nouvel utilisateur si nécessaire
    if (!user && name) {
      result = await pool.query(
        'INSERT INTO users (name, email, created_at) VALUES ($1, $2, NOW()) RETURNING *',
        [name, email]
      );
      user = result.rows[0];
    }

    if (user) {
      res.json({ success: true, user });
    } else {
      res.status(404).json({ success: false, error: 'Utilisateur non trouvé' });
    }
  } catch (error) {
    console.error('Erreur POST /users:', error);
    res.status(500).json({ error: 'Erreur lors du traitement utilisateur' });
  }
});

// GET /users/:id - Récupérer un utilisateur par son ID
app.get('/users/:id', async (req: Request, res: Response) => {
  const userId = parseInt(req.params.id);

  if (isNaN(userId)) {
    return res.status(400).json({ error: 'ID utilisateur invalide' });
  }

  try {
    const result = await pool.query('SELECT id, name, email, created_at FROM users WHERE id = $1', [userId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Utilisateur non trouvé' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Erreur GET /users/:id:', error);
    res.status(500).json({ error: 'Erreur lors de la récupération de l\'utilisateur' });
  }
});

// ============================================
// ROUTE DE TEST
// ============================================

app.get('/', (req: Request, res: Response) => {
  res.json({
    message: '✅ API PostgreSQL avec TypeScript',
    endpoints: {
      posts: 'GET /posts, POST /posts',
      likes: 'POST /posts/:id/like',
      comments: 'GET /posts/:id/comments, POST /posts/:id/comments',
      users: 'POST /users, GET /users/:id'
    }
  });
});

// ============================================
// DÉMARRAGE DU SERVEUR
// ============================================

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Serveur TypeScript sur le port ${PORT}`);
  console.log(`📊 Tables disponibles: users, posts, likes, comments`);
  console.log(`📝 Exemple: POST /posts avec { author_id, author_name, content }`);
});
