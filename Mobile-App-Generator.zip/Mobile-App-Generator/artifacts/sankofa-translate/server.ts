import express from 'express';
import cors from 'cors';
import pg from 'pg';

const { Pool } = pg;

const pool = new Pool({
  connectionString: 'postgresql://postgres:password@helium/heliumdb?sslmode=disable'
});

const app = express();
app.use(cors());
app.use(express.json());

// GET /posts - Récupérer tous les posts
app.get('/posts', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT p.*, 
             COALESCE((SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id), 0) as like_count
      FROM posts p 
      ORDER BY p.created_at DESC
    `);
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

// POST /posts - Créer un post
app.post('/posts', async (req, res) => {
  const { author_id, author_name, content, language, translation, image_uri } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO posts (author_id, author_name, content, language, translation, image_uri, created_at)
       VALUES ($1, $2, $3, $4, $5, $6, NOW())
       RETURNING *`,
      [author_id, author_name, content, language || 'fr', translation || null, image_uri || null]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

// POST /posts/:id/like - Liker un post
app.post('/posts/:id/like', async (req, res) => {
  const postId = parseInt(req.params.id);
  const { user_id } = req.body;
  
  try {
    const check = await pool.query('SELECT * FROM likes WHERE post_id = $1 AND user_id = $2', [postId, user_id]);
    
    if (check.rows.length > 0) {
      await pool.query('DELETE FROM likes WHERE post_id = $1 AND user_id = $2', [postId, user_id]);
    } else {
      await pool.query('INSERT INTO likes (post_id, user_id) VALUES ($1, $2)', [postId, user_id]);
    }
    
    const count = await pool.query('SELECT COUNT(*) FROM likes WHERE post_id = $1', [postId]);
    res.json({ likes: parseInt(count.rows[0].count) });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

// POST /posts/:id/comments - Ajouter un commentaire
app.post('/posts/:id/comments', async (req, res) => {
  const postId = parseInt(req.params.id);
  const { author_id, author_name, content } = req.body;
  
  try {
    const result = await pool.query(
      `INSERT INTO comments (post_id, author_id, author_name, content, created_at)
       VALUES ($1, $2, $3, $4, NOW())
       RETURNING *`,
      [postId, author_id, author_name, content]
    );
    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

// GET /posts/:id/comments - Récupérer les commentaires
app.get('/posts/:id/comments', async (req, res) => {
  const postId = parseInt(req.params.id);
  try {
    const result = await pool.query('SELECT * FROM comments WHERE post_id = $1 ORDER BY created_at DESC', [postId]);
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

// POST /users - Inscription/connexion
app.post('/users', async (req, res) => {
  const { name, email } = req.body;
  try {
    let result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
    let user = result.rows[0];
    
    if (!user && name) {
      result = await pool.query('INSERT INTO users (name, email) VALUES ($1, $2) RETURNING *', [name, email]);
      user = result.rows[0];
    }
    
    res.json({ success: true, user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message });
  }
});

app.get('/', (req, res) => {
  res.send('✅ API PostgreSQL avec TypeScript');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Serveur sur le port ${PORT}`);
});
