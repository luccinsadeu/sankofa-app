// data/db.ts

// ============ TYPES ============
export interface VocabEntry {
  word: string;
  translation: string;
  pronunciation?: string;
  example?: string;
}

export interface CultureQuestion {
  tier: 0 | 1 | 2;
  question: string;
  options: string[];
  correctIndex: number;
}

export interface Phrase {
  tier: 0 | 1 | 2;
  words: string[];
  correctOrder: number[];
  translation: string;
}

// ============ VOCABULAIRE ============
// Swahili (50 mots par palier – extraits)
export const VOCAB_DB: Record<string, Record<number, VocabEntry[]>> = {
  sw: {
    0: [
      { word: "habari", translation: "bonjour/nouvelles" },
      { word: "asante", translation: "merci" },
      { word: "tafadhali", translation: "s'il vous plaît" },
      { word: "karibu", translation: "bienvenue" },
      { word: "kwaheri", translation: "au revoir" },
      { word: "pole", translation: "désolé" },
      { word: "chakula", translation: "nourriture" },
      { word: "maji", translation: "eau" },
      { word: "rafiki", translation: "ami" },
      { word: "mama", translation: "mère" },
      { word: "baba", translation: "père" },
      { word: "mtoto", translation: "enfant" },
      { word: "paka", translation: "chat" },
      { word: "mbwa", translation: "chien" },
      { word: "nyumba", translation: "maison" },
      { word: "shule", translation: "école" },
      { word: "jua", translation: "soleil" },
      { word: "mvua", translation: "pluie" },
      { word: "ndiyo", translation: "oui" },
      { word: "hapana", translation: "non" },
      { word: "mtu", translation: "personne" },
      { word: "mke", translation: "femme/épouse" },
      { word: "mume", translation: "mari" },
      { word: "nyama", translation: "viande" },
      { word: "samaki", translation: "poisson" },
      { word: "matunda", translation: "fruits" },
      { word: "mboga", translation: "légumes" },
      { word: "mkate", translation: "pain" },
      { word: "maziwa", translation: "lait" },
      { word: "mchele", translation: "riz" },
      { word: "ndizi", translation: "banane" },
      { word: "embe", translation: "mangue" },
      { word: "simba", translation: "lion" },
      { word: "tembo", translation: "éléphant" },
      { word: "ndege", translation: "oiseau/avion" },
      { word: "soko", translation: "marché" },
      { word: "duka", translation: "magasin" },
      { word: "barabara", translation: "route" },
      { word: "mto", translation: "rivière" },
      { word: "mlima", translation: "montagne" },
      { word: "jina", translation: "nom" },
      { word: "nchi", translation: "pays" },
      { word: "lugha", translation: "langue" },
      { word: "elimu", translation: "éducation" },
      { word: "afya", translation: "santé" },
      { word: "kazi", translation: "travail" },
      { word: "pesa", translation: "argent" },
      { word: "bei", translation: "prix" },
      { word: "saa", translation: "heure/montre" },
      { word: "wiki", translation: "semaine" }
    ],
    1: [
      { word: "mwalimu", translation: "professeur" },
      { word: "daktari", translation: "médecin" },
      { word: "polisi", translation: "policier" },
      { word: "mhandisi", translation: "ingénieur" },
      { word: "mkulima", translation: "agriculteur" },
      { word: "hospitali", translation: "hôpital" },
      { word: "kanisa", translation: "église" },
      { word: "msikiti", translation: "mosquée" },
      { word: "benki", translation: "banque" },
      { word: "posta", translation: "poste" },
      { word: "gari", translation: "voiture" },
      { word: "basi", translation: "bus" },
      { word: "meli", translation: "bateau" },
      { word: "bahari", translation: "mer/océan" },
      { word: "pwani", translation: "côte/plage" },
      { word: "msitu", translation: "forêt" },
      { word: "jangwa", translation: "désert" },
      { word: "shamba", translation: "ferme/champ" },
      { word: "mji", translation: "ville" },
      { word: "kijiji", translation: "village" },
      { word: "serikali", translation: "gouvernement" },
      { word: "elimu", translation: "éducation" },
      { word: "afya", translation: "santé" },
      { word: "kazi", translation: "travail" },
      { word: "pesa", translation: "argent" },
      { word: "bei", translation: "prix" },
      { word: "saa", translation: "heure" },
      { word: "wiki", translation: "semaine" },
      { word: "mwaka", translation: "année" },
      { word: "kesho", translation: "demain" },
      { word: "jana", translation: "hier" },
      { word: "leo", translation: "aujourd'hui" },
      { word: "usiku", translation: "nuit" },
      { word: "asubuhi", translation: "matin" },
      { word: "jioni", translation: "soir" },
      { word: "chakari", translation: "cuisinier" },
      { word: "mzigo", translation: "bagage" },
      { word: "safari", translation: "voyage" },
      { word: "upendo", translation: "amour" },
      { word: "imani", translation: "foi" },
      { word: "nguvu", translation: "force" },
      { word: "akili", translation: "intelligence" },
      { word: "moyo", translation: "cœur" },
      { word: "roho", translation: "âme" },
      { word: "ndoto", translation: "rêve" },
      { word: "maisha", translation: "vie" },
      { word: "uzuri", translation: "beauté" },
      { word: "ukweli", translation: "vérité" },
      { word: "busara", translation: "sagesse" },
      { word: "subira", translation: "patience" }
    ],
    2: [
      { word: "uhuru", translation: "liberté" },
      { word: "amani", translation: "paix" },
      { word: "haki", translation: "justice" },
      { word: "urafiki", translation: "amitié" },
      { word: "undugu", translation: "fraternité" },
      { word: "umoja", translation: "unité" },
      { word: "utamaduni", translation: "culture" },
      { word: "historia", translation: "histoire" },
      { word: "sanaa", translation: "art" },
      { word: "muziki", translation: "musique" },
      { word: "michezo", translation: "sport" },
      { word: "sayansi", translation: "science" },
      { word: "teknolojia", translation: "technologie" },
      { word: "mazingira", translation: "environnement" },
      { word: "hali ya hewa", translation: "climat" },
      { word: "uchumi", translation: "économie" },
      { word: "siasa", translation: "politique" },
      { word: "dini", translation: "religion" },
      { word: "mila", translation: "tradition" },
      { word: "sherehe", translation: "fête" },
      { word: "harusi", translation: "mariage" },
      { word: "mazishi", translation: "funérailles" },
      { word: "ibada", translation: "culte" },
      { word: "shukrani", translation: "gratitude" },
      { word: "msamaha", translation: "pardon" },
      { word: "huruma", translation: "compassion" },
      { word: "busara", translation: "sagesse" },
      { word: "subira", translation: "patience" },
      { word: "ukweli", translation: "vérité" },
      { word: "uongo", translation: "mensonge" },
      { word: "upendo", translation: "amour" },
      { word: "imani", translation: "foi" },
      { word: "nguvu", translation: "force" },
      { word: "akili", translation: "intelligence" },
      { word: "moyo", translation: "cœur" },
      { word: "roho", translation: "âme" },
      { word: "ndoto", translation: "rêve" },
      { word: "maisha", translation: "vie" },
      { word: "kifo", translation: "mort" },
      { word: "uzuri", translation: "beauté" },
      { word: "utajiri", translation: "richesse" },
      { word: "umaskini", translation: "pauvreté" },
      { word: "ujuzi", translation: "compétence" },
      { word: "ustadi", translation: "expertise" },
      { word: "uadilifu", translation: "intégrité" },
      { word: "uaminifu", translation: "honnêteté" },
      { word: "ujasiri", translation: "courage" },
      { word: "uvumilivu", translation: "tolérance" },
      { word: "upole", translation: "douceur" },
      { word: "unyenyekevu", translation: "humilité" }
    ]
  },
  // Lingala (structure similaire, 50 mots par palier – extraits)
  ln: {
    0: [
      { word: "mbote", translation: "bonjour" },
      { word: "nalingi", translation: "j'aime" },
      { word: "malamu", translation: "bien" },
      { word: "merci", translation: "merci" },
      { word: "oyo", translation: "ceci/cela" },
      { word: "ndako", translation: "maison" },
      { word: "motu", translation: "personne" },
      { word: "mwasi", translation: "femme" },
      { word: "mobali", translation: "homme" },
      { word: "mwana", translation: "enfant" },
      // ... 40 autres mots (raccourci pour lisibilité)
    ],
    1: [ /* 50 mots */ ],
    2: [ /* 50 mots */ ]
  },
  // Yoruba
  yo: {
    0: [
      { word: "bawo ni", translation: "comment vas-tu" },
      { word: "o se", translation: "merci" },
      // ... 48 autres
    ],
    1: [],
    2: []
  },
  // Haoussa
  ha: {
    0: [
      { word: "sannu", translation: "bonjour" },
      // ...
    ],
    1: [],
    2: []
  },
  // Zoulou
  zu: {
    0: [
      { word: "sawubona", translation: "bonjour" },
      // ...
    ],
    1: [],
    2: []
  }
};

// ============ CULTURE (5 questions par palier) ============
export const CULTURE_DB: Record<string, CultureQuestion[]> = {
  sw: [
    { tier: 0, question: "Dans quel pays le swahili est-il langue officielle ?", options: ["Tanzanie", "Nigeria", "Ghana", "Sénégal"], correctIndex: 0 },
    { tier: 0, question: "Que signifie 'Hakuna Matata' ?", options: ["Pas de problème", "Au revoir", "Bon appétit", "Bonne nuit"], correctIndex: 0 },
    { tier: 0, question: "Quel animal est emblématique en Tanzanie ?", options: ["Lion", "Girafe", "Zèbre", "Tous"], correctIndex: 3 },
    { tier: 0, question: "Quelle île de Tanzanie est célèbre pour ses épices ?", options: ["Zanzibar", "Mafia", "Pemba", "Kilwa"], correctIndex: 0 },
    { tier: 0, question: "Quel est le plus haut sommet d'Afrique ?", options: ["Kilimandjaro", "Mont Kenya", "Rwenzori", "Simien"], correctIndex: 0 },
    { tier: 1, question: "Qui a écrit 'L'Orgueil du lion' en swahili ?", options: ["Shaaban Robert", "Euphrase Kezilahabi", "Abdulrazak Gurnah", "Ngũgĩ"], correctIndex: 0 },
    { tier: 1, question: "Le mot 'safari' vient du swahili. Que signifie-t-il ?", options: ["Voyage", "Chasse", "Aventure", "Découverte"], correctIndex: 0 },
    { tier: 1, question: "Quel est le plat national de Tanzanie ?", options: ["Ugali", "Nyama choma", "Pilau", "Samoussas"], correctIndex: 0 },
    { tier: 1, question: "Quel instrument est typique du swahili ?", options: ["Zeze", "Djembe", "Kora", "Balafon"], correctIndex: 0 },
    { tier: 1, question: "Quelle danse est traditionnelle swahili ?", options: ["Chakacha", "Soukous", "Mbalax", "Gwara gwara"], correctIndex: 0 },
    { tier: 2, question: "Quel écrivain tanzanien a obtenu le Prix Nobel ?", options: ["Abdulrazak Gurnah", "Wole Soyinka", "Nadine Gordimer", "J.M. Coetzee"], correctIndex: 0 },
    { tier: 2, question: "Quel film a popularisé 'Hakuna Matata' ?", options: ["Le Roi Lion", "Madagascar", "Out of Africa", "The Lion King"], correctIndex: 0 },
    { tier: 2, question: "Quel bateau traditionnel swahili ?", options: ["Dhow", "Canoë", "Pirogue", "Galion"], correctIndex: 0 },
    { tier: 2, question: "Monnaie de la Tanzanie ?", options: ["Shilling tanzanien", "Franc CFA", "Rand", "Naira"], correctIndex: 0 },
    { tier: 2, question: "Site UNESCO swahili ?", options: ["Kilwa Kisiwani", "Dar es Salaam", "Mombasa", "Lamu"], correctIndex: 0 }
  ],
  ln: [
    { tier: 0, question: "Dans quel pays parle-t-on lingala ?", options: ["RDC", "Cameroun", "Sénégal", "Côte d'Ivoire"], correctIndex: 0 },
    { tier: 0, question: "Que signifie 'Mbote' ?", options: ["Bonjour", "Merci", "Au revoir", "S'il vous plaît"], correctIndex: 0 },
    { tier: 0, question: "Quel fleuve traverse Kinshasa ?", options: ["Congo", "Niger", "Nil", "Zambèze"], correctIndex: 0 },
    { tier: 0, question: "Capitale de la RDC ?", options: ["Kinshasa", "Brazzaville", "Lubumbashi", "Kisangani"], correctIndex: 0 },
    { tier: 0, question: "Musicien de rumba congolaise ?", options: ["Papa Wemba", "Fally Ipupa", "Koffi Olomide", "Tabu Ley"], correctIndex: 0 },
    // ... 10 autres (tiers 1 et 2)
  ],
  // Même chose pour yo, ha, zu (à compléter)
};

// ============ PHRASES (5 par palier) ============
export const PHRASES_DB: Record<string, Phrase[]> = {
  sw: [
    { tier: 0, words: ["Nakupenda", "sana"], correctOrder: [0,1], translation: "Je t'aime beaucoup" },
    { tier: 0, words: ["Habari", "yako"], correctOrder: [0,1], translation: "Comment vas-tu ?" },
    { tier: 0, words: ["Asante", "sana"], correctOrder: [0,1], translation: "Merci beaucoup" },
    { tier: 0, words: ["Tafadhali", "njoo"], correctOrder: [0,1], translation: "S'il te plaît, viens" },
    { tier: 0, words: ["Nina", "nyumba"], correctOrder: [0,1], translation: "J'ai une maison" },
    { tier: 1, words: ["Ninataka", "kula", "chakula"], correctOrder: [0,1,2], translation: "Je veux manger" },
    { tier: 1, words: ["Wewe", "ni", "mwalimu"], correctOrder: [0,1,2], translation: "Tu es prof" },
    { tier: 1, words: ["Tunaenda", "sokoni"], correctOrder: [0,1], translation: "Nous allons au marché" },
    { tier: 1, words: ["Alinunua", "gari"], correctOrder: [0,1], translation: "Il a acheté une voiture" },
    { tier: 1, words: ["Watoto", "wanacheza"], correctOrder: [0,1], translation: "Les enfants jouent" },
    { tier: 2, words: ["Uhuru", "na", "amani"], correctOrder: [0,1,2], translation: "Liberté et paix" },
    { tier: 2, words: ["Mungu", "bariki", "Afrika"], correctOrder: [0,1,2], translation: "Que Dieu bénisse l'Afrique" },
    { tier: 2, words: ["Tukutane", "kesho"], correctOrder: [0,1], translation: "Rendez-vous demain" },
    { tier: 2, words: ["Nimefurahi", "kukutana", "nawe"], correctOrder: [0,1,2], translation: "Ravi de te rencontrer" },
    { tier: 2, words: ["Soma", "kitabu", "hiki"], correctOrder: [0,1,2], translation: "Lis ce livre" }
  ],
  // ln, yo, ha, zu avec structure similaire (15 chacune)
};