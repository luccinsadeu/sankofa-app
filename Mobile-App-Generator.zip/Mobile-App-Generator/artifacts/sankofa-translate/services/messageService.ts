const API_URL = "http://localhost:3000/api";

export async function sendMessage(fromId: string, toId: string, text: string) {
  const res = await fetch(`${API_URL}/messages`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ fromId, toId, text }),
  });
  return res.json();
}

export async function getMessages(userId: string) {
  const res = await fetch(`${API_URL}/messages?userId=${userId}`);
  return res.json();
}