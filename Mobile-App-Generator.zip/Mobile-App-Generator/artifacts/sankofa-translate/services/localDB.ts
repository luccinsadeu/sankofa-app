// services/localDB.ts
import AsyncStorage from "@react-native-async-storage/async-storage";

const POSTS_FILE = "/home/runner/workspace/artifacts/sankofa-translate/data/posts.json";

// Sur le web (Replit), on utilise le serveur
// Sur mobile, on utilise AsyncStorage
export async function getPosts(): Promise<any[]> {
  if (typeof window !== "undefined") {
    // Web - lire le fichier JSON via fetch
    const response = await fetch("/data/posts.json");
    return response.json();
  } else {
    // Mobile - AsyncStorage
    const saved = await AsyncStorage.getItem("posts");
    return saved ? JSON.parse(saved) : [];
  }
}

export async function savePosts(posts: any[]): Promise<void> {
  const json = JSON.stringify(posts, null, 2);

  if (typeof window !== "undefined") {
    // Web - écrire le fichier JSON via API Replit
    await fetch("/api/save-posts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: json,
    });
  } else {
    // Mobile - AsyncStorage
    await AsyncStorage.setItem("posts", JSON.stringify(posts));
  }
}