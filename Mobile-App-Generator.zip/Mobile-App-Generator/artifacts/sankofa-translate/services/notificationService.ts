// @ts-nocheck
// services/notificationService.ts
// Service de notifications temporairement désactivé (expo-notifications retiré)

export interface NotificationSettings {
  enabled: boolean;
  hour: number;
  minute: number;
  frequency: "daily" | "weekly";
}

export async function getNotificationSettings(): Promise<NotificationSettings> {
  return {
    enabled: false,
    hour: 9,
    minute: 0,
    frequency: "daily",
  };
}

export async function saveNotificationSettings(_settings: NotificationSettings) {
  return { success: true };
}