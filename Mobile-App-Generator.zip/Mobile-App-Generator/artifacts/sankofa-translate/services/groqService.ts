import AsyncStorage from "@react-native-async-storage/async-storage";

// ============================================
// TYPES ET INTERFACES
// ============================================

export type CodeLangue = keyof typeof LANGUAGES;
export type MoteurTraduction = "google" | "groq" | "dictionnaire" | "cache";
export type NiveauFiabilite = "haute" | "moyenne" | "basse" | "inconnue";

export interface ResultatTraduction {
  traduction: string;
  moteur: MoteurTraduction;
  fiabilite: NiveauFiabilite;
  avertissements?: string[];
  sourceVerifiee?: boolean;
  alternatives?: string[];
}

export interface OptionsTraduction {
  contexte?: string;
  exigerVerification?: boolean;
  qualite?: "rapide" | "standard" | "premium";
}

// ============================================
// CONFIGURATION
// ============================================

const GROQ_API_KEY_STORAGE = "@sankofa_groq_key";
const DEFAULT_GROQ_KEY = "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";

export const LANGUAGES: Record<string, string> = {
  fr: "Français",
  en: "Anglais",
  sw: "Swahili",
  ln: "Lingala",
  yo: "Yoruba",
  ha: "Hausa",
  zu: "Zoulou",
  ew: "Ewondo",
  du: "Duala",
  gh: "Ghomala",
  ff: "Fulfulde",
  bu: "Bulu",
  gb: "Gbaya",
};

// Mapping des codes de langue pour Google Translate
const GOOGLE_LANG_CODES: Record<string, string> = {
  fr: "fr",
  en: "en",
  sw: "sw",
  ln: "ln",
  yo: "yo",
  ha: "ha",
  zu: "zu",
  // Langues camerounaises - Google peut ne pas toutes les supporter
  ew: "ewo", // Ewondo
  du: "dua", // Duala
  ff: "ff",  // Fulfulde
  // Fallback pour les non-supportées
  gh: "fr",  // Ghomala -> fallback français
  bu: "fr",  // Bulu -> fallback français
  gb: "fr",  // Gbaya -> fallback français
};

// Langues supportées nativement par Google Translate
const GOOGLE_SUPPORTED = new Set(["fr", "en", "sw", "ln", "yo", "ha", "zu", "ff"]);

// ============================================
// GESTION DES ERREURS
// ============================================

export class ErreurAPI extends Error {
  constructor(
    message: string,
    public statut?: number,
    public code?: string
  ) {
    super(message);
    this.name = 'ErreurAPI';
  }
}

// ============================================
// GESTION DES CLÉS API
// ============================================

let cachedGroqKey: string | null = null;

export async function getGroqApiKey(): Promise<string> {
  if (cachedGroqKey) return cachedGroqKey;
  const stored = await AsyncStorage.getItem(GROQ_API_KEY_STORAGE);
  cachedGroqKey = stored || DEFAULT_GROQ_KEY;
  return cachedGroqKey;
}

export async function saveGroqApiKey(key: string): Promise<void> {
  cachedGroqKey = key;
  await AsyncStorage.setItem(GROQ_API_KEY_STORAGE, key);
}

export async function clearGroqApiKey(): Promise<void> {
  cachedGroqKey = DEFAULT_GROQ_KEY;
  await AsyncStorage.removeItem(GROQ_API_KEY_STORAGE);
}

export async function hasCustomApiKey(): Promise<boolean> {
  const stored = await AsyncStorage.getItem(GROQ_API_KEY_STORAGE);
  return !!stored;
}

export function getLanguageName(code: string): string {
  return LANGUAGES[code] || code.toUpperCase();
}

// ============================================
// MOTEUR GOOGLE TRANSLATE (API NON-OFFICIELLE)
// ============================================

async function traduireViaGoogle(texte: string, src: string, tgt: string): Promise<string> {
  // Vérifier si Google supporte cette langue
  if (!GOOGLE_SUPPORTED.has(tgt) && !GOOGLE_SUPPORTED.has(src)) {
    throw new Error("Langue non supportée par Google Translate");
  }

  const googleSrc = GOOGLE_LANG_CODES[src] || src;
  const googleTgt = GOOGLE_LANG_CODES[tgt] || tgt;

  try {
    // Utilisation de l'API Google Translate (endpoint public)
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${googleSrc}&tl=${googleTgt}&dt=t&q=${encodeURIComponent(texte)}`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      },
    });

    if (!response.ok) {
      throw new Error(`Google API error: ${response.status}`);
    }

    const data = await response.json();

    // Extraire la traduction du format de réponse Google
    let traduction = "";
    if (data && data[0]) {
      for (const segment of data[0]) {
        if (segment[0]) {
          traduction += segment[0];
        }
      }
    }

    if (!traduction) {
      throw new Error("Traduction vide");
    }

    return traduction.trim();

  } catch (error: any) {
    console.warn("Google Translate failed:", error.message);
    throw error;
  }
}

// ============================================
// MOTEUR GROQ (FALLBACK INTELLIGENT)
// ============================================

async function traduireViaGroq(
  texte: string,
  src: string,
  tgt: string,
  options?: { temperature?: number; maxTokens?: number }
): Promise<string> {
  const apiKey = await getGroqApiKey();

  const { temperature = 0.2, maxTokens = 1024 } = options || {};

  // Prompt optimisé selon la langue cible
  let systemPrompt = `Tu es un traducteur professionnel ${LANGUAGES[src]} → ${LANGUAGES[tgt]}. Réponds UNIQUEMENT avec la traduction.`;

  // Prompts spécialisés pour certaines langues
  if (tgt === "ln" || src === "ln") {
    systemPrompt = `Tu es un expert en lingala (RDC/Congo). 
Règles: préfixes mo-/ba-, ki-/bi-, li-/ma-; verbes en ko-; conjugaison: na- (je), o- (tu), a- (il), to- (nous), bo- (vous), ba- (ils).
Exemples: "Je t'aime" = "Nalingi yo", "Je vais" = "Nakei", "Je mange" = "Nazali kolya".
Réponds UNIQUEMENT avec la traduction.`;
  } else if (tgt === "gh" || tgt === "ew" || tgt === "du" || tgt === "bu" || tgt === "gb") {
    systemPrompt = `Tu es un expert en langues camerounaises, particulièrement le ${LANGUAGES[tgt]}.
Traduis avec précision du ${LANGUAGES[src]} vers le ${LANGUAGES[tgt]}.
Conserve le sens exact et le contexte culturel.
Réponds UNIQUEMENT avec la traduction.`;
  } else if (tgt === "sw") {
    systemPrompt = `Tu es un expert en swahili. Utilise les classes nominales correctes (M-/WA-, KI-/VI-, etc.).
Exemples: "Je t'aime" = "Nakupenda", "Comment vas-tu?" = "Habari gani?", "Merci" = "Asante".
Réponds UNIQUEMENT avec la traduction.`;
  }

  const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: texte },
      ],
      temperature,
      max_tokens: maxTokens,
    }),
  });

  if (!response.ok) {
    const err = await response.json().catch(() => ({}));
    throw new ErreurAPI(
      (err as any)?.error?.message || `Groq API error: ${response.status}`,
      response.status
    );
  }

  const data = await response.json() as any;
  let traduction = data.choices?.[0]?.message?.content?.trim() || "";

  // Nettoyage
  traduction = traduction
    .replace(/^["']|["']$/g, '')
    .replace(/^(Traduction|Translation|En .*?)\s*:\s*/i, '')
    .trim();

  return traduction;
}

// ============================================
// CACHE SIMPLE POUR LES TRADUCTIONS
// ============================================

interface CacheEntry {
  traduction: string;
  moteur: MoteurTraduction;
  timestamp: number;
}

const translationCache = new Map<string, CacheEntry>();
const CACHE_TTL = 1000 * 60 * 60 * 24; // 24 heures

function getCacheKey(texte: string, src: string, tgt: string): string {
  return `${src}:${tgt}:${texte.toLowerCase().trim()}`;
}

function getFromCache(texte: string, src: string, tgt: string): CacheEntry | null {
  const key = getCacheKey(texte, src, tgt);
  const entry = translationCache.get(key);

  if (entry && Date.now() - entry.timestamp < CACHE_TTL) {
    return entry;
  }

  if (entry) {
    translationCache.delete(key);
  }

  return null;
}

function setToCache(texte: string, src: string, tgt: string, traduction: string, moteur: MoteurTraduction): void {
  const key = getCacheKey(texte, src, tgt);
  translationCache.set(key, {
    traduction,
    moteur,
    timestamp: Date.now(),
  });

  // Limiter la taille du cache
  if (translationCache.size > 100) {
    const firstKey = translationCache.keys().next().value;
    if (firstKey) {
      translationCache.delete(firstKey);
    }
  }
}

// ============================================
// FONCTION MAÎTRESSE (FUSION GOOGLE + GROQ)
// ============================================

export async function traduire(
  texte: string,
  langueSource: string,
  langueCible: string,
  options: OptionsTraduction = {}
): Promise<{
  traduction: string;
  fiable: boolean;
  moteur: MoteurTraduction;
  fiabilite: NiveauFiabilite;
  avertissement?: string;
}> {

  // Validation
  if (!texte?.trim()) {
    return { 
      traduction: "", 
      fiable: true, 
      moteur: "dictionnaire", 
      fiabilite: "haute" 
    };
  }

  // Vérifier le cache
  const cached = getFromCache(texte, langueSource, langueCible);
  if (cached) {
    console.log(`[Cache] Traduction trouvée (${cached.moteur})`);
    return {
      traduction: cached.traduction,
      fiable: cached.moteur === "google",
      moteur: cached.moteur,
      fiabilite: cached.moteur === "google" ? "haute" : "moyenne",
    };
  }

  const estLangueSupporteeGoogle = GOOGLE_SUPPORTED.has(langueCible) && GOOGLE_SUPPORTED.has(langueSource);

  // STRATÉGIE 1: Google Translate (prioritaire pour les langues supportées)
  if (estLangueSupporteeGoogle) {
    try {
      console.log(`[Google] Traduction ${langueSource} → ${langueCible}`);
      const traduction = await traduireViaGoogle(texte, langueSource, langueCible);

      if (traduction && traduction.length > 0) {
        setToCache(texte, langueSource, langueCible, traduction, "google");

        return {
          traduction,
          fiable: true,
          moteur: "google",
          fiabilite: "haute",
        };
      }
    } catch (error: any) {
      console.warn(`[Google] Échec, fallback vers Groq:`, error.message);
      // Continuer vers Groq
    }
  }

  // STRATÉGIE 2: Groq (fallback pour toutes les langues)
  try {
    console.log(`[Groq] Traduction ${langueSource} → ${langueCible}`);

    // Ajuster la température selon la qualité demandée
    const temperature = options.qualite === "premium" ? 0.1 : 
                       options.qualite === "rapide" ? 0.5 : 0.2;

    const traduction = await traduireViaGroq(texte, langueSource, langueCible, { temperature });

    // Déterminer la fiabilité
    let fiabilite: NiveauFiabilite = "moyenne";
    let avertissement: string | undefined;

    const estLingala = langueCible === "ln" || langueSource === "ln";
    const estCamerounaise = ["gh", "ew", "du", "bu", "gb"].includes(langueCible);

    if (estLingala) {
      fiabilite = "moyenne";
      avertissement = "ℹ️ Traduction lingala générée par IA. Vérifiez avec un locuteur natif.";
    } else if (estCamerounaise) {
      fiabilite = "moyenne";
      avertissement = "⚠️ Langue camerounaise - Traduction IA, vérifiez avec un locuteur natif.";
    } else if (options.qualite === "premium") {
      fiabilite = "haute";
    }

    setToCache(texte, langueSource, langueCible, traduction, "groq");

    return {
      traduction,
      fiable: fiabilite === "haute",
      moteur: "groq",
      fiabilite,
      avertissement,
    };

  } catch (error: any) {
    console.error("[Erreur] Traduction impossible:", error.message);

    return {
      traduction: `[⚠️ Erreur de traduction]`,
      fiable: false,
      moteur: "groq",
      fiabilite: "basse",
      avertissement: "Service de traduction indisponible. Vérifiez votre connexion.",
    };
  }
}

// ============================================
// TRADUCTION PAR LOT (BATCH)
// ============================================

export async function traduireLot(
  textes: string[],
  langueSource: string,
  langueCible: string
): Promise<Array<{ traduction: string; moteur: MoteurTraduction }>> {
  const resultats: Array<{ traduction: string; moteur: MoteurTraduction }> = [];

  for (const texte of textes) {
    try {
      const resultat = await traduire(texte, langueSource, langueCible);
      resultats.push({
        traduction: resultat.traduction,
        moteur: resultat.moteur,
      });
    } catch (error) {
      resultats.push({
        traduction: `[Erreur] ${texte}`,
        moteur: "groq",
      });
    }
  }

  return resultats;
}

// ============================================
// DÉTECTION DE LANGUE
// ============================================

export async function detecterLangue(texte: string): Promise<{ code: string; confiance: number }> {
  try {
    // Utiliser Groq pour la détection
    const apiKey = await getGroqApiKey();

    const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "llama-3.3-70b-versatile",
        messages: [
          {
            role: "system",
            content: `Détecte la langue de ce texte. Réponds UNIQUEMENT avec le code ISO 639-1 parmi: ${Object.keys(LANGUAGES).join(", ")}.`,
          },
          { role: "user", content: texte },
        ],
        temperature: 0.1,
        max_tokens: 10,
      }),
    });

    const data = await response.json();
    const code = data.choices?.[0]?.message?.content?.trim().toLowerCase() || "fr";

    return {
      code: LANGUAGES[code] ? code : "fr",
      confiance: 0.8,
    };
  } catch (error) {
    return { code: "fr", confiance: 0.5 };
  }
}

// ============================================
// SIGNALEMENT D'ERREUR (POUR AMÉLIORATION)
// ============================================

export async function signalerTraductionIncorrecte(
  texte: string,
  mauvaiseTraduction: string,
  correction: string,
  langueSource: string,
  langueCible: string,
  raison: string
): Promise<void> {
  try {
    const signalements = await AsyncStorage.getItem("@sankofa_signalements");
    const liste = signalements ? JSON.parse(signalements) : [];

    liste.push({
      texte,
      mauvaiseTraduction,
      correction,
      langueSource,
      langueCible,
      raison,
      date: Date.now(),
    });

    // Garder les 50 derniers signalements
    if (liste.length > 50) {
      liste.shift();
    }

    await AsyncStorage.setItem("@sankofa_signalements", JSON.stringify(liste));

    // Mettre à jour le cache avec la correction
    setToCache(texte, langueSource, langueCible, correction, "dictionnaire");

    console.log("✅ Correction enregistrée !");
  } catch (error) {
    console.warn("Erreur lors du signalement:", error);
  }
}

// ============================================
// COMPATIBILITÉ AVEC L'ANCIENNE API
// ============================================

export async function translateText(
  text: string,
  fromLang: string,
  toLang: string
): Promise<{ translation: string; engine: "groq"; alternatives?: string[] }> {
  const resultat = await traduire(text, fromLang, toLang);
  return {
    translation: resultat.traduction,
    engine: "groq",
  };
}

export async function traduireTexteFiable(
  texte: string,
  langueSource: string,
  langueCible: string,
  options: OptionsTraduction = {}
): Promise<ResultatTraduction> {
  const resultat = await traduire(texte, langueSource, langueCible, options);

  return {
    traduction: resultat.traduction,
    moteur: resultat.moteur,
    fiabilite: resultat.fiabilite,
    avertissements: resultat.avertissement ? [resultat.avertissement] : undefined,
    sourceVerifiee: resultat.moteur === "google",
  };
}

// ============================================
// EXPORTS
// ============================================

export const SUPPORTED_LANGUAGES = Object.entries(LANGUAGES).map(([code, name]) => ({
  code,
  name,
}));

export const TRANSLATION_LANGUAGES = SUPPORTED_LANGUAGES.filter(l =>
  ["fr", "en", "sw", "ln", "yo", "ha", "zu", "ew", "du", "gh", "ff", "bu", "gb"].includes(l.code)
);

// Statistiques d'utilisation
export function getCacheStats(): { size: number; entries: Array<{ src: string; tgt: string; moteur: MoteurTraduction }> } {
  const entries: Array<{ src: string; tgt: string; moteur: MoteurTraduction }> = [];

  for (const [key, value] of translationCache.entries()) {
    const [src, tgt] = key.split(':');
    entries.push({ src, tgt, moteur: value.moteur });
  }

  return {
    size: translationCache.size,
    entries,
  };
}

export function clearCache(): void {
  translationCache.clear();
  console.log("✅ Cache de traduction vidé");
}

// ============================================
// EXPORT PAR DÉFAUT
// ============================================

export default {
  traduire,
  traduireLot,
  traduireTexteFiable,
  detecterLangue,
  signalerTraductionIncorrecte,
  translateText,
  getGroqApiKey,
  saveGroqApiKey,
  clearGroqApiKey,
  hasCustomApiKey,
  getLanguageName,
  getCacheStats,
  clearCache,
  LANGUAGES,
  SUPPORTED_LANGUAGES,
  TRANSLATION_LANGUAGES,
};