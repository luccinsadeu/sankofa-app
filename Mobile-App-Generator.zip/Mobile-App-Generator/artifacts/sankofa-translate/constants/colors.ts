const colors = {
  light: {
    text: "#1a0a00",
    tint: "#B8860B",

    background: "#FDF8F0",
    foreground: "#1a0a00",

    card: "#FFFFFF",
    cardForeground: "#1a0a00",

    primary: "#1B5E20",
    primaryForeground: "#FFFFFF",

    secondary: "#FFF8E1",
    secondaryForeground: "#3E2723",

    muted: "#F5EFDF",
    mutedForeground: "#8D6E63",

    accent: "#B8860B",
    accentForeground: "#FFFFFF",

    destructive: "#C62828",
    destructiveForeground: "#FFFFFF",

    border: "#E8D5B0",
    input: "#E8D5B0",

    gold: "#D4A017",
    terracotta: "#C1440E",
    deepGreen: "#1B5E20",
    midGreen: "#2E7D32",
    lightGreen: "#4CAF50",
    cream: "#FDF8F0",
    warmWhite: "#FFFDF7",
    darkBrown: "#3E2723",
    mediumBrown: "#6D4C41",
    lightBrown: "#BCAAA4",
  },
  dark: {
    text: "#F5F0E8",
    tint: "#D4A017",

    background: "#0D1B0E",
    foreground: "#F5F0E8",

    card: "#1A2B1B",
    cardForeground: "#F5F0E8",

    primary: "#4CAF50",
    primaryForeground: "#0D1B0E",

    secondary: "#1F3320",
    secondaryForeground: "#D4A017",

    muted: "#1A2B1B",
    mutedForeground: "#9E8E7A",

    accent: "#D4A017",
    accentForeground: "#0D1B0E",

    destructive: "#EF5350",
    destructiveForeground: "#FFFFFF",

    border: "#2A3D2B",
    input: "#2A3D2B",

    gold: "#D4A017",
    terracotta: "#E05C2A",
    deepGreen: "#4CAF50",
    midGreen: "#66BB6A",
    lightGreen: "#A5D6A7",
    cream: "#F5F0E8",
    warmWhite: "#1A2B1B",
    darkBrown: "#BCAAA4",
    mediumBrown: "#A1887F",
    lightBrown: "#6D4C41",
  },

  radius: 12,
};

export default colors;
