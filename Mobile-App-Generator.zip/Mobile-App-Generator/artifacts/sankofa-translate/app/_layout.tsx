import { Stack, useRouter, useSegments } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import React, { useEffect } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { useColorScheme, Platform } from "react-native";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AppProvider, useApp } from "@/context/AppContext";
import { I18nProvider } from "@/context/I18nContext";

// Thème clair
const LIGHT_THEME = {
  background: "#FFFFFF",
  text: "#1A1A1A",
  card: "#F5F5F5",
  primary: "#0D2E0F", // vert foncé Sankofa
  gold: "#D4AF37",
  border: "#E5E5E5",
  mutedForeground: "#6B7280",
  deepGreen: "#0D2E0F",
  midGreen: "#1E4A21",
  destructive: "#EF4444",
};

// Thème sombre
const DARK_THEME = {
  background: "#121212",
  text: "#FFFFFF",
  card: "#1E1E1E",
  primary: "#1E4A21",
  gold: "#D4AF37",
  border: "#2C2C2C",
  mutedForeground: "#9CA3AF",
  deepGreen: "#1E4A21",
  midGreen: "#2E6B32",
  destructive: "#EF4444",
};

SplashScreen.preventAutoHideAsync().catch(() => {});

function RootLayoutNav() {
  const { user, isLoading } = useApp();
  const router = useRouter();
  const segments = useSegments();
  const colorScheme = useColorScheme();
  const colors = colorScheme === "dark" ? DARK_THEME : LIGHT_THEME;

  useEffect(() => {
    if (isLoading) return;
    SplashScreen.hideAsync().catch(() => {});
    const inAuthGroup = segments[0] === "(tabs)";
    if (!user && inAuthGroup) {
      router.replace("/login");
    } else if (user && !inAuthGroup) {
      router.replace("/(tabs)");
    }
  }, [user, isLoading, segments]);

  return (
    <>
      <StatusBar style={colorScheme === "dark" ? "light" : "dark"} backgroundColor={colors.background} />
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: colors.background },
          animation: Platform.OS === "android" ? "slide_from_right" : "default",
        }}
      >
        <Stack.Screen name="index" />
        <Stack.Screen name="welcome" />
        <Stack.Screen name="login" />
        <Stack.Screen name="home" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="settings" options={{ presentation: "card" }} />
        <Stack.Screen name="chat/[id]" />
      </Stack>
    </>
  );
}

export default function RootLayout() {
  const colorScheme = useColorScheme();
  const colors = colorScheme === "dark" ? DARK_THEME : LIGHT_THEME;

  return (
    <SafeAreaProvider>
      <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
        <ErrorBoundary>
          <GestureHandlerRootView style={{ flex: 1 }}>
            <I18nProvider>
              <AppProvider>
                <RootLayoutNav />
              </AppProvider>
            </I18nProvider>
          </GestureHandlerRootView>
        </ErrorBoundary>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}