// app/index.tsx — point d'entrée : vérifie la session et redirige
import AsyncStorage from "@react-native-async-storage/async-storage";
import { router } from "expo-router";
import { useEffect } from "react";
import { ActivityIndicator, View } from "react-native";

export default function Index() {
  useEffect(() => {
    (async () => {
      try {
        const userData = await AsyncStorage.getItem("@sankofa_user");
        const onboarded = await AsyncStorage.getItem("onboardingCompleted");
        if (userData && onboarded === "true") {
          router.replace("/(tabs)");
        } else {
          router.replace("/login");
        }
      } catch {
        router.replace("/login");
      }
    })();
  }, []);

  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center", backgroundColor: "#0d1a0e" }}>
      <ActivityIndicator size="large" color="#52b788" />
    </View>
  );
}
