import React, { useEffect, useRef } from "react";
import {
  Animated,
  Easing,
  Image,
  Platform,
  StyleSheet,
  Text,
  View,
} from "react-native";

interface LoadingScreenProps {
  onFinish?: () => void;
  duration?: number;
}

export default function LoadingScreen({
  onFinish,
  duration = 2800,
}: LoadingScreenProps) {
  const bgOpacity       = useRef(new Animated.Value(0)).current;
  const birdScale       = useRef(new Animated.Value(0.4)).current;
  const birdOpacity     = useRef(new Animated.Value(0)).current;
  const birdY           = useRef(new Animated.Value(30)).current;
  const wingRotate      = useRef(new Animated.Value(0)).current;
  const glowOpacity     = useRef(new Animated.Value(0)).current;
  const glowScale       = useRef(new Animated.Value(0.6)).current;
  const titleOpacity    = useRef(new Animated.Value(0)).current;
  const titleY          = useRef(new Animated.Value(20)).current;
  const subtitleOpacity = useRef(new Animated.Value(0)).current;
  const dot1            = useRef(new Animated.Value(0)).current;
  const dot2            = useRef(new Animated.Value(0)).current;
  const dot3            = useRef(new Animated.Value(0)).current;
  const screenOpacity   = useRef(new Animated.Value(1)).current;
  const birdBob         = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(bgOpacity, { toValue: 1, duration: 300, useNativeDriver: true }).start();

    Animated.sequence([
      Animated.delay(200),
      Animated.parallel([
        Animated.timing(glowOpacity, { toValue: 0.6, duration: 500, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(glowScale,   { toValue: 1,   duration: 600, easing: Easing.out(Easing.back(1.5)), useNativeDriver: true }),
      ]),
    ]).start();

    Animated.sequence([
      Animated.delay(350),
      Animated.parallel([
        Animated.timing(birdOpacity, { toValue: 1, duration: 450, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(birdScale,   { toValue: 1, duration: 500, easing: Easing.out(Easing.back(1.8)), useNativeDriver: true }),
        Animated.timing(birdY,       { toValue: 0, duration: 500, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      ]),
    ]).start();

    Animated.sequence([
      Animated.delay(900),
      Animated.loop(
        Animated.sequence([
          Animated.timing(wingRotate, { toValue: 1, duration: 160, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(wingRotate, { toValue: 0, duration: 160, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        ]),
        { iterations: 3 }
      ),
    ]).start();

    Animated.sequence([
      Animated.delay(2000),
      Animated.loop(
        Animated.sequence([
          Animated.timing(birdBob, { toValue: -8, duration: 700, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          Animated.timing(birdBob, { toValue: 0,  duration: 700, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        ]),
        { iterations: 2 }
      ),
    ]).start();

    Animated.sequence([
      Animated.delay(700),
      Animated.parallel([
        Animated.timing(titleOpacity, { toValue: 1, duration: 400, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(titleY,       { toValue: 0, duration: 400, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      ]),
    ]).start();

    Animated.sequence([
      Animated.delay(1000),
      Animated.timing(subtitleOpacity, { toValue: 1, duration: 400, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
    ]).start();

    const dotAnim = (dot: Animated.Value, delay: number) =>
      Animated.sequence([
        Animated.delay(delay),
        Animated.loop(
          Animated.sequence([
            Animated.timing(dot, { toValue: 1,   duration: 400, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
            Animated.timing(dot, { toValue: 0.2, duration: 400, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
          ])
        ),
      ]);

    dotAnim(dot1, 1100).start();
    dotAnim(dot2, 1300).start();
    dotAnim(dot3, 1500).start();

    if (onFinish) {
      const timer = setTimeout(() => {
        Animated.timing(screenOpacity, {
          toValue: 0, duration: 400, easing: Easing.in(Easing.cubic), useNativeDriver: true,
        }).start(() => onFinish());
      }, duration);
      return () => clearTimeout(timer);
    }
  }, []);

  const wingInterp = wingRotate.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "-18deg"],
  });

  return (
    <Animated.View style={[styles.root, { opacity: screenOpacity }]}>
      {/* Fond */}
      <Animated.View style={[styles.bg, { opacity: bgOpacity }]}>
        <View style={styles.bgTop} />
        <View style={styles.bgBottom} />
      </Animated.View>

      {/* Particules déco */}
      <View style={[styles.particles, { pointerEvents: "none" }]}>
        {PARTICLES.map((p, i) => (
          <View
            key={i}
            style={[
              styles.particle,
              {
                left:            p.x,
                top:             p.y,
                width:           p.size,
                height:          p.size,
                borderRadius:    p.size / 2,
                backgroundColor: p.color,
                opacity:         p.opacity,
              },
            ]}
          />
        ))}
      </View>

      {/* Halo */}
      <Animated.View
        style={[styles.glow, { opacity: glowOpacity, transform: [{ scale: glowScale }], pointerEvents: "none" }]}
      />

      {/* Oiseau */}
      <Animated.View
        style={[
          styles.birdWrapper,
          {
            opacity: birdOpacity,
            transform: [
              { scale: birdScale },
              { translateY: birdY },
              { translateY: birdBob },
            ],
          },
        ]}
      >
        <Animated.View
          style={[
            styles.wingOverlay,
            {
              transform: [
                { translateX: -10 },
                { translateY: 8 },
                { rotate: wingInterp },
                { translateX: 10 },
                { translateY: -8 },
              ],
              pointerEvents: "none",
            },
          ]}
        />
        <Image
          source={require("../assets/images/icon.png")}
          style={styles.bird}
          resizeMode="contain"
        />
      </Animated.View>

      {/* Titre */}
      <Animated.View
        style={{ opacity: titleOpacity, transform: [{ translateY: titleY }], alignItems: "center" }}
      >
        <Text style={styles.title}>SANKOFA</Text>
        <View style={styles.titleUnderline} />
      </Animated.View>

      {/* Sous-titre */}
      <Animated.Text style={[styles.subtitle, { opacity: subtitleOpacity }]}>
        Translate & Learn
      </Animated.Text>

      {/* Points */}
      <View style={styles.dotsRow}>
        {([dot1, dot2, dot3] as Animated.Value[]).map((dot, i) => (
          <Animated.View
            key={i}
            style={[
              styles.dot,
              {
                opacity: dot,
                transform: [
                  {
                    scale: dot.interpolate({
                      inputRange: [0.2, 1],
                      outputRange: [0.7, 1.2],
                    }),
                  },
                ],
              },
            ]}
          />
        ))}
      </View>

      {/* Tagline */}
      <Animated.Text style={[styles.tagline, { opacity: subtitleOpacity }]}>
        Explorez les langues d'Afrique
      </Animated.Text>
    </Animated.View>
  );
}

// ─── Particules — positions en nombre (px) ────────────────────────────────────
const PARTICLES: { x: number; y: number; size: number; color: string; opacity: number }[] = [
  { x: 30,  y: 80,  size: 6, color: "#E8B647", opacity: 0.5 },
  { x: 320, y: 60,  size: 4, color: "#52b788", opacity: 0.4 },
  { x: 50,  y: 520, size: 5, color: "#52b788", opacity: 0.3 },
  { x: 340, y: 490, size: 8, color: "#E8B647", opacity: 0.35 },
  { x: 180, y: 700, size: 4, color: "#fff",    opacity: 0.15 },
  { x: 10,  y: 330, size: 3, color: "#E8B647", opacity: 0.25 },
  { x: 355, y: 280, size: 5, color: "#52b788", opacity: 0.3 },
  { x: 260, y: 100, size: 3, color: "#fff",    opacity: 0.2 },
  { x: 90,  y: 140, size: 4, color: "#E8B647", opacity: 0.2 },
  { x: 230, y: 610, size: 6, color: "#52b788", opacity: 0.25 },
];

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  root: {
    ...StyleSheet.absoluteFillObject,
    alignItems: "center",
    justifyContent: "center",
    zIndex: 9999,
  },
  bg: { ...StyleSheet.absoluteFillObject },
  bgTop: {
    position: "absolute", top: 0, left: 0, right: 0, height: "60%",
    backgroundColor: "#0a0f0d",
  },
  bgBottom: {
    position: "absolute", bottom: 0, left: 0, right: 0, height: "45%",
    backgroundColor: "#0d1a12",
  },
  particles: { ...StyleSheet.absoluteFillObject },
  particle:  { position: "absolute" },
  glow: {
    position: "absolute",
    width: 220, height: 220, borderRadius: 110,
    backgroundColor: "transparent",
    borderWidth: 60,
    borderColor: "rgba(82,183,136,0.08)",
    shadowColor: "#52b788",
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 40,
    elevation: 0,
  },
  birdWrapper: {
    width: 180, height: 180,
    alignItems: "center", justifyContent: "center",
    marginBottom: 28,
  },
  wingOverlay: {
    position: "absolute",
    width: 80, height: 90,
    backgroundColor: "transparent",
    zIndex: 2,
  },
  bird: { width: 170, height: 170 },
  title: {
    fontSize: 36, fontWeight: "900",
    color: "#E8B647", letterSpacing: 10,
    ...(Platform.OS === "ios" ? { fontFamily: "Georgia" } : { fontFamily: "serif" }),
  },
  titleUnderline: {
    width: 60, height: 2,
    backgroundColor: "#52b788", borderRadius: 1, marginTop: 8,
  },
  subtitle: {
    fontSize: 15, color: "rgba(255,255,255,0.55)",
    letterSpacing: 3, marginTop: 10, fontWeight: "300",
  },
  dotsRow: {
    flexDirection: "row", gap: 10, marginTop: 36, alignItems: "center",
  },
  dot: {
    width: 8, height: 8, borderRadius: 4, backgroundColor: "#52b788",
  },
  tagline: {
    position: "absolute", bottom: 52,
    fontSize: 12, color: "rgba(255,255,255,0.3)",
    letterSpacing: 2, textTransform: "uppercase",
  },
});