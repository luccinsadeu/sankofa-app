import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useRouter } from "expo-router";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Easing,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Image,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import AsyncStorage from "@react-native-async-storage/async-storage";

type AuthMode = "welcome" | "signup" | "login";
const AVATARS = ["🐘", "🦁", "🐒", "🦒", "🐊", "🌍", "📖", "✨", "🎨", "🎵", "⚽", "🦅"];

export default function Welcome() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { signup, login, setUser } = useApp();

  const [mode, setMode] = useState<AuthMode>("welcome");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [avatar, setAvatar] = useState("🐘");
  const [loginEmail, setLoginEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 600, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
    ]).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.08, duration: 2000, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 2000, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ])
    ).start();
    checkAlreadyLoggedIn();
  }, []);

  const checkAlreadyLoggedIn = async () => {
    try {
      const userData = await AsyncStorage.getItem("@sankofa_user");
      const onboarded = await AsyncStorage.getItem("onboardingCompleted");
      if (userData && onboarded === "true") {
        router.replace("/(tabs)");
      }
    } catch (_) {}
  };

  function animateTo(newMode: AuthMode) {
    Haptics.selectionAsync();
    setError("");
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 0, duration: 180, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 20, duration: 180, useNativeDriver: true }),
    ]).start(() => {
      setMode(newMode);
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 300, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(slideAnim, { toValue: 0, duration: 300, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      ]).start();
    });
  }

  const displayName = username.trim();
  const canSignup = displayName.length >= 2 && email.includes("@") && email.includes(".");

  async function handleSignup() {
    if (!displayName || displayName.length < 2 || !email.trim()) {
      setError("Veuillez remplir tous les champs");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await signup(displayName, email.trim());
      if (result.success && result.user) {
        const userWithAvatar = { ...result.user, avatar };
        setUser(userWithAvatar);
        await AsyncStorage.setItem("@sankofa_avatar", avatar);
        await AsyncStorage.setItem("onboardingCompleted", "true");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      } else {
        setError(result.error || "Erreur lors de l'inscription. Vérifiez votre connexion.");
      }
    } catch (_) {
      setError("Connexion impossible. Vérifiez votre réseau.");
    } finally {
      setLoading(false);
    }
  }

  async function handleLogin() {
    if (!loginEmail.trim() || !loginEmail.includes("@")) {
      setError("Entrez un email valide");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await login(loginEmail.trim());
      if (result.success && result.user) {
        await AsyncStorage.setItem("onboardingCompleted", "true");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      } else {
        setError("Aucun compte trouvé avec cet email");
      }
    } catch (_) {
      setError("Connexion impossible. Vérifiez votre réseau.");
    } finally {
      setLoading(false);
    }
  }

  const topPad = Platform.OS === "web" ? 56 : insets.top;
  const bottomPad = Platform.OS === "web" ? 32 : insets.bottom + 16;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.bgCircle1, { backgroundColor: colors.deepGreen + "18", pointerEvents: "none" }]} />
      <View style={[styles.bgCircle2, { backgroundColor: colors.gold + "14", pointerEvents: "none" }]} />

      {mode !== "welcome" && (
        <View style={[styles.header, { paddingTop: topPad + 8 }]}>
          <Pressable onPress={() => animateTo("welcome")} style={[styles.backBtn, { backgroundColor: colors.secondary }]}>
            <MaterialIcons name="arrow-back" size={18} color={colors.foreground} />
          </Pressable>
          <View style={{ flex: 1 }} />
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>
            {mode === "login" ? "Connexion" : "Inscription"}
          </Text>
          <View style={{ width: 36 }} />
        </View>
      )}

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Animated.View style={{ flex: 1, opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>
          <ScrollView
            contentContainerStyle={[
              styles.scroll,
              { paddingTop: mode === "welcome" ? topPad : 16, paddingBottom: bottomPad },
            ]}
            keyboardShouldPersistTaps="handled"
          >
            {mode === "welcome" && (
              <View style={styles.welcomeContainer}>
                <View style={styles.logoSection}>
                  <Animated.View style={[styles.logoOuter, { backgroundColor: colors.deepGreen + "20", transform: [{ scale: pulseAnim }] }]}>
                    <View style={[styles.logoInner, { backgroundColor: colors.deepGreen }]}>
                      <Image
                        source={require("@/assets/images/icon.png")}
                        style={{ width: 52, height: 52 }}
                        resizeMode="contain"
                      />
                    </View>
                  </Animated.View>
                  <Text style={[styles.logoLabel, { color: colors.deepGreen }]}>SANKOFA</Text>
                  <Text style={[styles.logoTitle, { color: colors.foreground }]}>Translate & Learn</Text>
                  <Text style={[styles.logoSub, { color: colors.mutedForeground }]}>
                    Explorez les langues d'Afrique 🌍
                  </Text>
                </View>

                <View style={styles.featureRow}>
                  {[
                    { icon: "language", text: "11 langues africaines" },
                    { icon: "emoji-events", text: "Quiz & niveaux" },
                    { icon: "group", text: "Communauté" },
                  ].map((f) => (
                    <View key={f.icon} style={[styles.featureChip, { backgroundColor: colors.secondary }]}>
                      <MaterialIcons name={f.icon as any} size={13} color={colors.deepGreen} />
                      <Text style={[styles.featureText, { color: colors.foreground }]}>{f.text}</Text>
                    </View>
                  ))}
                </View>

                <View style={styles.ctaSection}>
                  <PrimaryButton label="Créer un compte" onPress={() => animateTo("signup")} color={colors.deepGreen} />
                  <View style={styles.dividerRow}>
                    <View style={[styles.divider, { backgroundColor: colors.border }]} />
                    <Text style={[styles.dividerText, { color: colors.mutedForeground }]}>ou</Text>
                    <View style={[styles.divider, { backgroundColor: colors.border }]} />
                  </View>
                  <SecondaryButton label="Se connecter" onPress={() => animateTo("login")} colors={colors} />
                </View>
              </View>
            )}

            {mode === "signup" && (
              <ProfileStep
                username={username}
                onUsername={setUsername}
                email={email}
                onEmail={setEmail}
                avatar={avatar}
                onAvatar={setAvatar}
                colors={colors}
                error={error}
                loading={loading}
                onSignup={handleSignup}
                canSignup={canSignup}
              />
            )}

            {mode === "login" && (
              <LoginStep
                email={loginEmail}
                onEmail={setLoginEmail}
                onSubmit={handleLogin}
                loading={loading}
                error={error}
                colors={colors}
                onSignup={() => animateTo("signup")}
              />
            )}
          </ScrollView>
        </Animated.View>
      </KeyboardAvoidingView>
    </View>
  );
}

function ProfileStep({ username, onUsername, email, onEmail, avatar, onAvatar, colors, error, loading, onSignup, canSignup }: any) {
  return (
    <View style={styles.stepContainer}>
      <Text style={[styles.stepTitle, { color: colors.foreground }]}>🌍 Crée ton compte</Text>
      <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>Rejoins la communauté Sankofa</Text>

      <View style={styles.avatarSection}>
        <View style={[styles.avatarPreview, { borderColor: colors.deepGreen }]}>
          <Text style={{ fontSize: 52 }}>{avatar}</Text>
        </View>
        <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>Choisis ton avatar</Text>
        <View style={styles.avatarGrid}>
          {AVATARS.map((a) => (
            <Pressable key={a} onPress={() => { Haptics.selectionAsync(); onAvatar(a); }}>
              <View style={[
                styles.avatarItem,
                { backgroundColor: a === avatar ? colors.deepGreen + "20" : colors.secondary },
                a === avatar && { borderWidth: 2, borderColor: colors.deepGreen },
              ]}>
                <Text style={{ fontSize: 22 }}>{a}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Pseudo</Text>
        <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <MaterialIcons name="alternate-email" size={17} color={colors.mutedForeground} />
          <TextInput
            value={username}
            onChangeText={onUsername}
            placeholder="ex: Sankofa Learner"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.input, { color: colors.foreground }]}
          />
        </View>
      </View>

      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Email</Text>
        <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <MaterialIcons name="email" size={17} color={colors.mutedForeground} />
          <TextInput
            value={email}
            onChangeText={onEmail}
            placeholder="ex: sankofa@example.com"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="none"
            keyboardType="email-address"
            style={[styles.input, { color: colors.foreground }]}
          />
        </View>
      </View>

      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      <PrimaryButton
        label={loading ? "Création..." : "S'inscrire"}
        onPress={onSignup}
        disabled={loading || !canSignup}
        color={colors.deepGreen}
      />
      <Text style={[styles.termsText, { color: colors.mutedForeground }]}>
        En créant un compte, tu rejoins la communauté Sankofa 🌍
      </Text>
    </View>
  );
}

function LoginStep({ email, onEmail, onSubmit, loading, error, colors, onSignup }: any) {
  return (
    <View style={styles.loginContainer}>
      <View style={styles.loginHeader}>
        <View style={[styles.loginIcon, { backgroundColor: colors.deepGreen + "18" }]}>
          <MaterialIcons name="login" size={32} color={colors.deepGreen} />
        </View>
        <Text style={[styles.loginTitle, { color: colors.foreground }]}>Bon retour ! 👋</Text>
        <Text style={[styles.loginSub, { color: colors.mutedForeground }]}>Entrez votre email pour continuer</Text>
      </View>

      <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <MaterialIcons name="email" size={18} color={colors.mutedForeground} />
        <TextInput
          value={email}
          onChangeText={onEmail}
          placeholder="votre@email.com"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="none"
          keyboardType="email-address"
          autoFocus
          style={[styles.input, { color: colors.foreground }]}
        />
      </View>

      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      <PrimaryButton
        label={loading ? "Connexion..." : "Se connecter"}
        onPress={onSubmit}
        disabled={loading || !email.includes("@")}
        color={colors.deepGreen}
      />
      <Pressable onPress={onSignup}>
        <Text style={[styles.switchText, { color: colors.mutedForeground }]}>
          Pas encore de compte ?{" "}
          <Text style={{ color: colors.deepGreen, fontWeight: "700" }}>Créer un compte</Text>
        </Text>
      </Pressable>
    </View>
  );
}

function PrimaryButton({ label, onPress, disabled, color }: any) {
  return (
    <Pressable
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.primaryBtn,
        { backgroundColor: disabled ? "#9ca3af" : color, opacity: pressed ? 0.85 : 1 },
      ]}
    >
      <Text style={styles.primaryBtnText}>{label}</Text>
    </Pressable>
  );
}

function SecondaryButton({ label, onPress, colors }: any) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.secondaryBtn,
        { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.8 : 1 },
      ]}
    >
      <Text style={[styles.secondaryBtnText, { color: colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  bgCircle1: { position: "absolute", top: -100, right: -80, width: 300, height: 300, borderRadius: 150, zIndex: 0 },
  bgCircle2: { position: "absolute", bottom: 50, left: -100, width: 250, height: 250, borderRadius: 125, zIndex: 0 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingBottom: 12, gap: 14 },
  backBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  headerTitle: { flex: 1, fontSize: 17, fontWeight: "700", textAlign: "center" },
  scroll: { paddingHorizontal: 20, flexGrow: 1 },
  welcomeContainer: { gap: 28, paddingTop: 20 },
  logoSection: { alignItems: "center", gap: 12 },
  logoOuter: { width: 130, height: 130, borderRadius: 65, alignItems: "center", justifyContent: "center" },
  logoInner: { width: 100, height: 100, borderRadius: 50, alignItems: "center", justifyContent: "center", overflow: "hidden" },
  logoLabel: { fontSize: 12, fontWeight: "800", letterSpacing: 4, marginTop: 4 },
  logoTitle: { fontSize: 30, fontWeight: "800" },
  logoSub: { fontSize: 15, textAlign: "center" },
  featureRow: { flexDirection: "row", flexWrap: "wrap", gap: 8, justifyContent: "center" },
  featureChip: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 7, borderRadius: 20 },
  featureText: { fontSize: 12, fontWeight: "600" },
  ctaSection: { gap: 12 },
  dividerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  divider: { flex: 1, height: 1 },
  dividerText: { fontSize: 13 },
  stepContainer: { gap: 20, paddingTop: 8 },
  stepTitle: { fontSize: 24, fontWeight: "800" },
  stepSub: { fontSize: 14 },
  avatarSection: { alignItems: "center", gap: 10 },
  avatarPreview: { width: 100, height: 100, borderRadius: 50, borderWidth: 3, alignItems: "center", justifyContent: "center" },
  avatarGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, justifyContent: "center" },
  avatarItem: { width: 52, height: 52, borderRadius: 26, alignItems: "center", justifyContent: "center" },
  fieldGroup: { gap: 8 },
  fieldLabel: { fontSize: 14, fontWeight: "600" },
  inputContainer: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 14, borderWidth: 1, paddingHorizontal: 16 },
  input: { flex: 1, paddingVertical: 14, fontSize: 16 },
  primaryBtn: { paddingVertical: 16, borderRadius: 14, alignItems: "center" },
  primaryBtnText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  secondaryBtn: { paddingVertical: 15, borderRadius: 14, alignItems: "center", borderWidth: 1 },
  secondaryBtnText: { fontWeight: "600", fontSize: 15 },
  loginContainer: { gap: 20, paddingTop: 40 },
  loginHeader: { alignItems: "center", gap: 10, marginBottom: 8 },
  loginIcon: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center" },
  loginTitle: { fontSize: 26, fontWeight: "800" },
  loginSub: { fontSize: 14, textAlign: "center" },
  switchText: { fontSize: 14, textAlign: "center", marginTop: 8 },
  termsText: { fontSize: 12, textAlign: "center", marginTop: -8 },
  errorText: { color: "#ef4444", fontSize: 13, textAlign: "center" },
});