// app/login.tsx
import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { GradientView } from "@/components/GradientView";
import { useRouter } from "expo-router";
import React, { useState, useRef, useEffect } from "react";
import {
  Animated,
  Easing,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Image,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useColors } from "@/hooks/useColors";
import { useApp } from "@/context/AppContext";
import AsyncStorage from "@react-native-async-storage/async-storage";

// ─── Constantes ───────────────────────────────────────────────────────────────
const AFRICAN_LANGUAGES = [
  { id: "swahili", name: "Swahili", flag: "🇹🇿", color: "#4CAF50" },
  { id: "yoruba", name: "Yoruba", flag: "🇳🇬", color: "#E8B647" },
  { id: "hausa", name: "Haoussa", flag: "🇳🇬", color: "#FF9800" },
  { id: "zulu", name: "Zulu", flag: "🇿🇦", color: "#2196F3" },
  { id: "lingala", name: "Lingala", flag: "🇨🇩", color: "#9C27B0" },
] as const;

type LanguageId = typeof AFRICAN_LANGUAGES[number]["id"];
type AuthMode = "welcome" | "signup" | "login";
type SignupStep = "profile" | "language" | "goal" | "ready";

const AVATARS = ["🐘", "🦁", "🐒", "🦒", "🐊", "🌍", "📖", "✨", "🎨", "🎵", "⚽", "🦅"];

// ─── Main component ───────────────────────────────────────────────────────────
export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { signup, login, setUser } = useApp();

  const [mode, setMode] = useState<AuthMode>("welcome");
  const [signupStep, setSignupStep] = useState<SignupStep>("profile");

  // Signup fields
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [avatar, setAvatar] = useState("🐘");
  const [picked, setPicked] = useState<LanguageId | null>(null);
  const [goal, setGoal] = useState(10);

  // Login fields
  const [loginEmail, setLoginEmail] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 600, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
    ]).start();
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, { toValue: 1.08, duration: 2000, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(pulseAnim, { toValue: 1, duration: 2000, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ])
    ).start();
  }, []);

  function animateTo(newMode: AuthMode) {
    Haptics.selectionAsync();
    setError("");
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 0, duration: 180, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 20, duration: 180, useNativeDriver: true }),
    ]).start(() => {
      setMode(newMode);
      setSignupStep("profile");
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 300, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(slideAnim, { toValue: 0, duration: 300, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      ]).start();
    });
  }

  // ── Signup steps ─────────────────────────────────────────────────────────────
  const SIGNUP_STEPS: SignupStep[] = ["profile", "language", "goal", "ready"];
  const stepIndex = SIGNUP_STEPS.indexOf(signupStep);

  function nextStep() {
    Haptics.selectionAsync();
    const next = SIGNUP_STEPS[Math.min(stepIndex + 1, SIGNUP_STEPS.length - 1)];
    animateStep(next);
  }

  function prevStep() {
    Haptics.selectionAsync();
    if (stepIndex === 0) { animateTo("welcome"); return; }
    animateStep(SIGNUP_STEPS[stepIndex - 1]);
  }

  function animateStep(next: SignupStep) {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 0, duration: 150, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 15, duration: 150, useNativeDriver: true }),
    ]).start(() => {
      setSignupStep(next);
      Animated.parallel([
        Animated.timing(fadeAnim, { toValue: 1, duration: 280, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
        Animated.timing(slideAnim, { toValue: 0, duration: 280, easing: Easing.out(Easing.cubic), useNativeDriver: true }),
      ]).start();
    });
  }

  const sanitizedUser = username.trim().replace(/[^a-zA-Z0-9_]/g, "").toLowerCase();

  const canNext =
    signupStep === "goal" || signupStep === "ready" ||
    (signupStep === "profile" && sanitizedUser.length >= 2 && email.includes("@") && email.includes(".")) ||
    (signupStep === "language" && !!picked);

  // ── Finish signup ─────────────────────────────────────────────────────────────
  async function handleSignup() {
    if (!picked || !sanitizedUser || !email.trim()) {
      setError("Veuillez remplir tous les champs");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await signup(sanitizedUser, email.trim());
      if (result.success && result.user) {
        setUser({   // <-- correction : enlever await
          id: result.user.id,
          name: sanitizedUser,
          email: email.trim(),
          avatar,
          joinedAt: new Date().toISOString(),
        });
        await AsyncStorage.setItem("userLanguage", picked);
        await AsyncStorage.setItem("userDailyGoal", goal.toString());
        await AsyncStorage.setItem("onboardingCompleted", "true");
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      } else {
        setError(result.error || "Erreur lors de l'inscription");
      }
    } catch (e: any) {
      setError("Connexion impossible. Vérifiez votre connexion.");
    } finally {
      setLoading(false);
    }
  }

  // ── Login ─────────────────────────────────────────────────────────────────────
  async function handleLogin() {
    if (!loginEmail.trim() || !loginEmail.includes("@")) {
      setError("Entrez un email valide");
      return;
    }
    setLoading(true);
    setError("");
    try {
      const result = await login(loginEmail.trim());
      if (result.success && result.user) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace("/(tabs)");
      } else {
        setError("Aucun compte trouvé avec cet email");
      }
    } catch (e: any) {
      setError("Connexion impossible. Vérifiez votre connexion.");
    } finally {
      setLoading(false);
    }
  }

  const topPad = Platform.OS === "web" ? 56 : insets.top;
  const bottomPad = Platform.OS === "web" ? 32 : insets.bottom + 16;

  // ── Render ─────────────────────────────────────────────────────────────────────
  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <View style={[styles.bgCircle1, { pointerEvents: "none" }]} />
      <View style={[styles.bgCircle2, { pointerEvents: "none" }]} />

      {mode !== "welcome" && (
        <View style={[styles.header, { paddingTop: topPad + 8 }]}>
          <Pressable onPress={mode === "signup" ? prevStep : () => animateTo("welcome")} style={[styles.backBtn, { backgroundColor: colors.secondary }]}>
            <MaterialIcons name="arrow-back" size={18} color={colors.foreground} />
          </Pressable>

          {mode === "signup" && (
            <View style={styles.progressBar}>
              {SIGNUP_STEPS.map((_, i) => (
                <View key={i} style={[styles.progressDot, {
                  flex: 1,
                  backgroundColor: i <= stepIndex ? colors.deepGreen : colors.border,
                }]} />
              ))}
            </View>
          )}

          {mode === "login" && (
            <Text style={[styles.headerTitle, { color: colors.foreground }]}>Connexion</Text>
          )}
          <View style={{ width: 36 }} />
        </View>
      )}

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Animated.View style={{ flex: 1, opacity: fadeAnim, transform: [{ translateY: slideAnim }] }}>
          <ScrollView
            contentContainerStyle={[styles.scroll, { paddingTop: mode === "welcome" ? topPad : 16, paddingBottom: bottomPad }]}
            showsVerticalScrollIndicator={false}
            keyboardShouldPersistTaps="handled"
          >
            {mode === "welcome" && (
              <WelcomeScreen
                colors={colors}
                pulseAnim={pulseAnim}
                onSignup={() => animateTo("signup")}
                onLogin={() => animateTo("login")}
              />
            )}

            {mode === "signup" && (
              <>
                {signupStep === "profile" && (
                  <ProfileStep
                    username={username} onUsername={setUsername}
                    email={email} onEmail={setEmail}
                    avatar={avatar} onAvatar={setAvatar}
                    colors={colors}
                  />
                )}
                {signupStep === "language" && (
                  <LanguageStep picked={picked} onPick={setPicked} colors={colors} />
                )}
                {signupStep === "goal" && (
                  <GoalStep goal={goal} onGoal={setGoal} colors={colors} />
                )}
                {signupStep === "ready" && (
                  <ReadyStep
                    username={sanitizedUser} avatar={avatar}
                    languagePicked={picked} goal={goal} colors={colors}
                  />
                )}

                {error ? <Text style={styles.errorText}>{error}</Text> : null}

                <View style={{ marginTop: 24 }}>
                  {signupStep === "ready" ? (
                    <PrimaryButton
                      label={loading ? "Création du compte..." : "Commencer l'aventure 🚀"}
                      onPress={handleSignup}
                      disabled={loading}
                      color={colors.deepGreen}
                    />
                  ) : (
                    <PrimaryButton
                      label="Continuer"
                      onPress={nextStep}
                      disabled={!canNext}
                      color={colors.deepGreen}
                    />
                  )}
                </View>
              </>
            )}

            {mode === "login" && (
              <LoginStep
                email={loginEmail} onEmail={setLoginEmail}
                onSubmit={handleLogin} loading={loading}
                error={error} colors={colors}
                onSignup={() => animateTo("signup")}
              />
            )}
          </ScrollView>
        </Animated.View>
      </KeyboardAvoidingView>
    </View>
  );
}

// ─── Welcome Screen (avec image au centre) ────────────────────────────────────
function WelcomeScreen({ colors, pulseAnim, onSignup, onLogin }: any) {
  const features = [
    { icon: "language", label: "5 langues africaines", color: "#E8B647" },
    { icon: "flash-on", label: "Quiz interactifs", color: "#4CAF50" },
    { icon: "group", label: "Communauté active", color: "#2196F3" },
    { icon: "menu-book", label: "Traduction gratuite", color: "#9C27B0" },
  ];

  return (
    <View style={styles.welcomeContainer}>
      <View style={styles.logoSection}>
        <Animated.View style={[styles.logoOuter, { transform: [{ scale: pulseAnim }] }]}>
          <GradientView colors={["#2d6a4f", "#52b788"]} style={styles.logoInner}>
            <Image
              source={require("@/assets/images/icon.png")}
              style={{ width: 52, height: 52 }}
              resizeMode="contain"
            />
          </GradientView>
        </Animated.View>
        <Text style={[styles.logoLabel, { color: colors.deepGreen }]}>SANKOFA</Text>
        <Text style={[styles.logoTitle, { color: colors.foreground }]}>Translate & Learn</Text>
        <Text style={[styles.logoSub, { color: colors.mutedForeground }]}>
          Explorez les langues d'Afrique
        </Text>
      </View>

      <View style={styles.featuresGrid}>
        {features.map((f) => (
          <View key={f.label} style={[styles.featureCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
            <View style={[styles.featureIcon, { backgroundColor: f.color + "18" }]}>
              <MaterialIcons name={f.icon as any} size={20} color={f.color} />
            </View>
            <Text style={[styles.featureLabel, { color: colors.foreground }]}>{f.label}</Text>
          </View>
        ))}
      </View>

      <View style={styles.ctaSection}>
        <PrimaryButton label="Créer un compte" onPress={onSignup} color="#2d6a4f" />
        <View style={styles.dividerRow}>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
          <Text style={[styles.dividerText, { color: colors.mutedForeground }]}>ou</Text>
          <View style={[styles.divider, { backgroundColor: colors.border }]} />
        </View>
        <SecondaryButton label="Se connecter" onPress={onLogin} colors={colors} />
      </View>

      <Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>
        Gratuit · Sans publicité · Données privées
      </Text>
    </View>
  );
}

// ─── Login Step ───────────────────────────────────────────────────────────────
function LoginStep({ email, onEmail, onSubmit, loading, error, colors, onSignup }: any) {
  return (
    <View style={styles.loginContainer}>
      <View style={styles.loginHeader}>
        <View style={[styles.loginIcon, { backgroundColor: colors.deepGreen + "15" }]}>
          <MaterialIcons name="login" size={32} color={colors.deepGreen} />
        </View>
        <Text style={[styles.loginTitle, { color: colors.foreground }]}>Bon retour ! 👋</Text>
        <Text style={[styles.loginSub, { color: colors.mutedForeground }]}>
          Entrez votre email pour accéder à votre compte
        </Text>
      </View>

      <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <MaterialIcons name="email" size={18} color={colors.mutedForeground} />
        <TextInput
          value={email}
          onChangeText={onEmail}
          placeholder="votre@email.com"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="none"
          keyboardType="email-address"
          autoCorrect={false}
          autoFocus
          style={[styles.input, { color: colors.foreground }]}
        />
      </View>

      {error ? <Text style={styles.errorText}>{error}</Text> : null}

      <PrimaryButton
        label={loading ? "Connexion..." : "Se connecter"}
        onPress={onSubmit}
        disabled={loading || !email.includes("@")}
        color="#2d6a4f"
      />

      <Pressable onPress={onSignup} style={styles.switchLink}>
        <Text style={[styles.switchText, { color: colors.mutedForeground }]}>
          Pas encore de compte ?{" "}
          <Text style={{ color: colors.deepGreen, fontWeight: "700" }}>
            Créer un compte
          </Text>
        </Text>
      </Pressable>
    </View>
  );
}

// ─── Profile Step ─────────────────────────────────────────────────────────────
function ProfileStep({ username, onUsername, email, onEmail, avatar, onAvatar, colors }: any) {
  return (
    <View style={styles.stepContainer}>
      <View style={styles.stepHeader}>
        <Text style={[styles.stepTitle, { color: colors.foreground }]}>🌍 Ton identité</Text>
        <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>
          Crée ton profil pour rejoindre la communauté Sankofa
        </Text>
      </View>

      <View style={styles.avatarSection}>
        <View style={[styles.avatarPreview, { borderColor: colors.deepGreen }]}>
          <Text style={{ fontSize: 52 }}>{avatar}</Text>
        </View>
        <Text style={[styles.fieldLabel, { color: colors.mutedForeground }]}>Choisis ton avatar</Text>
        <View style={styles.avatarGrid}>
          {AVATARS.map((a) => (
            <Pressable key={a} onPress={() => { Haptics.selectionAsync(); onAvatar(a); }}>
              <View style={[
                styles.avatarItem,
                { backgroundColor: a === avatar ? colors.deepGreen + "20" : colors.secondary },
                a === avatar && { borderWidth: 2, borderColor: colors.deepGreen },
              ]}>
                <Text style={{ fontSize: 22 }}>{a}</Text>
              </View>
            </Pressable>
          ))}
        </View>
      </View>

      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Pseudo</Text>
        <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <MaterialIcons name="alternate-email" size={17} color={colors.mutedForeground} />
          <TextInput
            value={username}
            onChangeText={onUsername}
            placeholder="ex: sankofa_learner"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="none"
            autoCorrect={false}
            maxLength={25}
            style={[styles.input, { color: colors.foreground }]}
          />
        </View>
        <Text style={[styles.fieldHint, { color: colors.mutedForeground }]}>
          Lettres, chiffres, underscore. Min. 2 caractères.
        </Text>
      </View>

      <View style={styles.fieldGroup}>
        <Text style={[styles.fieldLabel, { color: colors.foreground }]}>Email</Text>
        <View style={[styles.inputContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <MaterialIcons name="email" size={17} color={colors.mutedForeground} />
          <TextInput
            value={email}
            onChangeText={onEmail}
            placeholder="ex: sankofa@example.com"
            placeholderTextColor={colors.mutedForeground}
            autoCapitalize="none"
            keyboardType="email-address"
            autoCorrect={false}
            style={[styles.input, { color: colors.foreground }]}
          />
        </View>
      </View>
    </View>
  );
}

// ─── Language Step ────────────────────────────────────────────────────────────
function LanguageStep({ picked, onPick, colors }: any) {
  return (
    <View style={styles.stepContainer}>
      <View style={styles.stepHeader}>
        <Text style={[styles.stepTitle, { color: colors.foreground }]}>🎯 Ta langue</Text>
        <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>
          Choisis la langue africaine que tu veux apprendre
        </Text>
      </View>
      <View style={styles.langList}>
        {AFRICAN_LANGUAGES.map((lang) => {
          const active = picked === lang.id;
          return (
            <Pressable key={lang.id} onPress={() => { Haptics.selectionAsync(); onPick(lang.id); }}>
              <View style={[
                styles.langCard,
                { backgroundColor: active ? lang.color + "15" : colors.card, borderColor: active ? lang.color : colors.border },
              ]}>
                <View style={[styles.langFlagBox, { backgroundColor: active ? lang.color + "20" : colors.secondary }]}>
                  <Text style={{ fontSize: 30 }}>{lang.flag}</Text>
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.langName, { color: colors.foreground }]}>{lang.name}</Text>
                </View>
                {active && (
                  <View style={[styles.checkCircle, { backgroundColor: lang.color }]}>
                    <MaterialIcons name="check" size={14} color="#fff" />
                  </View>
                )}
              </View>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
}

// ─── Goal Step ────────────────────────────────────────────────────────────────
function GoalStep({ goal, onGoal, colors }: any) {
  const options = [5, 10, 15, 20, 30];
  return (
    <View style={styles.stepContainer}>
      <View style={styles.stepHeader}>
        <Text style={[styles.stepTitle, { color: colors.foreground }]}>📚 Objectif quotidien</Text>
        <Text style={[styles.stepSub, { color: colors.mutedForeground }]}>
          Combien de mots veux-tu apprendre chaque jour ?
        </Text>
      </View>
      <View style={styles.goalDisplay}>
        <Text style={[styles.goalNumber, { color: colors.deepGreen }]}>{goal}</Text>
        <Text style={[styles.goalUnit, { color: colors.mutedForeground }]}>mots / jour</Text>
      </View>
      <View style={styles.goalOptions}>
        {options.map((n) => (
          <Pressable key={n} onPress={() => { Haptics.selectionAsync(); onGoal(n); }}>
            <View style={[
              styles.goalOption,
              { borderColor: goal === n ? colors.deepGreen : colors.border, backgroundColor: goal === n ? colors.deepGreen + "15" : colors.card },
            ]}>
              <Text style={[styles.goalOptionNum, { color: goal === n ? colors.deepGreen : colors.foreground }]}>{n}</Text>
            </View>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

// ─── Ready Step ───────────────────────────────────────────────────────────────
function ReadyStep({ username, avatar, languagePicked, goal, colors }: any) {
  const lang = AFRICAN_LANGUAGES.find(l => l.id === languagePicked);
  return (
    <View style={styles.readyContainer}>
      <View style={[styles.readyCheck, { backgroundColor: "#4CAF5020" }]}>
        <MaterialIcons name="check" size={60} color="#4CAF50" />
      </View>
      <Text style={[styles.readyTitle, { color: colors.foreground }]}>Prêt à voyager ! 🚀</Text>
      <Text style={[styles.readySub, { color: colors.mutedForeground }]}>
        Ton aventure linguistique au cœur de l'Afrique commence maintenant.
      </Text>
      <View style={[styles.readyCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Text style={{ fontSize: 28 }}>{avatar}</Text>
        <Text style={[styles.readyUsername, { color: colors.foreground }]}>@{username || "toi"}</Text>
        <View style={[styles.readyDivider, { backgroundColor: colors.border }]} />
        <Text style={{ fontSize: 18 }}>{lang?.flag || "🌍"}</Text>
        <Text style={[{ fontSize: 13, color: colors.mutedForeground }]}>{lang?.name}</Text>
        <View style={[styles.readyDivider, { backgroundColor: colors.border }]} />
        <Text style={[{ fontSize: 13, color: colors.mutedForeground }]}>🎯 {goal} mots/j</Text>
      </View>
    </View>
  );
}

// ─── Boutons ──────────────────────────────────────────────────────────────────
function PrimaryButton({ label, onPress, disabled, color }: { label: string; onPress: () => void; disabled?: boolean; color: string }) {
  return (
    <Pressable onPress={onPress} disabled={disabled} style={({ pressed }) => [styles.primaryBtn, { backgroundColor: disabled ? "#9ca3af" : color, opacity: pressed ? 0.85 : 1 }]}>
      <Text style={styles.primaryBtnText}>{label}</Text>
    </Pressable>
  );
}

function SecondaryButton({ label, onPress, colors }: { label: string; onPress: () => void; colors: any }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.secondaryBtn, { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.8 : 1 }]}>
      <Text style={[styles.secondaryBtnText, { color: colors.foreground }]}>{label}</Text>
    </Pressable>
  );
}

// ─── Styles (complets) ────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  root: { flex: 1 },
  bgCircle1: { position: "absolute", top: -100, right: -80, width: 300, height: 300, borderRadius: 150, backgroundColor: "#52b78812", zIndex: 0 },
  bgCircle2: { position: "absolute", bottom: 50, left: -100, width: 250, height: 250, borderRadius: 125, backgroundColor: "#E8B64712", zIndex: 0 },
  header: { flexDirection: "row", alignItems: "center", paddingHorizontal: 20, paddingBottom: 12, gap: 14 },
  backBtn: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  progressBar: { flex: 1, flexDirection: "row", gap: 6 },
  progressDot: { height: 4, borderRadius: 2 },
  headerTitle: { flex: 1, fontSize: 17, fontWeight: "700", textAlign: "center" },
  scroll: { paddingHorizontal: 20, gap: 0, flexGrow: 1 },
  welcomeContainer: { gap: 32, paddingTop: 20 },
  logoSection: { alignItems: "center", gap: 12 },
  logoOuter: { width: 130, height: 130, borderRadius: 65, backgroundColor: "#52b78818", alignItems: "center", justifyContent: "center" },
  logoInner: { width: 100, height: 100, borderRadius: 50, alignItems: "center", justifyContent: "center" },
  logoLabel: { fontSize: 12, fontWeight: "800", letterSpacing: 4, marginTop: 4 },
  logoTitle: { fontSize: 30, fontWeight: "800" },
  logoSub: { fontSize: 15, textAlign: "center" },
  featuresGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  featureCard: { width: "47%", flexGrow: 1, borderRadius: 16, borderWidth: 1, padding: 16, gap: 10, alignItems: "flex-start" },
  featureIcon: { width: 42, height: 42, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  featureLabel: { fontSize: 13, fontWeight: "600" },
  ctaSection: { gap: 12 },
  dividerRow: { flexDirection: "row", alignItems: "center", gap: 12 },
  divider: { flex: 1, height: 1 },
  dividerText: { fontSize: 13 },
  disclaimer: { fontSize: 11, textAlign: "center", paddingBottom: 8 },
  loginContainer: { gap: 20, paddingTop: 20 },
  loginHeader: { alignItems: "center", gap: 10, marginBottom: 8 },
  loginIcon: { width: 80, height: 80, borderRadius: 40, alignItems: "center", justifyContent: "center" },
  loginTitle: { fontSize: 26, fontWeight: "800" },
  loginSub: { fontSize: 14, textAlign: "center" },
  switchLink: { alignItems: "center", paddingVertical: 8 },
  switchText: { fontSize: 14, textAlign: "center" },
  stepContainer: { gap: 24, paddingTop: 8 },
  stepHeader: { gap: 6 },
  stepTitle: { fontSize: 24, fontWeight: "800" },
  stepSub: { fontSize: 14 },
  avatarSection: { alignItems: "center", gap: 12 },
  avatarPreview: { width: 100, height: 100, borderRadius: 50, borderWidth: 3, alignItems: "center", justifyContent: "center", backgroundColor: "transparent" },
  avatarGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10, justifyContent: "center" },
  avatarItem: { width: 52, height: 52, borderRadius: 26, alignItems: "center", justifyContent: "center" },
  fieldGroup: { gap: 8 },
  fieldLabel: { fontSize: 14, fontWeight: "600" },
  fieldHint: { fontSize: 11 },
  inputContainer: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 14, borderWidth: 1, paddingHorizontal: 16 },
  input: { flex: 1, paddingVertical: 14, fontSize: 16 },
  langList: { gap: 10 },
  langCard: { flexDirection: "row", alignItems: "center", gap: 14, borderRadius: 16, borderWidth: 1.5, padding: 14 },
  langFlagBox: { width: 52, height: 52, borderRadius: 12, alignItems: "center", justifyContent: "center" },
  langName: { fontSize: 16, fontWeight: "700" },
  checkCircle: { width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  goalDisplay: { alignItems: "center", paddingVertical: 20, gap: 4 },
  goalNumber: { fontSize: 72, fontWeight: "800" },
  goalUnit: { fontSize: 16, fontWeight: "600" },
  goalOptions: { flexDirection: "row", flexWrap: "wrap", gap: 10, justifyContent: "center" },
  goalOption: { minWidth: 68, paddingVertical: 14, paddingHorizontal: 20, borderRadius: 14, borderWidth: 1.5, alignItems: "center" },
  goalOptionNum: { fontSize: 18, fontWeight: "700" },
  readyContainer: { alignItems: "center", gap: 20, paddingTop: 30 },
  readyCheck: { width: 120, height: 120, borderRadius: 60, alignItems: "center", justifyContent: "center" },
  readyTitle: { fontSize: 28, fontWeight: "800", textAlign: "center" },
  readySub: { fontSize: 14, textAlign: "center", maxWidth: 300 },
  readyCard: { flexDirection: "row", alignItems: "center", gap: 10, borderRadius: 100, paddingHorizontal: 20, paddingVertical: 14, borderWidth: 1 },
  readyUsername: { fontSize: 15, fontWeight: "700" },
  readyDivider: { width: 1, height: 20 },
  primaryBtn: { paddingVertical: 16, borderRadius: 14, alignItems: "center" },
  primaryBtnText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  secondaryBtn: { paddingVertical: 15, borderRadius: 14, alignItems: "center", borderWidth: 1 },
  secondaryBtnText: { fontWeight: "600", fontSize: 15 },
  errorText: { color: "#ef4444", fontSize: 13, textAlign: "center", marginTop: -8 },
});