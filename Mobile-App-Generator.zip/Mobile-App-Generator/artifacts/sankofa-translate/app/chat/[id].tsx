import { Feather } from "@expo/vector-icons";
import { GradientView } from "@/components/GradientView";
import { router, useLocalSearchParams } from "expo-router";
import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/context/I18nContext";
import { useColors } from "@/hooks/useColors";
import { useHaptics } from "@/hooks/useHaptics";
import {
  getMessages,
  sendMessage,
  formatChatTime,
  type ChatMessage,
} from "@/services/chatService";

function TypingIndicator({ colors }: { colors: any }) {
  return (
    <View style={[styles.typingBubble, { backgroundColor: colors.secondary }]}>
      <View style={styles.dots}>
        {[0, 1, 2].map(i => (
          <View key={i} style={[styles.dot, { backgroundColor: colors.mutedForeground }]} />
        ))}
      </View>
    </View>
  );
}

export default function ChatScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { lang } = useI18n();
  const { user, friends } = useApp();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { impact, notification } = useHaptics();

  const friend = friends.find(f => f.id === id);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [isFriendTyping, setIsFriendTyping] = useState(false);
  const flatRef = useRef<FlatList>(null);

  const loadMessages = useCallback(async () => {
    if (!user || !id) return;
    const msgs = await getMessages(user.id, id);
    setMessages(msgs);
  }, [user, id]);

  useEffect(() => {
    loadMessages();
  }, [loadMessages]);

  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(() => flatRef.current?.scrollToEnd({ animated: true }), 100);
    }
  }, [messages]);

  function simulateFriendResponse(userMsg: string) {
    setTimeout(() => {
      setIsFriendTyping(true);
      setTimeout(async () => {
        setIsFriendTyping(false);
        if (!user || !friend || !id) return;
        const responses = [
          `Merci pour ton message ! 😊`,
          `Intéressant ! 🌍`,
          `Je vais y réfléchir.`,
          `C'est une bonne idée !`,
          `À bientôt sur Sankofa ! 🌿`,
        ];
        const resp = responses[Math.floor(Math.random() * responses.length)];
        const msg = await sendMessage(id, user.id, {
          senderId: id,
          senderName: friend.name,
          content: resp,
        });
        setMessages(prev => [...prev, msg]);
        notification();
      }, 1500 + Math.random() * 1000);
    }, 400);
  }

  async function handleSend() {
    if (!input.trim() || !user || !id) return;
    impact();
    const text = input.trim();
    setInput("");
    const msg = await sendMessage(user.id, id, {
      senderId: user.id,
      senderName: user.name,
      content: text,
    });
    setMessages(prev => [...prev, msg]);
    simulateFriendResponse(text);
  }

  const topPad = Platform.OS === "web" ? 0 : insets.top;
  const bottomPad = Platform.OS === "web" ? 20 : insets.bottom;

  return (
    <KeyboardAvoidingView
      style={[styles.container, { backgroundColor: colors.background }]}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <GradientView colors={[colors.deepGreen, colors.midGreen]} style={[styles.header, { paddingTop: topPad + 12 }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={20} color="#fff" />
        </Pressable>
        <View style={[styles.headerAvatar, { backgroundColor: "rgba(255,255,255,0.2)" }]}>
          <Text style={styles.headerAvatarText}>{friend?.name[0] ?? "?"}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerName}>{friend?.name ?? "Chat"}</Text>
          <Text style={styles.headerStatus}>
            {isFriendTyping
              ? lang === "fr" ? "En train d'écrire…" : "Typing…"
              : lang === "fr" ? "Actif récemment" : "Recently active"}
          </Text>
        </View>
      </GradientView>

      <FlatList
        ref={flatRef}
        data={messages}
        keyExtractor={m => m.id}
        contentContainerStyle={[styles.messageList, { paddingTop: 16, paddingBottom: bottomPad + 16 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyChat}>
            <Text style={{ fontSize: 32 }}>👋</Text>
            <Text style={[styles.emptyChatText, { color: colors.mutedForeground }]}>
              {lang === "fr"
                ? `Dites bonjour à ${friend?.name ?? "votre ami"} !`
                : `Say hello to ${friend?.name ?? "your friend"}!`}
            </Text>
          </View>
        }
        renderItem={({ item, index }) => {
          const isMe = item.senderId === user?.id;
          const showTime =
            index === messages.length - 1 ||
            messages[index + 1]?.senderId !== item.senderId;
          return (
            <View
              style={[styles.bubbleRow, isMe ? styles.bubbleRowMe : styles.bubbleRowThem]}
            >
              <View
                style={[
                  styles.bubble,
                  isMe
                    ? [styles.bubbleMe, { backgroundColor: colors.deepGreen }]
                    : [styles.bubbleThem, { backgroundColor: colors.secondary, borderColor: colors.border }],
                ]}
              >
                <Text style={[styles.bubbleText, { color: isMe ? "#fff" : colors.foreground }]}>
                  {item.content}
                </Text>
              </View>
              {showTime && (
                <Text style={[styles.bubbleTime, { color: colors.mutedForeground }]}>
                  {formatChatTime(item.createdAt)}
                </Text>
              )}
            </View>
          );
        }}
        ListFooterComponent={isFriendTyping ? <TypingIndicator colors={colors} /> : null}
      />

      <View style={[styles.inputBar, { backgroundColor: colors.background, borderTopColor: colors.border, paddingBottom: bottomPad + 8 }]}>
        <TextInput
          style={[styles.input, { backgroundColor: colors.secondary, borderColor: colors.border, color: colors.foreground }]}
          placeholder={lang === "fr" ? "Écrivez un message…" : "Write a message…"}
          placeholderTextColor={colors.mutedForeground}
          value={input}
          onChangeText={setInput}
          multiline
          maxLength={500}
          returnKeyType="send"
          onSubmitEditing={handleSend}
        />
        <Pressable
          style={[styles.sendBtn, { backgroundColor: input.trim() ? colors.deepGreen : colors.muted }]}
          onPress={handleSend}
          disabled={!input.trim()}
        >
          <Feather name="send" size={18} color={input.trim() ? "#fff" : colors.mutedForeground} />
        </Pressable>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  backBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: "rgba(255,255,255,0.15)",
    alignItems: "center",
    justifyContent: "center",
  },
  headerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  headerAvatarText: { color: "#fff", fontWeight: "800", fontSize: 16 },
  headerName: { color: "#fff", fontSize: 16, fontWeight: "700" },
  headerStatus: { color: "rgba(255,255,255,0.7)", fontSize: 12, marginTop: 2 },
  messageList: { paddingHorizontal: 16, gap: 4 },
  bubbleRow: { gap: 2, maxWidth: "80%" },
  bubbleRowMe: { alignSelf: "flex-end", alignItems: "flex-end" },
  bubbleRowThem: { alignSelf: "flex-start", alignItems: "flex-start" },
  bubble: { borderRadius: 18, paddingHorizontal: 14, paddingVertical: 10 },
  bubbleMe: { borderBottomRightRadius: 4 },
  bubbleThem: { borderBottomLeftRadius: 4, borderWidth: 1 },
  bubbleText: { fontSize: 15, lineHeight: 21 },
  bubbleTime: { fontSize: 10, marginHorizontal: 4 },
  typingBubble: {
    alignSelf: "flex-start",
    marginHorizontal: 16,
    marginTop: 4,
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 18,
    borderBottomLeftRadius: 4,
  },
  dots: { flexDirection: "row", gap: 4 },
  dot: { width: 7, height: 7, borderRadius: 3.5 },
  emptyChat: { alignItems: "center", paddingTop: 60, gap: 10 },
  emptyChatText: { fontSize: 15, textAlign: "center" },
  inputBar: {
    flexDirection: "row",
    alignItems: "flex-end",
    gap: 8,
    paddingHorizontal: 12,
    paddingTop: 10,
    borderTopWidth: 1,
  },
  input: {
    flex: 1,
    borderRadius: 22,
    borderWidth: 1.5,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 15,
    maxHeight: 120,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
});
