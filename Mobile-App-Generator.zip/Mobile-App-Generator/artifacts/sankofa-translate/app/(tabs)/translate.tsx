import { MaterialIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState, useRef, useEffect } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Modal,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Card, Toast } from "@/components/ui";
import { useColors } from "@/hooks/useColors";
import {
  LANGUAGES,
  traduire,
  signalerTraductionIncorrecte,
  type NiveauFiabilite,
} from "@/services/groqService";
import * as Clipboard from "expo-clipboard";

const TRANSLATION_LANGUAGES = Object.entries(LANGUAGES).map(([code, name]) => ({ code, name }));
function getLanguageName(code: string): string {
  return LANGUAGES[code as keyof typeof LANGUAGES] ?? code;
}

// ─── Language Picker ─────────────────────────────────────────────────────────
function LanguagePicker({ languages, selected, onSelect, colors, title }: any) {
  return (
    <Card style={styles.picker}>
      {title && <Text style={[styles.pickerTitle, { color: colors.mutedForeground }]}>{title}</Text>}
      <ScrollView showsVerticalScrollIndicator={false} nestedScrollEnabled>
        {languages.map((l: any) => (
          <Pressable
            key={l.code}
            style={[styles.pickerItem, l.code === selected && { backgroundColor: colors.deepGreen + "20" }]}
            onPress={() => onSelect(l.code)}
          >
            <Text style={[styles.pickerText, { color: l.code === selected ? colors.deepGreen : colors.foreground, fontWeight: l.code === selected ? "600" : "500" }]}>
              {l.name}
            </Text>
            {l.code === selected && <MaterialIcons name="check" size={14} color={colors.deepGreen} />}
          </Pressable>
        ))}
      </ScrollView>
    </Card>
  );
}

// ─── Composant principal (traduction texte uniquement) ───────────────────────
export default function TranslateScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  // Langues
  const [fromLang, setFromLang] = useState("fr");
  const [toLang, setToLang] = useState("sw");
  const [showFromPicker, setShowFromPicker] = useState(false);
  const [showToPicker, setShowToPicker] = useState(false);

  // Messages
  const [messages, setMessages] = useState<Array<{ id: string; text: string; isUser: boolean; fiabilite?: NiveauFiabilite; avertissement?: string }>>([]);
  const [inputText, setInputText] = useState("");
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: "", type: "success" as "success" | "error" | "info" });

  // Correction
  const [showCorrectionModal, setShowCorrectionModal] = useState(false);
  const [correctionText, setCorrectionText] = useState("");
  const [currentTranslation, setCurrentTranslation] = useState<{ original: string; translated: string; fromLang: string; toLang: string } | null>(null);

  const LANGUES_DISPONIBLES = TRANSLATION_LANGUAGES.filter(
    (l) => !["ew", "du", "gh", "ff", "bu", "gb"].includes(l.code)
  );

  // Réorganisation : français et anglais en tête, puis langues prioritaires africaines, puis le reste
  const LANGUES_PRIORITAIRES = ["ln", "sw", "yo", "ha", "zu"];
  const languesOrganisees = [
    // Français et anglais (langues de base)
    ...LANGUES_DISPONIBLES.filter((l) => l.code === "fr" || l.code === "en"),
    // Langues prioritaires africaines (sauf si déjà incluses – ici non)
    ...LANGUES_DISPONIBLES.filter((l) => LANGUES_PRIORITAIRES.includes(l.code)),
    // Toutes les autres langues disponibles
    ...LANGUES_DISPONIBLES.filter((l) => !LANGUES_PRIORITAIRES.includes(l.code) && l.code !== "fr" && l.code !== "en"),
  ];

  function showMsg(msg: string, type: "success" | "error" | "info" = "success") {
    setToast({ visible: true, message: msg, type });
    setTimeout(() => setToast((t) => ({ ...t, visible: false })), 2800);
  }

  async function handleSend() {
    if (!inputText.trim()) return;
    const textToSend = inputText.trim();
    setInputText("");
    const userMsgId = Date.now().toString();
    setMessages(prev => [...prev, { id: userMsgId, text: textToSend, isUser: true }]);
    setLoading(true);
    try {
      const result = await traduire(textToSend, fromLang, toLang);
      const botMsgId = (Date.now() + 1).toString();
      setMessages(prev => [...prev, {
        id: botMsgId,
        text: result.traduction,
        isUser: false,
        fiabilite: result.fiabilite,
        avertissement: result.avertissement,
      }]);
      Haptics.notificationAsync(result.fiabilite === "haute" ? Haptics.NotificationFeedbackType.Success : Haptics.NotificationFeedbackType.Warning).catch(() => {});
      if (result.fiabilite === "basse") showMsg("Traduction incertaine", "error");
      else if (result.fiabilite === "moyenne" && result.avertissement) showMsg(result.avertissement, "info");
      else if (result.fiabilite === "haute") showMsg("Traduction fiable ✓", "success");
    } catch {
      showMsg("Erreur de traduction", "error");
      const botMsgId = (Date.now() + 1).toString();
      setMessages(prev => [...prev, { id: botMsgId, text: "❌ Erreur lors de la traduction", isUser: false, fiabilite: "basse" }]);
    } finally {
      setLoading(false);
    }
  }

  function swapLanguages() {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
    setFromLang(toLang);
    setToLang(fromLang);
  }

  async function copyToClipboard(text: string) {
    try {
      await Clipboard.setStringAsync(text);
      showMsg("Copié !", "success");
    } catch {
      showMsg("Impossible de copier", "error");
    }
  }

  function openCorrectionModal(original: string, translated: string) {
    setCurrentTranslation({ original, translated, fromLang, toLang });
    setCorrectionText("");
    setShowCorrectionModal(true);
  }

  async function envoyerCorrection() {
    if (!correctionText.trim() || !currentTranslation) { showMsg("Veuillez entrer la correction", "error"); return; }
    try {
      await signalerTraductionIncorrecte(
        currentTranslation.original,
        currentTranslation.translated,
        correctionText.trim(),
        currentTranslation.fromLang,
        currentTranslation.toLang,
        "Correction"
      );
      setShowCorrectionModal(false);
      showMsg("Merci !", "success");
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});
    } catch {
      showMsg("Erreur", "error");
    }
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 + 84 : insets.bottom + 84;
  const closePickers = () => {
    setShowFromPicker(false);
    setShowToPicker(false);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.background }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 0 : 0}
    >
      <View style={{ flex: 1 }}>
        <View style={[styles.langHeader, { paddingTop: topPad + 8 }]}>
          <Pressable style={[styles.langChip, { backgroundColor: colors.card }]} onPress={() => { setShowFromPicker(!showFromPicker); setShowToPicker(false); }}>
            <Text style={[styles.langChipText, { color: colors.foreground }]}>{getLanguageName(fromLang)}</Text>
            <MaterialIcons name="arrow-drop-down" size={14} color={colors.mutedForeground} />
          </Pressable>
          <Pressable style={[styles.swapChip, { backgroundColor: colors.gold }]} onPress={swapLanguages}>
            <MaterialIcons name="swap-horiz" size={16} color="#fff" />
          </Pressable>
          <Pressable style={[styles.langChip, { backgroundColor: colors.card }]} onPress={() => { setShowToPicker(!showToPicker); setShowFromPicker(false); }}>
            <Text style={[styles.langChipText, { color: colors.foreground }]}>{getLanguageName(toLang)}</Text>
            <MaterialIcons name="arrow-drop-down" size={14} color={colors.mutedForeground} />
          </Pressable>
        </View>

        {showFromPicker && <LanguagePicker languages={languesOrganisees} selected={fromLang} onSelect={(c: string) => { setFromLang(c); setShowFromPicker(false); }} colors={colors} title="Langue source" />}
        {showToPicker && <LanguagePicker languages={languesOrganisees} selected={toLang} onSelect={(c: string) => { setToLang(c); setShowToPicker(false); }} colors={colors} title="Langue cible" />}

        <ScrollView
          style={{ flex: 1, paddingHorizontal: 16 }}
          contentContainerStyle={{ paddingBottom: 16 }}
          onScrollBeginDrag={closePickers}
        >
          {messages.map((msg, index) => (
            <View key={msg.id} style={[styles.messageRow, msg.isUser ? styles.userRow : styles.botRow]}>
              <View style={[styles.bubble, msg.isUser ? { backgroundColor: colors.deepGreen } : { backgroundColor: colors.card }]}>
                {!msg.isUser && msg.fiabilite && (
                  <View style={styles.bubbleHeader}>
                    <View style={[styles.fiabiliteBadge, { backgroundColor: (msg.fiabilite === "haute" ? "#10b981" : msg.fiabilite === "moyenne" ? "#f59e0b" : "#ef4444") + "20" }]}>
                      <MaterialIcons name={msg.fiabilite === "haute" ? "check-circle" : msg.fiabilite === "moyenne" ? "warning" : "cancel"} size={10} color={msg.fiabilite === "haute" ? "#10b981" : msg.fiabilite === "moyenne" ? "#f59e0b" : "#ef4444"} />
                      <Text style={[styles.fiabiliteText, { color: msg.fiabilite === "haute" ? "#10b981" : msg.fiabilite === "moyenne" ? "#f59e0b" : "#ef4444" }]}>
                        {msg.fiabilite === "haute" ? "Fiable" : msg.fiabilite === "moyenne" ? "À vérifier" : "Douteuse"}
                      </Text>
                    </View>
                    {msg.fiabilite !== "haute" && (
                      <Pressable onPress={() => openCorrectionModal(messages[index-1]?.text || "", msg.text)} style={styles.correctionBtn}>
                        <MaterialIcons name="flag" size={12} color="#ef4444" />
                      </Pressable>
                    )}
                    <Pressable onPress={() => copyToClipboard(msg.text)} style={styles.copyBtn}>
                      <MaterialIcons name="content-copy" size={12} color={colors.mutedForeground} />
                    </Pressable>
                  </View>
                )}
                <Text style={[styles.messageText, { color: msg.isUser ? "#fff" : colors.foreground }]}>{msg.text}</Text>
                {!msg.isUser && msg.avertissement && <Text style={[styles.warningText, { color: colors.mutedForeground }]}>{msg.avertissement}</Text>}
              </View>
            </View>
          ))}
          {loading && (
            <View style={styles.loadingIndicator}>
              <ActivityIndicator size="small" color={colors.deepGreen} />
              <Text style={{ color: colors.mutedForeground, marginLeft: 8 }}>Traduction...</Text>
            </View>
          )}
        </ScrollView>

        <View style={[styles.inputBar, { backgroundColor: colors.card, borderTopColor: colors.border, paddingBottom: bottomPad > 20 ? bottomPad : 12 }]}>
          <TextInput
            style={[styles.textInput, { backgroundColor: colors.secondary, color: colors.foreground }]}
            placeholder="Écrivez votre texte..."
            placeholderTextColor={colors.mutedForeground}
            value={inputText}
            onChangeText={setInputText}
            multiline
            returnKeyType="send"
            onSubmitEditing={handleSend}
          />
          <Pressable onPress={handleSend} disabled={loading || !inputText.trim()} style={[styles.sendBtn, (!inputText.trim() || loading) && { opacity: 0.5 }]}>
            <MaterialIcons name="send" size={22} color={colors.deepGreen} />
          </Pressable>
        </View>
      </View>

      <Modal visible={showCorrectionModal} transparent animationType="slide" onRequestClose={() => setShowCorrectionModal(false)}>
        <View style={styles.modalOverlay}>
          <View style={[styles.modalContent, { backgroundColor: colors.card }]}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>Signaler une erreur</Text>
            <Text style={[styles.modalSubtitle, { color: colors.mutedForeground }]}>Original : "{currentTranslation?.original}"</Text>
            <Text style={[styles.modalSubtitle, { color: colors.mutedForeground }]}>Actuelle : "{currentTranslation?.translated}"</Text>
            <TextInput
              style={[styles.correctionInput, { backgroundColor: colors.secondary, color: colors.foreground, borderColor: colors.border }]}
              placeholder="Entrez la traduction correcte..."
              placeholderTextColor={colors.mutedForeground}
              value={correctionText}
              onChangeText={setCorrectionText}
              multiline
              numberOfLines={3}
            />
            <View style={styles.modalActions}>
              <TouchableOpacity style={[styles.modalBtn, { backgroundColor: colors.secondary }]} onPress={() => setShowCorrectionModal(false)}>
                <Text style={{ color: colors.foreground }}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.modalBtn, { backgroundColor: colors.deepGreen }]} onPress={envoyerCorrection}>
                <Text style={{ color: "#fff" }}>Envoyer</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Toast message={toast.message} visible={toast.visible} type={toast.type} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  langHeader: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 12, paddingHorizontal: 16, paddingVertical: 12 },
  langChip: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 30, elevation: 2 },
  langChipText: { fontSize: 14, fontWeight: "600" },
  swapChip: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  messageRow: { marginVertical: 6 },
  userRow: { alignItems: "flex-end" },
  botRow: { alignItems: "flex-start" },
  bubble: { maxWidth: "80%", paddingVertical: 10, paddingHorizontal: 14, borderRadius: 20, elevation: 1 },
  bubbleHeader: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 6 },
  fiabiliteBadge: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 2, borderRadius: 12 },
  fiabiliteText: { fontSize: 10, fontWeight: "600" },
  correctionBtn: { padding: 2 },
  copyBtn: { padding: 2 },
  messageText: { fontSize: 15, lineHeight: 20 },
  warningText: { fontSize: 11, marginTop: 6, fontStyle: "italic" },
  loadingIndicator: { flexDirection: "row", alignItems: "center", justifyContent: "center", paddingVertical: 12 },
  inputBar: { flexDirection: "row", alignItems: "center", gap: 10, paddingHorizontal: 16, paddingVertical: 12, borderTopWidth: 1 },
  textInput: { flex: 1, fontSize: 16, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 30, maxHeight: 100 },
  sendBtn: { padding: 8 },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center" },
  modalContent: { width: "90%", maxWidth: 400, borderRadius: 20, padding: 20, gap: 16 },
  modalTitle: { fontSize: 18, fontWeight: "700" },
  modalSubtitle: { fontSize: 13 },
  correctionInput: { borderWidth: 1, borderRadius: 12, padding: 12, fontSize: 15, minHeight: 80, textAlignVertical: "top" },
  modalActions: { flexDirection: "row", justifyContent: "flex-end", gap: 12 },
  modalBtn: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 10 },
  picker: { marginHorizontal: 16, marginTop: 8, padding: 8, maxHeight: 280 },
  pickerTitle: { fontSize: 11, fontWeight: "600", textTransform: "uppercase", marginBottom: 8, paddingHorizontal: 4 },
  pickerItem: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 12, paddingVertical: 10, borderRadius: 8 },
  pickerText: { fontSize: 14 },
});