// @ts-nocheck
import { Feather } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import React, { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Toast } from "@/components/ui";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/context/I18nContext";
import { useColors } from "@/hooks/useColors";
import { useHaptics } from "@/hooks/useHaptics";
import { QUIZ_LANGUAGES } from "@/theme/quiz";

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatTimeAgo(iso: string): string {
  if (!iso) return "";
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return "maintenant";
  if (mins < 60) return `${mins}m`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h`;
  return `${Math.floor(hrs / 24)}j`;
}

function Avatar({ name, size = 40, color }: { name: string; size?: number; color: string }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, backgroundColor: color, alignItems: "center", justifyContent: "center" }}>
      <Text style={{ color: "#fff", fontWeight: "800", fontSize: size * 0.38 }}>
        {(name ?? "?").slice(0, 2).toUpperCase()}
      </Text>
    </View>
  );
}

// ─── Comments Modal ───────────────────────────────────────────────────────────
function CommentsModal({ post, visible, onClose }: {
  post: any; visible: boolean; onClose: () => void;
}) {
  const colors = useColors();
  const { lang } = useI18n();
  const { user, addComment, posts } = useApp();
  const { impact } = useHaptics();
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const insets = useSafeAreaInsets();

  const livePost = posts.find(p => p.id === post?.id) ?? post;

  async function submit() {
    if (!text.trim() || !user || sending) return;
    impact();
    setSending(true);
    try {
      await addComment(post.id, {
        authorId: user.id,
        authorName: user.name,
        content: text.trim(),
      });
      setText("");
    } finally {
      setSending(false);
    }
  }

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} transparent>
      <Pressable style={styles.modalOverlay} onPress={onClose} />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={[styles.modalSheet, { backgroundColor: colors.card, paddingBottom: insets.bottom + 16 }]}
      >
        <View style={[styles.handle, { backgroundColor: colors.border }]} />
        <View style={styles.modalHeader}>
          <Text style={[styles.modalTitle, { color: colors.foreground }]}>
            {(livePost?.comments?.length ?? 0)} {lang === "fr" ? "commentaires" : "comments"}
          </Text>
          <Pressable onPress={onClose} style={styles.closeBtn}>
            <Feather name="x" size={18} color={colors.mutedForeground} />
          </Pressable>
        </View>

        <FlatList
          data={livePost?.comments ?? []}
          keyExtractor={(c: any) => c.id}
          style={{ maxHeight: 360 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyComments}>
              <Feather name="message-circle" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>
                {lang === "fr" ? "Aucun commentaire" : "No comments yet"}
              </Text>
            </View>
          }
          renderItem={({ item, index }: { item: any; index: number }) => (
            <View>
              <View style={[styles.commentRow, { borderBottomColor: colors.border }]}>
                <Avatar name={item.authorName} size={34} color={colors.deepGreen} />
                <View style={{ flex: 1, gap: 2 }}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
                    <Text style={[styles.commentAuthor, { color: colors.foreground }]}>{item.authorName}</Text>
                    <Text style={[styles.commentTime, { color: colors.mutedForeground }]}>· {formatTimeAgo(item.createdAt)}</Text>
                  </View>
                  <Text style={[styles.commentBody, { color: colors.foreground }]}>{item.content}</Text>
                </View>
              </View>
            </View>
          )}
        />

        <View style={[styles.commentInputArea, { borderTopColor: colors.border }]}>
          <Avatar name={user?.name ?? "?"} size={34} color={colors.midGreen} />
          <TextInput
            style={[styles.commentInput, { backgroundColor: colors.secondary, color: colors.foreground, borderColor: colors.border }]}
            placeholder={lang === "fr" ? "Ajouter un commentaire..." : "Add a comment..."}
            placeholderTextColor={colors.mutedForeground}
            value={text}
            onChangeText={setText}
            returnKeyType="send"
            onSubmitEditing={submit}
          />
          <Pressable
            style={[styles.sendBtn, { backgroundColor: text.trim() && !sending ? colors.deepGreen : colors.muted }]}
            onPress={submit}
            disabled={!text.trim() || sending}
          >
            {sending
              ? <ActivityIndicator size="small" color="#fff" />
              : <Feather name="arrow-up" size={16} color={text.trim() ? "#fff" : colors.mutedForeground} />
            }
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Post Card ────────────────────────────────────────────────────────────────
function PostCard({ post, index }: { post: any; index: number }) {
  const colors = useColors();
  const { user, toggleLike } = useApp();
  const { impact } = useHaptics();
  const isLiked = user ? (post.likes ?? []).includes(user.id) : false;
  const langInfo = QUIZ_LANGUAGES.find(l => l.code === post.language);
  const [showComments, setShowComments] = useState(false);

  const scale = useSharedValue(1);
  const heartStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  async function handleLike() {
    if (!user) return;
    impact();
    scale.value = withSpring(1.4, { duration: 150 }, () => {
      scale.value = withSpring(1, { duration: 150 });
    });
    await toggleLike(post.id);
  }

  return (
    <>
      <View style={[styles.postCard, { borderBottomColor: colors.border, backgroundColor: colors.card }]}>
          <View style={styles.postLeft}>
            <Avatar name={post.authorName} size={42} color={colors.deepGreen} />
            <View style={[styles.threadLine, { backgroundColor: colors.border }]} />
          </View>
          <View style={styles.postRight}>
            <View style={styles.postHeaderRow}>
              <Text style={[styles.postAuthorName, { color: colors.foreground }]}>{post.authorName}</Text>
              {langInfo && (
                <View style={[styles.langPill, { backgroundColor: colors.secondary }]}>
                  <Text style={[styles.langPillText, { color: colors.mutedForeground }]}>{langInfo.flag} {langInfo.name}</Text>
                </View>
              )}
              <Text style={[styles.postTime, { color: colors.mutedForeground }]}>· {formatTimeAgo(post.createdAt)}</Text>
            </View>

            <Text style={[styles.postBody, { color: colors.foreground }]}>{post.content}</Text>

            {post.imageUri ? (
              <Image source={{ uri: post.imageUri }} style={styles.postImage} resizeMode="cover" />
            ) : null}

            {post.translation ? (
              <View style={[styles.quoteBox, { backgroundColor: colors.secondary, borderLeftColor: colors.midGreen }]}>
                <Feather name="globe" size={12} color={colors.midGreen} />
                <Text style={[styles.quoteText, { color: colors.mutedForeground }]}>{post.translation}</Text>
              </View>
            ) : null}

            <View style={styles.actionsRow}>
              <Pressable style={styles.actionItem} onPress={() => setShowComments(true)}>
                <Feather name="message-circle" size={18} color={colors.mutedForeground} />
                {(post.comments?.length ?? 0) > 0 && (
                  <Text style={[styles.actionNum, { color: colors.mutedForeground }]}>{post.comments.length}</Text>
                )}
              </Pressable>
              <Pressable style={styles.actionItem} onPress={handleLike}>
                <Animated.View style={heartStyle}>
                  <Feather name="heart" size={18} color={isLiked ? "#e0245e" : colors.mutedForeground} />
                </Animated.View>
                {(post.likes?.length ?? 0) > 0 && (
                  <Text style={[styles.actionNum, { color: isLiked ? "#e0245e" : colors.mutedForeground }]}>
                    {post.likes.length}
                  </Text>
                )}
              </Pressable>
              <Pressable style={styles.actionItem}>
                <Feather name="share" size={18} color={colors.mutedForeground} />
              </Pressable>
            </View>
          </View>
        </View>
      <CommentsModal
        post={post}
        visible={showComments}
        onClose={() => setShowComments(false)}
      />
    </>
  );
}

// ─── Compose Modal ────────────────────────────────────────────────────────────
function ComposeModal({ visible, onClose, onPosted }: {
  visible: boolean; onClose: () => void; onPosted: () => void;
}) {
  const colors = useColors();
  const { lang } = useI18n();
  const { user, createPost } = useApp();
  const insets = useSafeAreaInsets();
  const [content, setContent] = useState("");
  const [postLang, setPostLang] = useState("sw");
  const [translation, setTranslation] = useState("");
  const [showLangPicker, setShowLangPicker] = useState(false);
  const [imageUri, setImageUri] = useState<string | null>(null);
  const [posting, setPosting] = useState(false);

  const LANGS = QUIZ_LANGUAGES.filter(l => ["sw", "ln", "yo", "ha", "zu", "fr", "en"].includes(l.code));

  async function pickImage(source: "camera" | "gallery") {
    let result: ImagePicker.ImagePickerResult;
    if (source === "camera") {
      const { granted } = await ImagePicker.requestCameraPermissionsAsync();
      if (!granted) return;
      result = await ImagePicker.launchCameraAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7 });
    } else {
      const { granted } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!granted) return;
      result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7 });
    }
    if (!result.canceled && result.assets[0]) setImageUri(result.assets[0].uri);
  }

  async function submit() {
    if (!content.trim() || !user || posting) return;
    setPosting(true);
    try {
      await createPost({
        authorId: user.id,
        authorName: user.name,
        content: content.trim(),
        language: postLang,
        translation: translation.trim() || undefined,
        imageUri: imageUri || undefined,
      });
      setContent("");
      setTranslation("");
      setImageUri(null);
      onClose();
      onPosted();
    } finally {
      setPosting(false);
    }
  }

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose} transparent>
      <Pressable style={styles.modalOverlay} onPress={onClose} />
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={[styles.composeSheet, { backgroundColor: colors.card, paddingBottom: insets.bottom + 16 }]}
      >
        <View style={[styles.handle, { backgroundColor: colors.border }]} />
        <View style={styles.composeHeader}>
          <Pressable onPress={onClose}>
            <Text style={[styles.cancelLink, { color: colors.mutedForeground }]}>
              {lang === "fr" ? "Annuler" : "Cancel"}
            </Text>
          </Pressable>
          <Text style={[styles.composeTitle, { color: colors.foreground }]}>
            {lang === "fr" ? "Nouvelle publication" : "New post"}
          </Text>
          <Pressable
            style={[styles.postBtn, { backgroundColor: content.trim() && !posting ? colors.deepGreen : colors.muted }]}
            onPress={submit}
            disabled={!content.trim() || posting}
          >
            {posting
              ? <ActivityIndicator size="small" color="#fff" />
              : <Text style={[styles.postBtnText, { color: content.trim() ? "#fff" : colors.mutedForeground }]}>
                  {lang === "fr" ? "Publier" : "Post"}
                </Text>
            }
          </Pressable>
        </View>

        <View style={styles.composeBody}>
          <Avatar name={user?.name ?? "?"} size={42} color={colors.midGreen} />
          <View style={{ flex: 1, gap: 10 }}>
            <TextInput
              style={[styles.composeInput, { color: colors.foreground }]}
              placeholder={lang === "fr" ? "Partagez une phrase africaine..." : "Share an African phrase..."}
              placeholderTextColor={colors.mutedForeground}
              value={content}
              onChangeText={setContent}
              multiline
              autoFocus
            />
            <TextInput
              style={[styles.composeTranslation, { color: colors.mutedForeground, borderColor: colors.border }]}
              placeholder={lang === "fr" ? "Traduction (optionnel)" : "Translation (optional)"}
              placeholderTextColor={colors.mutedForeground + "80"}
              value={translation}
              onChangeText={setTranslation}
            />
          </View>
        </View>

        {imageUri && (
          <View style={styles.imagePreviewContainer}>
            <Image source={{ uri: imageUri }} style={styles.imagePreview} resizeMode="cover" />
            <Pressable
              style={[styles.imageRemoveBtn, { backgroundColor: colors.card }]}
              onPress={() => setImageUri(null)}
            >
              <Feather name="x" size={14} color={colors.foreground} />
            </Pressable>
          </View>
        )}

        <View style={[styles.composeFooter, { borderTopColor: colors.border }]}>
          <View style={styles.composeFooterLeft}>
            <Pressable style={styles.mediaBtn} onPress={() => pickImage("gallery")}>
              <Feather name="image" size={20} color={colors.deepGreen} />
            </Pressable>
            <Pressable style={styles.mediaBtn} onPress={() => pickImage("camera")}>
              <Feather name="camera" size={20} color={colors.deepGreen} />
            </Pressable>
          </View>
          <Pressable
            style={[styles.langSelectorBtn, { backgroundColor: colors.secondary, borderColor: colors.border }]}
            onPress={() => setShowLangPicker(!showLangPicker)}
          >
            <Text style={[styles.langSelectorText, { color: colors.foreground }]}>
              {LANGS.find(l => l.code === postLang)?.flag} {LANGS.find(l => l.code === postLang)?.name ?? postLang}
            </Text>
            <Feather name="chevron-down" size={13} color={colors.mutedForeground} />
          </Pressable>
        </View>

        {showLangPicker && (
          <View style={[styles.langPicker, { backgroundColor: colors.card, borderColor: colors.border }]}>
            {LANGS.map(l => (
              <Pressable
                key={l.code}
                style={[styles.langOption, l.code === postLang && { backgroundColor: colors.deepGreen + "20" }]}
                onPress={() => { setPostLang(l.code); setShowLangPicker(false); }}
              >
                <Text style={[styles.langOptionText, { color: l.code === postLang ? colors.deepGreen : colors.foreground }]}>
                  {l.flag} {l.name}
                </Text>
                {l.code === postLang && <Feather name="check" size={14} color={colors.deepGreen} />}
              </Pressable>
            ))}
          </View>
        )}
      </KeyboardAvoidingView>
    </Modal>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function SocialScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { lang } = useI18n();
  const { user, posts, refreshPosts, isLoading } = useApp();
  const { impact } = useHaptics();

  const [refreshing, setRefreshing] = useState(false);
  const [showCompose, setShowCompose] = useState(false);
  const [toast, setToast] = useState({ visible: false, message: "" });

  function showMsg(msg: string) {
    setToast({ visible: true, message: msg });
    setTimeout(() => setToast(t => ({ ...t, visible: false })), 2500);
  }

  async function handleRefresh() {
    setRefreshing(true);
    await refreshPosts();
    setRefreshing(false);
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 + 84 : insets.bottom + 84;

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <FlatList
        data={posts}
        keyExtractor={p => p.id}
        renderItem={({ item, index }) => (
          <PostCard post={item} index={index} />
        )}
        contentContainerStyle={{ paddingTop: topPad, paddingBottom: bottomPad }}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={colors.deepGreen}
          />
        }
        ListHeaderComponent={
          <View>
            <View style={[styles.topBar, { borderBottomColor: colors.border, paddingTop: 12 }]}>
              <View style={styles.tabsRow}>
                <Pressable style={styles.tabItem}>
                  <Text style={[styles.tabLabel, { color: colors.foreground, fontWeight: "700" }]}>
                    {lang === "fr" ? "Publications" : "For You"}
                  </Text>
                  <View style={[styles.tabIndicator, { backgroundColor: colors.deepGreen }]} />
                </Pressable>
              </View>
            </View>
            <Pressable
              style={[styles.newPostRow, { borderBottomColor: colors.border }]}
              onPress={() => { impact(); setShowCompose(true); }}
            >
              <Avatar name={user?.name ?? "?"} size={42} color={colors.midGreen} />
              <Text style={[styles.newPostHint, { color: colors.mutedForeground }]}>
                {lang === "fr" ? "Partagez une phrase africaine..." : "Share an African phrase..."}
              </Text>
              <View style={[styles.miniPostBtn, { backgroundColor: colors.deepGreen }]}>
                <Text style={styles.miniPostBtnText}>{lang === "fr" ? "Publier" : "Post"}</Text>
              </View>
            </Pressable>
          </View>
        }
        ListEmptyComponent={
          isLoading ? (
            <ActivityIndicator color={colors.deepGreen} size="large" style={{ marginTop: 60 }} />
          ) : (
            <View style={styles.emptyFeed}>
              <Text style={{ fontSize: 40 }}>🌍</Text>
              <Text style={[styles.emptyFeedTitle, { color: colors.foreground }]}>
                {lang === "fr" ? "Aucune publication" : "No posts yet"}
              </Text>
              <Text style={[styles.emptyFeedSub, { color: colors.mutedForeground }]}>
                {lang === "fr" ? "Soyez le premier à partager !" : "Be the first to share!"}
              </Text>
            </View>
          )
        }
      />

      <Pressable
        style={[styles.fab, { backgroundColor: colors.deepGreen, bottom: bottomPad - 60 }]}
        onPress={() => { impact(); setShowCompose(true); }}
      >
        <Feather name="edit-2" size={22} color="#fff" />
      </Pressable>

      <ComposeModal
        visible={showCompose}
        onClose={() => setShowCompose(false)}
        onPosted={() => showMsg(lang === "fr" ? "Publié !" : "Posted!")}
      />
      <Toast message={toast.message} visible={toast.visible} />
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: { flex: 1 },
  topBar: { borderBottomWidth: StyleSheet.hairlineWidth },
  tabsRow: { flexDirection: "row" },
  tabItem: { flex: 1, alignItems: "center", paddingVertical: 14, position: "relative" },
  tabLabel: { fontSize: 15 },
  tabIndicator: { position: "absolute", bottom: 0, left: "25%", right: "25%", height: 3, borderRadius: 2 },
  newPostRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth },
  newPostHint: { flex: 1, fontSize: 16 },
  miniPostBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 },
  miniPostBtnText: { color: "#fff", fontWeight: "700", fontSize: 14 },
  postCard: { flexDirection: "row", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: StyleSheet.hairlineWidth, gap: 12 },
  postLeft: { alignItems: "center" },
  threadLine: { width: 2, flex: 1, marginTop: 4, borderRadius: 1, opacity: 0.2 },
  postRight: { flex: 1, gap: 6 },
  postHeaderRow: { flexDirection: "row", alignItems: "center", gap: 6, flexWrap: "wrap" },
  postAuthorName: { fontSize: 15, fontWeight: "700" },
  langPill: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 100 },
  langPillText: { fontSize: 11, fontWeight: "600" },
  postTime: { fontSize: 13 },
  postBody: { fontSize: 16, lineHeight: 22 },
  postImage: { width: "100%", height: 220, borderRadius: 14, marginTop: 4 },
  quoteBox: { flexDirection: "row", alignItems: "flex-start", gap: 8, borderLeftWidth: 3, paddingLeft: 10, paddingVertical: 6, borderRadius: 2 },
  quoteText: { fontSize: 13, fontStyle: "italic", flex: 1, lineHeight: 18 },
  actionsRow: { flexDirection: "row", gap: 28, marginTop: 6 },
  actionItem: { flexDirection: "row", alignItems: "center", gap: 5 },
  actionNum: { fontSize: 13 },
  fab: { position: "absolute", right: 20, width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center", elevation: 6, shadowColor: "#000", shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.25, shadowRadius: 6 },
  composeSheet: { position: "absolute", bottom: 0, left: 0, right: 0, borderTopLeftRadius: 20, borderTopRightRadius: 20, padding: 16, gap: 14 },
  composeHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cancelLink: { fontSize: 15 },
  composeTitle: { fontSize: 16, fontWeight: "700" },
  postBtn: { paddingHorizontal: 18, paddingVertical: 8, borderRadius: 20, minWidth: 70, alignItems: "center" },
  postBtnText: { fontWeight: "700", fontSize: 14 },
  composeBody: { flexDirection: "row", gap: 12, alignItems: "flex-start" },
  composeInput: { fontSize: 17, lineHeight: 24, minHeight: 80 },
  composeTranslation: { fontSize: 14, borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 8 },
  composeFooter: { borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  composeFooterLeft: { flexDirection: "row", gap: 4 },
  mediaBtn: { padding: 8, borderRadius: 20 },
  langSelectorBtn: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 20, borderWidth: 1 },
  langSelectorText: { fontSize: 13, fontWeight: "600" },
  langPicker: { borderRadius: 14, borderWidth: 1, overflow: "hidden", marginTop: -8 },
  langOption: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12 },
  langOptionText: { fontSize: 14 },
  imagePreviewContainer: { position: "relative", marginHorizontal: 54 },
  imagePreview: { width: "100%", height: 180, borderRadius: 14 },
  imageRemoveBtn: { position: "absolute", top: 8, right: 8, width: 28, height: 28, borderRadius: 14, alignItems: "center", justifyContent: "center", elevation: 3 },
  modalOverlay: { position: "absolute", top: 0, bottom: 0, left: 0, right: 0, backgroundColor: "rgba(0,0,0,0.45)" },
  modalSheet: { position: "absolute", bottom: 0, left: 0, right: 0, borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 16, gap: 12 },
  handle: { width: 36, height: 4, borderRadius: 2, alignSelf: "center" },
  modalHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modalTitle: { fontSize: 17, fontWeight: "700" },
  closeBtn: { padding: 4 },
  commentRow: { flexDirection: "row", gap: 10, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  commentAuthor: { fontSize: 14, fontWeight: "700" },
  commentTime: { fontSize: 12 },
  commentBody: { fontSize: 14, lineHeight: 20 },
  commentInputArea: { flexDirection: "row", gap: 10, alignItems: "center", borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 12 },
  commentInput: { flex: 1, borderRadius: 22, borderWidth: 1.5, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14 },
  sendBtn: { width: 38, height: 38, borderRadius: 19, alignItems: "center", justifyContent: "center" },
  emptyComments: { alignItems: "center", gap: 10, paddingVertical: 32 },
  emptyText: { fontSize: 14, textAlign: "center" },
  emptyFeed: { alignItems: "center", gap: 10, paddingVertical: 60 },
  emptyFeedTitle: { fontSize: 18, fontWeight: "700" },
  emptyFeedSub: { fontSize: 14 },
});
