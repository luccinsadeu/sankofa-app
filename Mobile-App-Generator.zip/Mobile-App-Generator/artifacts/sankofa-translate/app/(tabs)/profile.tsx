// app/(tabs)/profile.tsx
import { MaterialIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  Alert,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";
import { useHaptics } from "@/hooks/useHaptics";

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { user, logout, totalScore, tierProgress } = useApp();
  const { impact } = useHaptics();
  const [avatar, setAvatar] = useState("🐘");
  const [memberSince, setMemberSince] = useState("");

  useEffect(() => {
    loadAvatar();
  }, [user]);

  const loadAvatar = async () => {
    const savedAvatar = await AsyncStorage.getItem("@sankofa_avatar");
    if (savedAvatar) setAvatar(savedAvatar);
    else if (user?.avatar) setAvatar(user.avatar);

    if (user?.joinedAt) {
      const date = new Date(user.joinedAt);
      setMemberSince(date.toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" }));
    }
  };

  // Calculate real stats from tierProgress
  const tiersUnlocked = Object.values(tierProgress).reduce((sum, tp) => sum + tp.unlockedTier, 0);
  const languagesStarted = Object.keys(tierProgress).length;
  const wordsLearned = Math.max(0, Math.floor(totalScore / 5));

  // Score rank label
  const getRank = () => {
    if (totalScore >= 500) return { label: "Expert Africain", icon: "🏆", color: colors.gold };
    if (totalScore >= 200) return { label: "Linguiste", icon: "⭐", color: colors.midGreen };
    if (totalScore >= 50) return { label: "Explorateur", icon: "🌍", color: colors.deepGreen };
    return { label: "Débutant", icon: "🌱", color: colors.mutedForeground };
  };

  const rank = getRank();

  const handleLogout = () => {
    Alert.alert(
      "Déconnexion",
      "Voulez-vous vraiment vous déconnecter ?",
      [
        { text: "Annuler", style: "cancel" },
        {
          text: "Déconnecter",
          style: "destructive",
          onPress: async () => {
            impact();
            await logout();
            await AsyncStorage.multiRemove(["@sankofa_user", "@sankofa_avatar", "onboardingCompleted"]);
            router.replace("/");
          },
        },
      ]
    );
  };

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 + 84 : insets.bottom + 84;
  const userName = user?.name || "Invité";
  const userEmail = user?.email || "Non connecté";

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ paddingTop: topPad + 16, paddingBottom: bottomPad, paddingHorizontal: 20, gap: 20 }}
      showsVerticalScrollIndicator={false}
    >
      {/* Avatar + Nom */}
      <View style={styles.avatarSection}>
        <View style={[styles.avatarRing, { borderColor: colors.deepGreen }]}>
          <View style={[styles.avatarInner, { backgroundColor: colors.secondary }]}>
            <Text style={styles.avatarEmoji}>{avatar}</Text>
          </View>
        </View>
        <Text style={[styles.userName, { color: colors.foreground }]}>{userName}</Text>
        <Text style={[styles.userEmail, { color: colors.mutedForeground }]}>{userEmail}</Text>

        {/* Rank badge */}
        <View style={[styles.rankBadge, { backgroundColor: rank.color + "20", borderColor: rank.color + "40" }]}>
          <Text style={{ fontSize: 14 }}>{rank.icon}</Text>
          <Text style={[styles.rankLabel, { color: rank.color }]}>{rank.label}</Text>
        </View>
      </View>

      {/* Score total prominent */}
      <View style={[styles.scoreCard, { backgroundColor: colors.deepGreen }]}>
        <View style={styles.scoreInner}>
          <Text style={styles.scoreLabel}>Score Total</Text>
          <Text style={styles.scoreValue}>{totalScore.toLocaleString()}</Text>
          <Text style={styles.scoreUnit}>points</Text>
        </View>
        <View style={styles.scoreDivider} />
        <View style={styles.scoreLangBlock}>
          <Text style={styles.scoreLangValue}>{languagesStarted}</Text>
          <Text style={styles.scoreLangLabel}>langue{languagesStarted !== 1 ? "s" : ""}</Text>
        </View>
      </View>

      {/* Statistiques */}
      <View style={[styles.statsCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <StatItem icon="check-circle" label="Niveaux débloqués" value={String(tiersUnlocked)} color={colors.deepGreen} colors={colors} />
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <StatItem icon="menu-book" label="Mots appris" value={String(wordsLearned)} color={colors.gold} colors={colors} />
        <View style={[styles.statDivider, { backgroundColor: colors.border }]} />
        <StatItem icon="language" label="Langues" value={String(languagesStarted)} color={colors.terracotta} colors={colors} />
      </View>

      {/* Infos */}
      <View style={[styles.infoCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={styles.infoRow}>
          <MaterialIcons name="calendar-today" size={17} color={colors.mutedForeground} />
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
            Membre {memberSince ? `depuis le ${memberSince}` : "récemment"}
          </Text>
        </View>
        <View style={[styles.infoSep, { backgroundColor: colors.border }]} />
        <View style={styles.infoRow}>
          <MaterialIcons name="smartphone" size={17} color={colors.mutedForeground} />
          <Text style={[styles.infoText, { color: colors.mutedForeground }]}>
            Sankofa Translate v1.0.0
          </Text>
        </View>
      </View>

      {/* Bouton déconnexion */}
      <Pressable
        style={({ pressed }) => [
          styles.logoutBtn,
          { backgroundColor: colors.card, borderColor: colors.destructive },
          pressed && { opacity: 0.7 },
        ]}
        onPress={handleLogout}
      >
        <MaterialIcons name="logout" size={18} color={colors.destructive} />
        <Text style={[styles.logoutText, { color: colors.destructive }]}>Se déconnecter</Text>
      </Pressable>
    </ScrollView>
  );
}

function StatItem({ icon, label, value, color, colors }: { icon: string; label: string; value: string; color: string; colors: any }) {
  return (
    <View style={styles.statItem}>
      <View style={[styles.statIconBg, { backgroundColor: color + "18" }]}>
        <MaterialIcons name={icon as any} size={16} color={color} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
        <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  avatarSection: { alignItems: "center", gap: 8, paddingTop: 8 },
  avatarRing: { width: 108, height: 108, borderRadius: 54, borderWidth: 3, padding: 4, marginBottom: 4 },
  avatarInner: { flex: 1, borderRadius: 50, alignItems: "center", justifyContent: "center" },
  avatarEmoji: { fontSize: 52 },
  userName: { fontSize: 22, fontWeight: "800" },
  userEmail: { fontSize: 14 },
  rankBadge: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, borderWidth: 1, marginTop: 4 },
  rankLabel: { fontSize: 13, fontWeight: "700" },
  scoreCard: { borderRadius: 20, padding: 20, flexDirection: "row", alignItems: "center" },
  scoreInner: { flex: 1, alignItems: "center" },
  scoreLabel: { color: "rgba(255,255,255,0.75)", fontSize: 12, fontWeight: "600", letterSpacing: 1, textTransform: "uppercase" },
  scoreValue: { color: "#fff", fontSize: 40, fontWeight: "900", lineHeight: 46 },
  scoreUnit: { color: "rgba(255,255,255,0.75)", fontSize: 13, fontWeight: "600" },
  scoreDivider: { width: 1, height: 60, backgroundColor: "rgba(255,255,255,0.25)", marginHorizontal: 16 },
  scoreLangBlock: { alignItems: "center" },
  scoreLangValue: { color: "#fff", fontSize: 32, fontWeight: "900" },
  scoreLangLabel: { color: "rgba(255,255,255,0.75)", fontSize: 12, fontWeight: "600" },
  statsCard: { borderRadius: 16, borderWidth: 1, padding: 16, gap: 12 },
  statItem: { flexDirection: "row", alignItems: "center", gap: 12 },
  statIconBg: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  statValue: { fontSize: 18, fontWeight: "800" },
  statLabel: { fontSize: 12 },
  statDivider: { height: 1 },
  infoCard: { borderRadius: 16, borderWidth: 1, padding: 16, gap: 0 },
  infoRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 10 },
  infoSep: { height: 1 },
  infoText: { fontSize: 14, flex: 1 },
  logoutBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center",
    gap: 10, paddingVertical: 15, borderRadius: 16, borderWidth: 1, marginTop: 4,
  },
  logoutText: { fontSize: 15, fontWeight: "700" },
});