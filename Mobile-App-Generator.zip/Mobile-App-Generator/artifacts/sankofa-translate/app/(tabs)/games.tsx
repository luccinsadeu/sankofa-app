import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { GradientView } from "@/components/GradientView";
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  Alert,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { GradientButton } from "@/components/ui";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/context/I18nContext";
import { useColors } from "@/hooks/useColors";
import { useHaptics } from "@/hooks/useHaptics";
import { QUIZ_DATA, QUIZ_LANGUAGES, type QuizQuestion, type QuizTier } from "@/theme/quiz";

// Import depuis data/db.ts
import { VOCAB_DB, CULTURE_DB, PHRASES_DB, VocabEntry } from "@/data/db";

// ─── Types ────────────────────────────────────────────────────────────────────
type GameInfo = {
  id: string;
  title: string;
  titleEn: string;
  desc: string;
  descEn: string;
  icon: string;
  gradient: [string, string];
  category: string;
};
type ScreenState =
  | "main_menu"
  | "quiz_select"
  | "quiz_tier_select"
  | "quiz_playing"
  | "quiz_result"
  | "game_select_lang"
  | "game_select_tier"
  | "game_playing"
  | "game_result";

// ─── Fonctions utilitaires ───────────────────────────────────────────────────
function pickRandom<T>(arr: T[], n: number): T[] {
  return [...arr].sort(() => Math.random() - 0.5).slice(0, n);
}

function getWordsForGame(language: string, tier: number): VocabEntry[] {
  const db = VOCAB_DB[language] || VOCAB_DB["sw"];
  const tierWords = db[tier] || db[0];
  return pickRandom(tierWords, 10);
}

function getCultureQuestionsForGame(language: string, tier: number) {
  const db = CULTURE_DB[language] || CULTURE_DB["sw"];
  const tierQs = db.filter((q: any) => q.tier === tier);
  return pickRandom(tierQs, 5);
}

function getPhrasesForGame(language: string, tier: number) {
  const db = PHRASES_DB[language] || PHRASES_DB["sw"];
  const tierPhrases = db.filter((p: any) => p.tier === tier);
  return pickRandom(tierPhrases, Math.min(5, tierPhrases.length));
}

// ─── Génération de grille pour mots mêlés ────────────────────────────────────
function generateWordSearch(words: string[], size = 10): string[][] {
  const grid: string[][] = Array(size).fill(null).map(() => Array(size).fill(''));
  const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const dirs = [[0,1], [1,0], [1,1], [1,-1], [0,-1], [-1,0], [-1,-1], [-1,1]];
  let wordsToPlace = [...words];

  for (const word of wordsToPlace) {
    const upperWord = word.toUpperCase();
    let placed = false;
    let attempts = 0;
    while (!placed && attempts < 200) {
      const dir = dirs[Math.floor(Math.random() * dirs.length)];
      const row = Math.floor(Math.random() * size);
      const col = Math.floor(Math.random() * size);
      let ok = true;
      for (let i = 0; i < upperWord.length; i++) {
        const nr = row + dir[0] * i;
        const nc = col + dir[1] * i;
        if (nr < 0 || nr >= size || nc < 0 || nc >= size) { ok = false; break; }
        if (grid[nr][nc] !== '' && grid[nr][nc] !== upperWord[i]) { ok = false; break; }
      }
      if (ok) {
        for (let i = 0; i < upperWord.length; i++) {
          const nr = row + dir[0] * i;
          const nc = col + dir[1] * i;
          grid[nr][nc] = upperWord[i];
        }
        placed = true;
      }
      attempts++;
    }
    if (!placed) {
      for (let i = 0; i < upperWord.length && i < size; i++) {
        grid[0][i] = upperWord[i];
      }
    }
  }

  for (let i = 0; i < size; i++) {
    for (let j = 0; j < size; j++) {
      if (grid[i][j] === '') {
        grid[i][j] = alphabet[Math.floor(Math.random() * alphabet.length)];
      }
    }
  }
  return grid;
}

// ─── Jeu de mots mêlés (validation automatique) ────────────────────────────
function WordSearchGame({ language, tier, onComplete, onBack, colors }: any) {
  const words = useMemo(() => {
    const vocab = getWordsForGame(language, tier);
    return vocab.slice(0, 6).map((w: VocabEntry) => w.word);
  }, [language, tier]);
  const [grid, setGrid] = useState<string[][]>([]);
  const [found, setFound] = useState<Set<string>>(new Set());
  const [selectedCells, setSelectedCells] = useState<[number, number][]>([]);
  const [score, setScore] = useState(0);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  useEffect(() => {
    const newGrid = generateWordSearch(words);
    setGrid(newGrid);
    setFound(new Set());
    setSelectedCells([]);
    setScore(0);
  }, [words]);

  const tryValidateCurrentWord = (cells: [number, number][]) => {
    if (cells.length < 2) return false;
    let word = "";
    for (const [r,c] of cells) {
      word += grid[r][c];
    }
    const lowerWord = word.toLowerCase();
    const foundWord = words.find((w: string) => w.toLowerCase() === lowerWord);
    if (foundWord && !found.has(foundWord)) {
      setFound(prev => new Set(prev).add(foundWord));
      const newScore = score + 10;
      setScore(newScore);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setSelectedCells([]);
      if (found.size + 1 === words.length) {
        onComplete(newScore, words.length * 10);
      }
      return true;
    }
    return false;
  };

  const handleCellPress = (row: number, col: number) => {
    const isAlready = selectedCells.some(([r,c]) => r === row && c === col);
    if (isAlready) {
      const newSelection = selectedCells.filter(([r,c]) => !(r === row && c === col));
      setSelectedCells(newSelection);
    } else {
      const newSelection = [...selectedCells, [row, col]] as [number, number][];
      setSelectedCells(newSelection);
      tryValidateCurrentWord(newSelection);
    }
  };

  const resetSelection = () => setSelectedCells([]);

  if (grid.length === 0) {
    return <View style={[styles.container, { backgroundColor: bg, justifyContent: "center", alignItems: "center" }]}><Text style={{ color: fg }}>Génération...</Text></View>;
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={styles.progress}>Mots Mêlés</Text>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable onPress={() => Alert.alert("Mode d'emploi", "Cliquez sur les lettres dans l'ordre. Dès que vous formez un mot, il est automatiquement validé.")} style={styles.helpBtn}>
            <Feather name="info" size={18} color="#fff" />
          </Pressable>
          <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
        </View>
      </View>

      <View style={styles.wordList}>
        {words.map((w: string) => (
          <Text key={w} style={[styles.wordChip, { color: found.has(w) ? "#10b981" : "#ef4444", textDecorationLine: found.has(w) ? "line-through" : "none" }]}>
            {w} {found.has(w) ? "✓" : ""}
          </Text>
        ))}
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false}>
        <View style={{ alignItems: "center", padding: 16 }}>
          {grid.map((row, r) => (
            <View key={r} style={{ flexDirection: "row" }}>
              {row.map((letter, c) => {
                const isSelected = selectedCells.some(([rr, cc]) => rr === r && cc === c);
                return (
                  <Pressable
                    key={c}
                    style={[styles.gridCell, { backgroundColor: isSelected ? "#f59e0b" : "#1f2937", borderColor: "#374151" }]}
                    onPress={() => handleCellPress(r, c)}
                  >
                    <Text style={styles.gridLetter}>{letter}</Text>
                  </Pressable>
                );
              })}
            </View>
          ))}
        </View>
      </ScrollView>

      <View style={styles.responseRow}>
        <Pressable style={[styles.responseBtn, { backgroundColor: "#6b7280" }]} onPress={resetSelection}>
          <Text style={styles.responseText}>⟳ Effacer</Text>
        </Pressable>
      </View>
    </View>
  );
}

// ─── SpeedRaceGame ───────────────────────────────────────────────────────────
function SpeedRaceGame({ language, tier, onComplete, onBack, colors }: any) {
  const words = useMemo(() => getWordsForGame(language, tier), [language, tier]);
  const [score, setScore] = useState(0);
  const [time, setTime] = useState(30);
  const [idx, setIdx] = useState(0);
  const [combo, setCombo] = useState(0);
  const [over, setOver] = useState(false);
  const pairs = useMemo(() => words.map((w: VocabEntry) => {
    const isCorrect = Math.random() > 0.5;
    const disp = isCorrect ? w.translation : words[Math.floor(Math.random() * words.length)].translation;
    return { w, isCorrect, disp };
  }), [words]);

  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!over && time > 0) {
      timer.current = setInterval(() => setTime(t => {
        if (t <= 1) { clearInterval(timer.current!); setOver(true); return 0; }
        return t - 1;
      }), 1000);
    }
    return () => { if (timer.current) clearInterval(timer.current); };
  }, [over, time]);

  const current = pairs[idx % pairs.length];
  function answer(userYes: boolean) {
    if (userYes === current.isCorrect) {
      const c = combo + 1; setScore(s => s + (c >= 5 ? 3 : 1)); setCombo(c);
    } else setCombo(0);
    setIdx(i => i + 1);
  }

  useEffect(() => {
    if (over) onComplete(score, words.length * 3);
  }, [over, score, words.length, onComplete]);

  if (over) return (
    <View style={[styles.container, { backgroundColor: bg, justifyContent: "center", alignItems: "center" }]}>
      <Text style={{ fontSize: 48 }}>⚡</Text>
      <Text style={[styles.resultScore, { color: fg }]}>{score} pts</Text>
      <Pressable style={[styles.btn, { backgroundColor: "#10b981", marginTop: 20 }]} onPress={() => { setScore(0); setTime(30); setOver(false); setCombo(0); setIdx(0); }}><Text style={styles.btnText}>Rejouer</Text></Pressable>
      <Pressable style={[styles.btn, { backgroundColor: "#6b7280", marginTop: 12 }]} onPress={onBack}><Text style={styles.btnText}>Retour</Text></Pressable>
    </View>
  );

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.timer, { color: time > 10 ? "#10b981" : "#ef4444" }]}>{time}s</Text>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable onPress={() => Alert.alert(
            "⚡ Mode d'emploi",
            "1. Lisez le mot et sa traduction proposée\n2. Dites si la traduction est correcte (OUI/NON)\n3. Répondez vite\n4. Combo x5 donne +3 points\n5. 30 secondes chrono"
          )} style={styles.helpBtn}>
            <Feather name="info" size={18} color="#fff" />
          </Pressable>
          <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
        </View>
      </View>
      {combo >= 3 && <Text style={styles.comboText}>🔥 Combo x{combo}!</Text>}
      <View style={styles.card}><Text style={[styles.word, { color: fg }]}>{current.w.word}</Text><Text style={[styles.translation, { color: fg }]}>{current.disp}</Text></View>
      <Text style={[styles.question, { color: fg }]}>Bonne traduction ?</Text>
      <View style={styles.responseRow}><Pressable style={[styles.responseBtn, { backgroundColor: "#10b981" }]} onPress={() => answer(true)}><Text style={styles.responseText}>✅ OUI</Text></Pressable><Pressable style={[styles.responseBtn, { backgroundColor: "#ef4444" }]} onPress={() => answer(false)}><Text style={styles.responseText}>❌ NON</Text></Pressable></View>
    </View>
  );
}

// ─── SpellingGame ────────────────────────────────────────────────────────────
function SpellingGame({ language, tier, onComplete, onBack, colors }: any) {
  const words = useMemo(() => getWordsForGame(language, tier), [language, tier]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [ans, setAns] = useState("");
  const [show, setShow] = useState(true);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const w = words[idx];
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";

  useEffect(() => { setShow(true); const t = setTimeout(() => setShow(false), 2000); return () => clearTimeout(t); }, [idx]);

  function sub() {
    if (!w) return;
    if (ans.toLowerCase() === w.word.toLowerCase()) {
      setFeedback("correct");
      const newScore = score + 5;
      setScore(newScore);
      setTimeout(() => {
        setFeedback(null);
        if (idx + 1 >= words.length) onComplete(newScore, words.length * 5);
        else { setIdx(i => i + 1); setAns(""); }
      }, 600);
    } else {
      setFeedback("wrong");
      setTimeout(() => setFeedback(null), 600);
    }
  }

  if (!w) { onComplete(score, 1); return null; }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={styles.progress}>{idx + 1}/{words.length}</Text>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable onPress={() => Alert.alert(
            "✍️ Mode d'emploi",
            "1. Le mot s'affiche 2 secondes\n2. Tapez son orthographe exacte\n3. Validez\n4. +5 points par mot correct"
          )} style={styles.helpBtn}>
            <Feather name="info" size={18} color="#fff" />
          </Pressable>
          <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
        </View>
      </View>
      <View style={styles.card}><Text style={styles.hintLabel}>Traduction</Text><Text style={[styles.hint, { color: fg }]}>{w.translation}</Text>{show && <Text style={[styles.reveal, { color: "#10b981" }]}>{w.word}</Text>}</View>
      <TextInput
        style={[styles.input, feedback === "correct" ? { borderColor: "#10b981" } : feedback === "wrong" ? { borderColor: "#ef4444" } : {}]}
        value={ans}
        onChangeText={setAns}
        placeholder="Épelez le mot..."
        placeholderTextColor="#6b7280"
        onSubmitEditing={sub}
      />
      <Pressable style={[styles.btnFull, { backgroundColor: "#10b981" }]} onPress={sub}><Text style={styles.btnText}>Valider</Text></Pressable>
    </View>
  );
}

// ─── MatchingGame ────────────────────────────────────────────────────────────
function MatchingGame({ language, tier, onComplete, onBack, colors }: any) {
  const words = useMemo(() => getWordsForGame(language, tier).slice(0, 6), [language, tier]);
  const [cards, setCards] = useState(() => {
    const pairs = words.flatMap((w: VocabEntry, i: number) => [
      { id: i * 2, text: w.word, pair: i, flipped: false, matched: false },
      { id: i * 2 + 1, text: w.translation, pair: i, flipped: false, matched: false }
    ]);
    return pairs.sort(() => Math.random() - 0.5);
  });
  const [flippedIds, setFlippedIds] = useState<number[]>([]);
  const [matches, setMatches] = useState(0);
  const [lock, setLock] = useState(false);
  const bg = colors?.background || "#1a1a2e";

  const handleCardPress = (id: number) => {
    if (lock) return;
    const card = cards.find((c: any) => c.id === id);
    if (!card || card.flipped || card.matched) return;
    if (flippedIds.length === 1 && flippedIds[0] === id) return;

    const newCards = cards.map((c: any) => c.id === id ? { ...c, flipped: true } : c);
    setCards(newCards);
    const newFlipped = [...flippedIds, id];
    setFlippedIds(newFlipped);

    if (newFlipped.length === 2) {
      setLock(true);
      const [id1, id2] = newFlipped;
      const card1 = newCards.find((c: any) => c.id === id1)!;
      const card2 = newCards.find((c: any) => c.id === id2)!;

      if (card1.pair === card2.pair && card1.text !== card2.text) {
        setTimeout(() => {
          setCards((prev: any[]) => prev.map((c: any) => c.id === id1 || c.id === id2 ? { ...c, matched: true, flipped: false } : c));
          setFlippedIds([]);
          const newMatches = matches + 1;
          setMatches(newMatches);
          if (newMatches === words.length) onComplete(newMatches * 10, words.length * 10);
          setLock(false);
        }, 500);
      } else {
        setTimeout(() => {
          setCards((prev: any[]) => prev.map((c: any) => c.id === id1 || c.id === id2 ? { ...c, flipped: false } : c));
          setFlippedIds([]);
          setLock(false);
        }, 800);
      }
    }
  };

  const getCardStyle = (card: any) => {
    if (card.matched) return { backgroundColor: "#10b981", borderColor: "#10b981" };
    if (card.flipped) return { backgroundColor: "#3b82f6", borderColor: "#3b82f6" };
    return { backgroundColor: "#1f2937", borderColor: "#374151" };
  };

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={[styles.progress, { color: "#fff" }]}>Paires: {matches}/{words.length}</Text>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable onPress={() => Alert.alert(
            "🃏 Mode d'emploi",
            "1. Retournez deux cartes\n2. Associez le mot à sa traduction\n3. 10 points par paire\n4. Trouvez toutes les paires"
          )} style={styles.helpBtn}>
            <Feather name="info" size={18} color="#fff" />
          </Pressable>
          <View style={styles.scoreBadge}><Text style={styles.scoreText}>{matches * 10} pts</Text></View>
        </View>
      </View>
      <View style={styles.matchingGrid}>
        {cards.map((card: any) => (
          <Pressable key={card.id} style={[styles.matchingCard, getCardStyle(card)]} onPress={() => handleCardPress(card.id)}>
            <Text style={[styles.matchingCardText, { color: "#fff" }]}>{card.flipped || card.matched ? card.text : "?"}</Text>
          </Pressable>
        ))}
      </View>
    </View>
  );
}

// ─── CultureQuizGame ─────────────────────────────────────────────────────────
function CultureQuizGame({ language, tier, onComplete, onBack, colors }: any) {
  const questions = useMemo(() => getCultureQuestionsForGame(language, tier), [language, tier]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [sel, setSel] = useState<number | null>(null);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";
  const q = questions[idx];
  if (!q) { onComplete(score, 1); return null; }

  function ans(i: number) {
    setSel(i);
    const isCorrect = i === q.correctIndex;
    const newScore = score + (isCorrect ? 10 : 0);
    setScore(newScore);
    setTimeout(() => {
      if (idx + 1 >= questions.length) onComplete(newScore, questions.length * 10);
      else { setIdx(x => x + 1); setSel(null); }
    }, 1000);
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={styles.progress}>{idx + 1}/{questions.length}</Text>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable onPress={() => Alert.alert(
            "🌍 Mode d'emploi",
            "1. Lisez la question\n2. Choisissez la bonne réponse\n3. +10 points par bonne réponse\n4. 70% pour débloquer le niveau suivant"
          )} style={styles.helpBtn}>
            <Feather name="info" size={18} color="#fff" />
          </Pressable>
          <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
        </View>
      </View>
      <View style={styles.card}><Text style={[styles.questionText, { color: fg }]}>{q.question}</Text></View>
      <View style={styles.options}>
        {q.options.map((o: string, i: number) => {
          let bc = "#374151", bgc = "#1f2937";
          if (sel !== null) { if (i === q.correctIndex) { bgc = "#10b98120"; bc = "#10b981"; } else if (i === sel) { bgc = "#ef444420"; bc = "#ef4444"; } }
          return <Pressable key={i} style={[styles.option, { backgroundColor: bgc, borderColor: bc }]} onPress={() => ans(i)} disabled={sel !== null}>
            <Text style={[styles.optionText, { color: fg }]}>{String.fromCharCode(65 + i)}. {o}</Text>
          </Pressable>;
        })}
      </View>
    </View>
  );
}

// ─── PhraseBuilderGame ───────────────────────────────────────────────────────
function PhraseBuilderGame({ language, tier, onComplete, onBack, colors }: any) {
  const phrases = useMemo(() => getPhrasesForGame(language, tier), [language, tier]);
  const [idx, setIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [sel, setSel] = useState<string[]>([]);
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const bg = colors?.background || "#1a1a2e";
  const fg = colors?.foreground || "#fff";
  const p = phrases[idx];
  if (!p) { onComplete(score, 1); return null; }
  const av = p.words.filter((w: string) => !sel.includes(w));

  function val() {
    const correct = p.correctOrder.map((i: number) => p.words[i]).join(" ");
    const isC = sel.join(" ") === correct;
    const newScore = score + (isC ? 5 : 0);
    setScore(newScore);
    setFeedback(isC ? "correct" : "wrong");
    setTimeout(() => {
      setFeedback(null);
      if (idx + 1 >= phrases.length) onComplete(newScore, phrases.length * 5);
      else { setIdx(i => i + 1); setSel([]); }
    }, 700);
  }

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      <View style={styles.header}>
        <Pressable onPress={onBack} style={styles.exitBtn}><Feather name="x" size={18} color="#fff" /></Pressable>
        <Text style={styles.progress}>{idx + 1}/{phrases.length}</Text>
        <View style={{ flexDirection: "row", gap: 8 }}>
          <Pressable onPress={() => Alert.alert(
            "📝 Mode d'emploi",
            "1. Lisez la traduction\n2. Cliquez sur les mots pour construire la phrase\n3. Cliquez sur un mot placé pour l'enlever\n4. Validez l'ordre\n5. +5 points par phrase correcte"
          )} style={styles.helpBtn}>
            <Feather name="info" size={18} color="#fff" />
          </Pressable>
          <View style={styles.scoreBadge}><Text style={styles.scoreText}>{score} pts</Text></View>
        </View>
      </View>
      <View style={styles.card}><Text style={styles.hintLabel}>Traduction</Text><Text style={[styles.hint, { color: fg }]}>{p.translation}</Text></View>
      <View style={[styles.buildZone, { borderColor: feedback === "correct" ? "#10b981" : feedback === "wrong" ? "#ef4444" : "#374151" }]}>
        {sel.map((w, i) => <Pressable key={i} style={[styles.wordBubble, { backgroundColor: "#10b981" }]} onPress={() => setSel(prev => prev.filter(x => x !== w))}><Text style={styles.wordText}>{w}</Text></Pressable>)}
      </View>
      <View style={styles.wordOptions}>{av.map((w: string, i: number) => <Pressable key={i} style={[styles.wordBubble, { backgroundColor: "#1f2937", borderColor: "#374151" }]} onPress={() => setSel(prev => [...prev, w])}><Text style={[styles.wordText, { color: fg }]}>{w}</Text></Pressable>)}</View>
      <Pressable style={[styles.btnFull, { backgroundColor: "#10b981" }]} onPress={val}><Text style={styles.btnText}>Valider</Text></Pressable>
    </View>
  );
}

// ─── Liste des jeux ──────────────────────────────────────────────────────────
const ALL_GAMES: GameInfo[] = [
  { id: "wordsearch", title: "Mots Mêlés", titleEn: "Word Search", desc: "Cliquez sur les lettres pour trouver les mots (validation auto)", descEn: "Click letters to find words (auto-validate)", icon: "search", gradient: ["#3b82f6", "#2563eb"], category: "vocabulaire" },
  { id: "speedrace", title: "Course de vitesse", titleEn: "Speed Race", desc: "Répondez le plus vite possible", descEn: "Answer as fast as possible", icon: "zap", gradient: ["#ef4444", "#dc2626"], category: "vitesse" },
  { id: "spelling", title: "Orthographe", titleEn: "Spelling Bee", desc: "Épelez correctement les mots", descEn: "Spell words correctly", icon: "edit-3", gradient: ["#10b981", "#059669"], category: "vocabulaire" },
  { id: "matching", title: "Paires", titleEn: "Matching", desc: "Associez mots et traductions", descEn: "Match words & translations", icon: "grid", gradient: ["#8b5cf6", "#7c3aed"], category: "vocabulaire" },
  { id: "culturequiz", title: "Quiz Culturel", titleEn: "Culture Quiz", desc: "Testez vos connaissances culturelles", descEn: "Test your cultural knowledge", icon: "globe", gradient: ["#14b8a6", "#0d9488"], category: "culture" },
  { id: "phrasebuilder", title: "Constructeur de phrases", titleEn: "Phrase Builder", desc: "Organisez les mots correctement", descEn: "Arrange words correctly", icon: "list", gradient: ["#f97316", "#ea580c"], category: "grammaire" },
];

// ─── Langues et quiz ─────────────────────────────────────────────────────────
const LANGUES_QUIZ = QUIZ_LANGUAGES.filter(l => !["ew", "du", "gh", "ff", "bu", "gb"].includes(l.code));
const QUIZ_DATA_FILTRE: Record<string, QuizTier[]> = {};
Object.keys(QUIZ_DATA).forEach(code => { if (!["ew", "du", "gh", "ff", "bu", "gb"].includes(code)) QUIZ_DATA_FILTRE[code] = QUIZ_DATA[code]; });
const TIER_COLORS: [string, string][] = [["#4CAF50", "#2E7D32"], ["#FF9800", "#E65100"], ["#9C27B0", "#4A148C"]];
const TIER_ICONS = ["🌱", "🌿", "🌳"];
const TIER_NAMES = ["Débutant", "Intermédiaire", "Avancé"];
const TIER_NAMES_EN = ["Beginner", "Intermediate", "Advanced"];
const GAME_PROGRESS_KEY = "@sankofa_game_progress";
const QUIZ_PROGRESS_KEY = "@sankofa_quiz_progress";
const PASS_SCORE = 70;

// ─── Styles (complets) ───────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { paddingHorizontal: 16, gap: 14 },
  mainHeader: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 16, padding: 16 },
  mainHeaderTitle: { color: "#fff", fontSize: 18, fontWeight: "700" },
  mainHeaderSub: { color: "rgba(255,255,255,0.7)", fontSize: 12 },
  quizBanner: { flexDirection: "row", alignItems: "center", gap: 14, borderRadius: 16, borderWidth: 2, padding: 16 },
  quizBannerIcon: { width: 50, height: 50, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  quizBannerTitle: { fontSize: 16, fontWeight: "700" },
  quizBannerDesc: { fontSize: 12, marginTop: 3 },
  section: { gap: 8, marginTop: 6 },
  sectionTitle: { fontSize: 16, fontWeight: "700" },
  gameCard: { flexDirection: "row", alignItems: "center", borderRadius: 14, padding: 12, gap: 12, borderWidth: 1 },
  gameIcon: { width: 40, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  gameTitle: { fontSize: 14, fontWeight: "700" },
  gameDesc: { fontSize: 11, marginTop: 2 },
  gameHeaderCard: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 16, padding: 16 },
  gameHeaderTitle: { color: "#fff", fontSize: 18, fontWeight: "700" },
  gameResultScore: { fontSize: 36, fontWeight: "800", marginTop: 16 },
  gameResultLabel: { fontSize: 16, marginTop: 8 },
  btn: { paddingHorizontal: 20, paddingVertical: 12, borderRadius: 10 },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 14 },
  backBtn: { width: 38, height: 38, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  selectTitle: { fontSize: 20, fontWeight: "700", marginTop: 8 },
  selectSubtitle: { fontSize: 14, marginTop: 4 },
  langGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  langCard: { width: "30%", borderRadius: 14, borderWidth: 1, padding: 16, alignItems: "center", gap: 8 },
  langFlag: { fontSize: 32 },
  langName: { fontSize: 12, fontWeight: "600", textAlign: "center" },
  tiersCol: { gap: 12 },
  tierCard: { borderRadius: 16, overflow: "hidden", borderWidth: 2 },
  tierGradient: { flexDirection: "row", alignItems: "center", padding: 18, gap: 14 },
  tierIcon: { fontSize: 30 },
  tierLevel: { color: "rgba(255,255,255,0.7)", fontSize: 11, fontWeight: "600", textTransform: "uppercase" },
  tierName: { color: "#fff", fontSize: 17, fontWeight: "800" },
  tierDesc: { color: "rgba(255,255,255,0.75)", fontSize: 11, marginTop: 3 },
  tierRight: { alignItems: "center" },
  passedBadge: { width: 28, height: 28, borderRadius: 14, backgroundColor: "rgba(255,255,255,0.3)", alignItems: "center", justifyContent: "center" },
  lockOverlay: { padding: 8, alignItems: "center" },
  lockOverlayText: { color: "#fff", fontSize: 11, textAlign: "center", fontWeight: "600" },
  unlockText: { fontSize: 14, fontWeight: "700", textAlign: "center" },
  resultCenter: { alignItems: "center", gap: 20 },
  resultBadge: { width: 180, height: 180, borderRadius: 90, alignItems: "center", justifyContent: "center", gap: 4 },
  resultEmoji: { fontSize: 40 },
  resultPct: { color: "#fff", fontSize: 32, fontWeight: "800" },
  resultBtns: { flexDirection: "row", gap: 10, width: "100%" },
  quizContainer: { flex: 1, paddingHorizontal: 16, gap: 14 },
  quizHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  exitBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(0,0,0,0.3)" },
  helpBtn: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(255,255,255,0.2)" },
  quizProgress: { fontSize: 14, fontWeight: "600" },
  scoreBadge: { backgroundColor: "#f59e0b", paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreChip: { paddingHorizontal: 12, paddingVertical: 4, borderRadius: 100 },
  scoreChipText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  scoreText: { color: "#fff", fontWeight: "700", fontSize: 13 },
  questionCard: { borderRadius: 20, padding: 32, alignItems: "center", gap: 12 },
  questionLabel: { color: "rgba(255,255,255,0.65)", fontSize: 14, fontWeight: "500" },
  questionWord: { color: "#fff", fontSize: 36, fontWeight: "800", textAlign: "center" },
  options: { gap: 10 },
  option: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 14, borderWidth: 1.5, padding: 14 },
  optionText: { flex: 1, fontSize: 15, fontWeight: "600" },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingTop: 40, paddingBottom: 16 },
  progress: { color: "#fff", fontSize: 14, fontWeight: "600" },
  card: { minHeight: 200, borderRadius: 20, borderWidth: 2, justifyContent: "center", alignItems: "center", padding: 30, backgroundColor: "#1f2937", margin: 20, borderColor: "#374151" },
  word: { fontSize: 32, fontWeight: "800", textAlign: "center" },
  translation: { fontSize: 22, marginTop: 8 },
  question: { textAlign: "center", fontSize: 16, marginVertical: 12 },
  responseRow: { flexDirection: "row", gap: 16, paddingHorizontal: 20, paddingBottom: 30 },
  responseBtn: { flex: 1, alignItems: "center", justifyContent: "center", paddingVertical: 16, borderRadius: 14 },
  responseText: { color: "#fff", fontWeight: "700", fontSize: 15 },
  resultScore: { fontSize: 32, fontWeight: "800", marginTop: 16 },
  timer: { fontSize: 28, fontWeight: "800" },
  comboText: { textAlign: "center", color: "#f59e0b", fontSize: 16, fontWeight: "700", marginTop: 8 },
  hintLabel: { color: "#9ca3af", fontSize: 11, textTransform: "uppercase" },
  hint: { fontSize: 24, fontWeight: "700" },
  reveal: { fontSize: 28, fontWeight: "800", marginTop: 8 },
  input: { marginHorizontal: 20, backgroundColor: "#1f2937", borderRadius: 12, padding: 14, fontSize: 18, color: "#fff", textAlign: "center", borderWidth: 2, borderColor: "#374151" },
  btnFull: { marginHorizontal: 20, paddingVertical: 14, borderRadius: 12, alignItems: "center", marginTop: 16 },
  matchingGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 12, paddingHorizontal: 16, marginTop: 20 },
  matchingCard: { width: "22%", aspectRatio: 0.8, borderRadius: 12, borderWidth: 2, alignItems: "center", justifyContent: "center", padding: 4 },
  matchingCardText: { fontSize: 11, fontWeight: "700", textAlign: "center", color: "#fff" },
  questionText: { fontSize: 18, fontWeight: "600", textAlign: "center", padding: 20, color: "#fff" },
  wordList: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 8, paddingHorizontal: 16, marginBottom: 16 },
  wordChip: { fontSize: 14, fontWeight: "600", marginHorizontal: 4 },
  grid: { paddingHorizontal: 4, gap: 3 },
  gridRow: { flexDirection: "row", gap: 3 },
  gridCell: { width: 40, height: 40, borderRadius: 6, borderWidth: 1, borderColor: "#374151", alignItems: "center", justifyContent: "center" },
  gridLetter: { color: "#fff", fontSize: 16, fontWeight: "700" },
  buildZone: { minHeight: 60, flexDirection: "row", flexWrap: "wrap", gap: 8, padding: 16, marginHorizontal: 20, borderWidth: 2, borderRadius: 12, marginTop: 20 },
  wordOptions: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center", gap: 8, padding: 16 },
  wordBubble: { paddingHorizontal: 16, paddingVertical: 10, borderRadius: 20, borderWidth: 1 },
  wordText: { color: "#fff", fontWeight: "600", fontSize: 14 },
});

// ─── Composant principal GamesScreen ────────────────────────────────────────
export default function GamesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { lang } = useI18n();
  const { addScore, saveTierProgress } = useApp();
  const { impact } = useHaptics();

  const [screen, setScreen] = useState<ScreenState>("main_menu");
  const [selectedLang, setSelectedLang] = useState("");
  const [selectedTier, setSelectedTier] = useState(0);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [sessionScore, setSessionScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [currentGame, setCurrentGame] = useState<GameInfo | null>(null);
  const [gameTier, setGameTier] = useState(0);
  const [gameScore, setGameScore] = useState(0);
  const [gameMaxScore, setGameMaxScore] = useState(0);
  const [gameProgress, setGameProgress] = useState<Record<string, Record<string, number>>>({});
  const [quizProgress, setQuizProgress] = useState<Record<string, number>>({});

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 + 84 : insets.bottom + 84;

  useEffect(() => { loadGameProgress(); loadQuizProgress(); }, []);

  async function loadGameProgress() { try { const saved = await AsyncStorage.getItem(GAME_PROGRESS_KEY); if (saved) setGameProgress(JSON.parse(saved)); } catch (e) {} }
  async function saveGameProgress(progress: Record<string, Record<string, number>>) { try { await AsyncStorage.setItem(GAME_PROGRESS_KEY, JSON.stringify(progress)); } catch (e) {} }
  async function loadQuizProgress() { try { const saved = await AsyncStorage.getItem(QUIZ_PROGRESS_KEY); if (saved) setQuizProgress(JSON.parse(saved)); } catch (e) {} }
  async function saveQuizProgress(progress: Record<string, number>) { try { await AsyncStorage.setItem(QUIZ_PROGRESS_KEY, JSON.stringify(progress)); } catch (e) {} }

  function startQuizTier(tier: QuizTier, tierIdx: number) {
    const qs = pickRandom([...tier.questions], 10);
    setSelectedTier(tierIdx); setQuestions(qs); setCurrentQ(0); setSelectedAnswer(null); setSessionScore(0); setCorrectAnswers(0); setScreen("quiz_playing");
  }

  function handleQuizAnswer(idx: number) {
    if (selectedAnswer !== null) return;
    setSelectedAnswer(idx);
    const q = questions[currentQ];
    const isCorrect = idx === q.correctIndex;
    if (isCorrect) { Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success); setSessionScore(s => s + 10); setCorrectAnswers(c => c + 1); }
    else Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    setTimeout(() => {
      if (currentQ + 1 >= questions.length) {
        const finalScore = sessionScore + (isCorrect ? 10 : 0);
        const finalCorrect = correctAnswers + (isCorrect ? 1 : 0);
        const pct = Math.round((finalScore / (questions.length * 10)) * 100);
        addScore(finalScore);
        saveTierProgress(selectedLang, selectedTier, finalScore, pct >= PASS_SCORE);
        if (pct >= PASS_SCORE) {
          const newProgress = { ...quizProgress };
          newProgress[selectedLang] = Math.max(newProgress[selectedLang] || 0, selectedTier + 1);
          setQuizProgress(newProgress);
          saveQuizProgress(newProgress);
        }
        setSessionScore(finalScore);
        setCorrectAnswers(finalCorrect);
        setScreen("quiz_result");
      } else { setCurrentQ(c => c + 1); setSelectedAnswer(null); }
    }, 800);
  }

  const handleGameComplete = useCallback((score: number, maxScore: number) => {
    setGameScore(score); setGameMaxScore(maxScore);
    addScore(score);
    const pct = Math.round((score / maxScore) * 100);
    if (pct >= PASS_SCORE && currentGame) {
      const newProgress = { ...gameProgress };
      if (!newProgress[currentGame.id]) newProgress[currentGame.id] = {};
      newProgress[currentGame.id][selectedLang] = Math.max(newProgress[currentGame.id][selectedLang] || 0, gameTier + 1);
      setGameProgress(newProgress);
      saveGameProgress(newProgress);
    }
    setScreen("game_result");
  }, [currentGame, gameProgress, selectedLang, gameTier, addScore]);

  const handleGameBack = useCallback(() => setScreen("game_select_tier"), []);

  function renderGame() {
    if (!currentGame) return null;
    const gp = { language: selectedLang, tier: gameTier, onComplete: handleGameComplete, onBack: handleGameBack, colors, lang };
    switch (currentGame.id) {
      case "wordsearch": return <WordSearchGame {...gp} />;
      case "speedrace": return <SpeedRaceGame {...gp} />;
      case "spelling": return <SpellingGame {...gp} />;
      case "matching": return <MatchingGame {...gp} />;
      case "culturequiz": return <CultureQuizGame {...gp} />;
      case "phrasebuilder": return <PhraseBuilderGame {...gp} />;
      default: return <Text style={{ color: "#fff", textAlign: "center", marginTop: 100 }}>Jeu non disponible</Text>;
    }
  }

  // ─── Écran principal (menu) ────────────────────────────────────────────────
  if (screen === "main_menu") {
    const categories = [...new Set(ALL_GAMES.map(g => g.category))];
    const catNames: Record<string, string> = { vocabulaire: "📝 Vocabulaire", grammaire: "📖 Grammaire", vitesse: "⚡ Vitesse", culture: "🌍 Culture" };
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scroll, { paddingTop: topPad + 16, paddingBottom: bottomPad }]}>
          <GradientView colors={["#f59e0b", "#d97706"]} style={styles.mainHeader}>
            <Feather name="play-circle" size={24} color="#fff" />
            <View style={{ flex: 1 }}><Text style={styles.mainHeaderTitle}>Jeux éducatifs</Text><Text style={styles.mainHeaderSub}>Apprenez en vous amusant !</Text></View>
          </GradientView>
          <Pressable style={[styles.quizBanner, { backgroundColor: colors.card, borderColor: colors.gold }]} onPress={() => { impact(); setScreen("quiz_select"); }}>
            <GradientView colors={["#f59e0b", "#d97706"]} style={styles.quizBannerIcon}><Feather name="award" size={28} color="#fff" /></GradientView>
            <View style={{ flex: 1 }}><Text style={[styles.quizBannerTitle, { color: colors.foreground }]}>🏆 Quiz Africain</Text><Text style={[styles.quizBannerDesc, { color: colors.mutedForeground }]}>3 paliers · 10 questions · QCM</Text></View>
            <Feather name="chevron-right" size={20} color={colors.gold} />
          </Pressable>
          {categories.map(cat => (
            <View key={cat} style={styles.section}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{catNames[cat] || cat}</Text>
              {ALL_GAMES.filter(g => g.category === cat).map(game => (
                <Pressable key={game.id} style={[styles.gameCard, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => { impact(); setCurrentGame(game); setScreen("game_select_lang"); }}>
                  <GradientView colors={game.gradient} style={styles.gameIcon}><Feather name={game.icon as any} size={18} color="#fff" /></GradientView>
                  <View style={{ flex: 1 }}><Text style={[styles.gameTitle, { color: colors.foreground }]}>{lang === "fr" ? game.title : game.titleEn}</Text><Text style={[styles.gameDesc, { color: colors.mutedForeground }]}>{lang === "fr" ? game.desc : game.descEn}</Text></View>
                  <Feather name="chevron-right" size={16} color={colors.mutedForeground} />
                </Pressable>
              ))}
            </View>
          ))}
        </ScrollView>
      </View>
    );
  }

  // ─── Sélection de la langue pour un jeu ────────────────────────────────────
  if (screen === "game_select_lang" && currentGame) {
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scroll, { paddingTop: topPad + 16 }]}>
          <Pressable style={[styles.backBtn, { backgroundColor: colors.muted }]} onPress={() => setScreen("main_menu")}><Feather name="arrow-left" size={18} color={colors.foreground} /></Pressable>
          <GradientView colors={currentGame.gradient} style={styles.gameHeaderCard}><Feather name={currentGame.icon as any} size={28} color="#fff" /><Text style={styles.gameHeaderTitle}>{lang === "fr" ? currentGame.title : currentGame.titleEn}</Text></GradientView>
          <Text style={[styles.selectTitle, { color: colors.foreground }]}>Choisissez une langue</Text>
          <View style={styles.langGrid}>
            {LANGUES_QUIZ.map(l => (
              <Pressable key={l.code} style={[styles.langCard, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => { impact(); setSelectedLang(l.code); setScreen("game_select_tier"); }}>
                <Text style={styles.langFlag}>{l.flag}</Text>
                <Text style={[styles.langName, { color: colors.foreground }]}>{l.name}</Text>
              </Pressable>
            ))}
          </View>
        </ScrollView>
      </View>
    );
  }

  // ─── Sélection du palier (niveau) ──────────────────────────────────────────
  if (screen === "game_select_tier" && currentGame) {
    const langInfo = LANGUES_QUIZ.find(l => l.code === selectedLang);
    const unlockedTier = gameProgress[currentGame.id]?.[selectedLang] || 0;
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scroll, { paddingTop: topPad + 16 }]}>
          <Pressable style={[styles.backBtn, { backgroundColor: colors.muted }]} onPress={() => setScreen("game_select_lang")}><Feather name="arrow-left" size={18} color={colors.foreground} /></Pressable>
          <GradientView colors={currentGame.gradient} style={styles.gameHeaderCard}><Feather name={currentGame.icon as any} size={28} color="#fff" /><Text style={styles.gameHeaderTitle}>{lang === "fr" ? currentGame.title : currentGame.titleEn}</Text></GradientView>
          <Text style={[styles.selectTitle, { color: colors.foreground }]}>{langInfo?.flag} {langInfo?.name}</Text>
          <Text style={[styles.selectSubtitle, { color: colors.mutedForeground }]}>{lang === "fr" ? "Choisissez un niveau" : "Choose a level"}</Text>
          <View style={styles.tiersCol}>
            {[0, 1, 2].map(i => {
              const isUnlocked = i <= unlockedTier;
              const isPassed = i < unlockedTier;
              return (
                <Pressable key={i} style={[styles.tierCard, { backgroundColor: colors.card, borderColor: TIER_COLORS[i][0], opacity: isUnlocked ? 1 : 0.5 }]} onPress={() => { if (isUnlocked) { impact(); setGameTier(i); setScreen("game_playing"); } }} disabled={!isUnlocked}>
                  <GradientView colors={TIER_COLORS[i]} style={styles.tierGradient}>
                    <Text style={styles.tierIcon}>{TIER_ICONS[i]}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.tierLevel}>{lang === "fr" ? `Palier ${i + 1}` : `Tier ${i + 1}`}</Text>
                      <Text style={styles.tierName}>{lang === "fr" ? TIER_NAMES[i] : TIER_NAMES_EN[i]}</Text>
                    </View>
                    <View style={styles.tierRight}>
                      {!isUnlocked ? (<Feather name="lock" size={20} color="rgba(255,255,255,0.6)" />) : isPassed ? (<View style={styles.passedBadge}><Feather name="check" size={14} color="#fff" /></View>) : (<Feather name="play-circle" size={26} color="rgba(255,255,255,0.9)" />)}
                    </View>
                  </GradientView>
                  {!isUnlocked && (<View style={[styles.lockOverlay, { backgroundColor: "rgba(0,0,0,0.3)" }]}><Text style={styles.lockOverlayText}>{lang === "fr" ? `🔒 Validez le palier ${i} avec ≥70%` : `🔒 Pass tier ${i} with ≥70%`}</Text></View>)}
                </Pressable>
              );
            })}
          </View>
        </ScrollView>
      </View>
    );
  }

  // ─── Écran de jeu ──────────────────────────────────────────────────────────
  if (screen === "game_playing") return <View style={[styles.container, { backgroundColor: colors.background }]}>{renderGame()}</View>;

  // ─── Écran de résultat d'un jeu ────────────────────────────────────────────
  if (screen === "game_result") {
    const pct = gameMaxScore > 0 ? Math.round((gameScore / gameMaxScore) * 100) : 0;
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scroll, { justifyContent: "center", alignItems: "center", paddingTop: topPad + 60 }]}>
          <Text style={{ fontSize: 64 }}>{pct >= 80 ? "🏆" : pct >= 50 ? "⭐" : "💪"}</Text>
          <Text style={[styles.gameResultScore, { color: colors.foreground }]}>{gameScore}/{gameMaxScore}</Text>
          <Text style={[styles.gameResultLabel, { color: colors.mutedForeground }]}>{pct >= 80 ? "Excellent !" : pct >= 50 ? "Bien joué !" : "Continue !"}</Text>
          {pct >= PASS_SCORE && currentGame && <Text style={[styles.unlockText, { color: colors.gold, marginTop: 8 }]}>🔓 {lang === "fr" ? "Palier suivant débloqué !" : "Next tier unlocked!"}</Text>}
          <View style={styles.resultBtns}>
            <Pressable style={[styles.btn, { backgroundColor: "#10b981" }]} onPress={() => setScreen("game_playing")}><Text style={styles.btnText}>Rejouer</Text></Pressable>
            <Pressable style={[styles.btn, { backgroundColor: colors.muted }]} onPress={() => setScreen("game_select_tier")}><Text style={[styles.btnText, { color: colors.foreground }]}>Paliers</Text></Pressable>
            <Pressable style={[styles.btn, { backgroundColor: colors.muted }]} onPress={() => setScreen("main_menu")}><Text style={[styles.btnText, { color: colors.foreground }]}>Menu</Text></Pressable>
          </View>
        </ScrollView>
      </View>
    );
  }

  // ─── Sélection du quiz (langue) ────────────────────────────────────────────
  if (screen === "quiz_select") return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      <ScrollView contentContainerStyle={[styles.scroll, { paddingTop: topPad + 16 }]}>
        <Pressable style={[styles.backBtn, { backgroundColor: colors.muted }]} onPress={() => setScreen("main_menu")}><Feather name="arrow-left" size={18} color={colors.foreground} /></Pressable>
        <Text style={[styles.selectTitle, { color: colors.foreground }]}>Choisissez une langue</Text>
        <View style={styles.langGrid}>
          {LANGUES_QUIZ.map(l => <Pressable key={l.code} style={[styles.langCard, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => { impact(); setSelectedLang(l.code); setScreen("quiz_tier_select"); }}><Text style={styles.langFlag}>{l.flag}</Text><Text style={[styles.langName, { color: colors.foreground }]}>{l.name}</Text></Pressable>)}
        </View>
      </ScrollView>
    </View>
  );

  // ─── Sélection du palier pour le quiz ──────────────────────────────────────
  if (screen === "quiz_tier_select") {
    const tiers = QUIZ_DATA_FILTRE[selectedLang] ?? [];
    const unlockedTier = quizProgress[selectedLang] || 0;
    const langInfo = LANGUES_QUIZ.find(l => l.code === selectedLang);
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scroll, { paddingTop: topPad + 16 }]}>
          <Pressable style={[styles.backBtn, { backgroundColor: colors.muted }]} onPress={() => setScreen("quiz_select")}><Feather name="arrow-left" size={18} color={colors.foreground} /></Pressable>
          <Text style={[styles.selectTitle, { color: colors.foreground }]}>{langInfo?.flag} {langInfo?.name}</Text>
          <Text style={[styles.selectSubtitle, { color: colors.mutedForeground }]}>{lang === "fr" ? "Choisissez un niveau" : "Choose a level"}</Text>
          <View style={styles.tiersCol}>
            {tiers.map((tier, i) => {
              const isUnlocked = i <= unlockedTier;
              const isPassed = i < unlockedTier;
              return (
                <Pressable key={i} style={[styles.tierCard, { backgroundColor: colors.card, borderColor: TIER_COLORS[i][0], opacity: isUnlocked ? 1 : 0.5 }]} onPress={() => { if (isUnlocked) startQuizTier(tier, i); }} disabled={!isUnlocked}>
                  <GradientView colors={TIER_COLORS[i]} style={styles.tierGradient}>
                    <Text style={styles.tierIcon}>{TIER_ICONS[i]}</Text>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.tierLevel}>{lang === "fr" ? `Palier ${i + 1}` : `Tier ${i + 1}`}</Text>
                      <Text style={styles.tierName}>{tier.label}</Text>
                    </View>
                    <View style={styles.tierRight}>
                      {!isUnlocked ? <Feather name="lock" size={20} color="rgba(255,255,255,0.6)" /> : isPassed ? <View style={styles.passedBadge}><Feather name="check" size={14} color="#fff" /></View> : <Feather name="play-circle" size={26} color="rgba(255,255,255,0.9)" />}
                    </View>
                  </GradientView>
                  {!isUnlocked && (<View style={[styles.lockOverlay, { backgroundColor: "rgba(0,0,0,0.3)" }]}><Text style={styles.lockOverlayText}>{lang === "fr" ? `🔒 Validez le palier ${i} avec ≥70%` : `🔒 Pass tier ${i} with ≥70%`}</Text></View>)}
                </Pressable>
              );
            })}
          </View>
        </ScrollView>
      </View>
    );
  }

  // ─── Écran de jeu du quiz ──────────────────────────────────────────────────
  if (screen === "quiz_playing") {
    const q = questions[currentQ];
    if (!q) return <Text style={{ color: "#fff", marginTop: 100, textAlign: "center" }}>Chargement...</Text>;
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <View style={[styles.quizContainer, { paddingTop: topPad + 16 }]}>
          <View style={styles.quizHeader}>
            <Pressable onPress={() => setScreen("quiz_tier_select")} style={[styles.exitBtn, { backgroundColor: colors.muted }]}><Feather name="x" size={18} color={colors.foreground} /></Pressable>
            <Text style={[styles.quizProgress, { color: colors.mutedForeground }]}>{currentQ + 1}/{questions.length}</Text>
            <View style={[styles.scoreChip, { backgroundColor: colors.gold }]}><Text style={styles.scoreChipText}>{sessionScore} pts</Text></View>
          </View>
          <GradientView colors={TIER_COLORS[selectedTier]} style={styles.questionCard}>
            <Text style={styles.questionLabel}>Que signifie...</Text>
            <Text style={styles.questionWord}>{q.word}</Text>
          </GradientView>
          <View style={styles.options}>
            {q.options.map((opt, i) => {
              let bg = colors.card, bc = colors.border, tc = colors.foreground;
              if (selectedAnswer !== null) { if (i === q.correctIndex) { bg = colors.deepGreen + "20"; bc = colors.deepGreen; tc = colors.deepGreen; } else if (i === selectedAnswer) { bg = colors.destructive + "20"; bc = colors.destructive; tc = colors.destructive; } }
              return <Pressable key={i} style={[styles.option, { backgroundColor: bg, borderColor: bc }]} onPress={() => handleQuizAnswer(i)} disabled={selectedAnswer !== null}><Text style={[styles.optionText, { color: tc }]}>{["A","B","C","D"][i]}. {opt}</Text></Pressable>;
            })}
          </View>
        </View>
      </View>
    );
  }

  // ─── Écran de résultat du quiz ─────────────────────────────────────────────
  if (screen === "quiz_result") {
    const pct = questions.length > 0 ? Math.round((correctAnswers / questions.length) * 100) : 0;
    const passed = pct >= PASS_SCORE;
    return (
      <View style={[styles.container, { backgroundColor: colors.background }]}>
        <ScrollView contentContainerStyle={[styles.scroll, styles.resultCenter, { paddingTop: topPad + 30 }]}>
          <GradientView colors={passed ? [colors.deepGreen, colors.midGreen] : [colors.terracotta, "#8B2500"]} style={styles.resultBadge}>
            <Text style={styles.resultEmoji}>{pct >= 80 ? "🏆" : pct >= 70 ? "⭐" : "💪"}</Text>
            <Text style={styles.resultPct}>{pct}%</Text>
          </GradientView>
          {passed && selectedTier < 2 && <Text style={[styles.unlockText, { color: colors.gold, marginTop: 8 }]}>🔓 {lang === "fr" ? "Palier suivant débloqué !" : "Next tier unlocked!"}</Text>}
          <View style={styles.resultBtns}>
            <GradientButton title="Rejouer" onPress={() => { const t = QUIZ_DATA_FILTRE[selectedLang]?.[selectedTier]; if (t) startQuizTier(t, selectedTier); }} style={{ flex: 1 }} />
            <GradientButton title="Paliers" onPress={() => setScreen("quiz_tier_select")} variant="secondary" style={{ flex: 1 }} />
          </View>
          <GradientButton title="Menu" onPress={() => setScreen("main_menu")} variant="secondary" />
        </ScrollView>
      </View>
    );
  }

  return <Text style={{ color: "#fff", marginTop: 100, textAlign: "center" }}>Chargement...</Text>;
}