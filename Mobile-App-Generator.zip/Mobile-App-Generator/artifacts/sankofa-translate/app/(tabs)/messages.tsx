import { Feather } from "@expo/vector-icons";
import { GradientView } from "@/components/GradientView";
import { router } from "expo-router";
import React, { useCallback, useEffect, useState, useRef } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  Alert,
  Modal,
  KeyboardAvoidingView,
  ActivityIndicator,
  TouchableOpacity,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { useApp } from "@/context/AppContext";
import { useI18n } from "@/context/I18nContext";
import { useColors } from "@/hooks/useColors";
import { useHaptics } from "@/hooks/useHaptics";

// ─── Types ──────────────────────────────────────────────────────────────────────
interface Message {
  id: string;
  fromId: string;
  fromName: string;
  toId: string;
  toName: string;
  subject: string;
  body: string;
  createdAt: string;
  read: boolean;
  starred: boolean;
  archived: boolean;
  category: "primary" | "social" | "promotions";
}

interface Conversation {
  id: string;
  withId: string;
  withName: string;
  withAvatar?: string;
  subject: string;
  lastMessage: string;
  lastMessageDate: string;
  unreadCount: number;
  starred: boolean;
  category: "primary" | "social" | "promotions";
}

// ─── Clés AsyncStorage ─────────────────────────────────────────────────────────
const STORAGE_KEYS = {
  MESSAGES: "@sankofa_emails",
};

// ─── Service de stockage style Gmail ───────────────────────────────────────────
class EmailStorage {
  static async getAllMessages(): Promise<Message[]> {
    try {
      const data = await AsyncStorage.getItem(STORAGE_KEYS.MESSAGES);
      return data ? JSON.parse(data) : [];
    } catch (error) {
      console.error("Erreur chargement emails:", error);
      return [];
    }
  }

  static async saveAllMessages(messages: Message[]): Promise<void> {
    try {
      await AsyncStorage.setItem(STORAGE_KEYS.MESSAGES, JSON.stringify(messages));
    } catch (error) {
      console.error("Erreur sauvegarde emails:", error);
    }
  }

  static async sendEmail(
    fromId: string,
    fromName: string,
    toId: string,
    toName: string,
    subject: string,
    body: string,
    category: "primary" | "social" | "promotions" = "primary"
  ): Promise<Message | null> {
    try {
      const messages = await this.getAllMessages();

      const newEmail: Message = {
        id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
        fromId,
        fromName,
        toId,
        toName,
        subject: subject.trim(),
        body: body.trim(),
        createdAt: new Date().toISOString(),
        read: false,
        starred: false,
        archived: false,
        category,
      };

      messages.push(newEmail);
      await this.saveAllMessages(messages);
      return newEmail;
    } catch (error) {
      console.error("Erreur envoi email:", error);
      return null;
    }
  }

  static async getInbox(userId: string, category?: string): Promise<Conversation[]> {
    const messages = await this.getAllMessages();

    let received = messages.filter(m => m.toId === userId && !m.archived);

    if (category && category !== "all") {
      received = received.filter(m => m.category === category);
    }

    const conversationsMap = new Map<string, Conversation>();

    received.forEach(msg => {
      const existing = conversationsMap.get(msg.fromId);
      const msgDate = new Date(msg.createdAt);

      if (!existing || msgDate > new Date(existing.lastMessageDate)) {
        conversationsMap.set(msg.fromId, {
          id: msg.fromId,
          withId: msg.fromId,
          withName: msg.fromName,
          subject: msg.subject,
          lastMessage: msg.body,
          lastMessageDate: msg.createdAt,
          unreadCount: existing ? existing.unreadCount + (msg.read ? 0 : 1) : (msg.read ? 0 : 1),
          starred: msg.starred,
          category: msg.category,
        });
      } else if (existing && !msg.read) {
        existing.unreadCount++;
      }
    });

    const conversations = Array.from(conversationsMap.values());

    conversations.sort((a, b) => 
      new Date(b.lastMessageDate).getTime() - new Date(a.lastMessageDate).getTime()
    );

    return conversations;
  }

  static async getSent(userId: string): Promise<Message[]> {
    const messages = await this.getAllMessages();
    return messages
      .filter(m => m.fromId === userId && !m.archived)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  static async getStarred(userId: string): Promise<Conversation[]> {
    const messages = await this.getAllMessages();
    const starredMessages = messages.filter(m => (m.toId === userId || m.fromId === userId) && m.starred && !m.archived);

    const conversationsMap = new Map<string, Conversation>();

    starredMessages.forEach(msg => {
      const otherId = msg.fromId === userId ? msg.toId : msg.fromId;
      const otherName = msg.fromId === userId ? msg.toName : msg.fromName;
      const existing = conversationsMap.get(otherId);
      const msgDate = new Date(msg.createdAt);

      if (!existing || msgDate > new Date(existing.lastMessageDate)) {
        conversationsMap.set(otherId, {
          id: otherId,
          withId: otherId,
          withName: otherName,
          subject: msg.subject,
          lastMessage: msg.body,
          lastMessageDate: msg.createdAt,
          unreadCount: 0,
          starred: true,
          category: msg.category,
        });
      }
    });

    return Array.from(conversationsMap.values());
  }

  static async getConversation(userId: string, otherId: string): Promise<Message[]> {
    const messages = await this.getAllMessages();
    return messages
      .filter(m => 
        (m.fromId === userId && m.toId === otherId) ||
        (m.fromId === otherId && m.toId === userId)
      )
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  static async markAsRead(userId: string, otherId: string): Promise<void> {
    const messages = await this.getAllMessages();
    let updated = false;

    const updatedMessages = messages.map(m => {
      if (m.fromId === otherId && m.toId === userId && !m.read) {
        updated = true;
        return { ...m, read: true };
      }
      return m;
    });

    if (updated) {
      await this.saveAllMessages(updatedMessages);
    }
  }

  static async toggleStar(messageId: string): Promise<boolean> {
    const messages = await this.getAllMessages();
    const index = messages.findIndex(m => m.id === messageId);
    if (index !== -1) {
      messages[index].starred = !messages[index].starred;
      await this.saveAllMessages(messages);
      return true;
    }
    return false;
  }

  static async archiveConversation(userId: string, otherId: string): Promise<boolean> {
    const messages = await this.getAllMessages();
    let updated = false;

    const updatedMessages = messages.map(m => {
      if ((m.fromId === userId && m.toId === otherId) || (m.fromId === otherId && m.toId === userId)) {
        updated = true;
        return { ...m, archived: true };
      }
      return m;
    });

    if (updated) {
      await this.saveAllMessages(updatedMessages);
    }
    return updated;
  }

  static async deleteMessage(messageId: string): Promise<boolean> {
    const messages = await this.getAllMessages();
    const filtered = messages.filter(m => m.id !== messageId);
    await this.saveAllMessages(filtered);
    return true;
  }
}

// ─── Composant d'écriture d'email (Compose) ────────────────────────────────────
function ComposeEmail({ visible, onClose, onSend }: { visible: boolean; onClose: () => void; onSend: () => void }) {
  const colors = useColors();
  const { user, friends, getAllUsers } = useApp();
  const insets = useSafeAreaInsets();
  const [to, setTo] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [category, setCategory] = useState<"primary" | "social" | "promotions">("primary");
  const [sending, setSending] = useState(false);
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);

  // Charger tous les utilisateurs au montage
  useEffect(() => {
    loadAllUsers();
  }, []);

  const loadAllUsers = async () => {
    try {
      // Récupérer tous les utilisateurs (via API ou contexte)
      const users = getAllUsers ? await getAllUsers() : friends || [];
      setAllUsers(users);
    } catch (error) {
      console.error("Erreur chargement utilisateurs:", error);
    }
  };

  // Filtrer les suggestions pendant que l'utilisateur tape
  const handleToChange = (text: string) => {
    setTo(text);

    if (text.length > 0) {
      const filtered = allUsers.filter(u => 
        u.name.toLowerCase().includes(text.toLowerCase()) &&
        u.id !== user?.id // Ne pas s'envoyer à soi-même
      );
      setSuggestions(filtered.slice(0, 5));
    } else {
      setSuggestions([]);
    }
  };

  const selectUser = (selectedUser: any) => {
    setTo(selectedUser.name);
    setSuggestions([]);
  };

  const handleSend = async () => {
    // Vérifications
    if (!to.trim()) {
      Alert.alert("Erreur", "Veuillez entrer le nom du destinataire");
      return;
    }

    if (!subject.trim()) {
      Alert.alert("Erreur", "Veuillez entrer un objet");
      return;
    }

    if (!body.trim()) {
      Alert.alert("Erreur", "Veuillez écrire votre message");
      return;
    }

    if (!user) {
      Alert.alert("Erreur", "Vous devez être connecté");
      return;
    }

    // 1. Vérifier si le destinataire existe dans la base
    const recipient = allUsers.find(u => 
      u.name.toLowerCase() === to.toLowerCase() || 
      u.id === to
    );

    if (!recipient) {
      Alert.alert(
        "Destinataire introuvable", 
        `"${to}" n'existe pas dans Sankofa.\n\nVérifiez le nom ou demandez à la personne de s'inscrire.`
      );
      return;
    }

    // 2. Empêcher l'envoi à soi-même
    if (recipient.id === user.id) {
      Alert.alert("Erreur", "Vous ne pouvez pas vous envoyer un message à vous-même");
      return;
    }

    setSending(true);

    // 3. Envoyer le message
    const result = await EmailStorage.sendEmail(
      user.id,
      user.name,
      recipient.id,
      recipient.name,
      subject,
      body,
      category
    );

    setSending(false);

    if (result) {
      Alert.alert("Succès", "Message envoyé !");
      setTo("");
      setSubject("");
      setBody("");
      onSend();
      onClose();
    } else {
      Alert.alert("Erreur", "Impossible d'envoyer le message");
    }
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={[styles.composeContainer, { backgroundColor: colors.background }]}>
        <View style={[styles.composeHeader, { borderBottomColor: colors.border, paddingTop: insets.top }]}>
          <Pressable onPress={onClose} style={styles.composeCloseBtn}>
            <Feather name="x" size={24} color={colors.foreground} />
          </Pressable>
          <Text style={[styles.composeTitle, { color: colors.foreground }]}>Nouveau message</Text>
          <Pressable onPress={handleSend} disabled={sending} style={[styles.composeSendBtn, { backgroundColor: colors.primary }]}>
            <Text style={styles.composeSendText}>{sending ? "..." : "Envoyer"}</Text>
          </Pressable>
        </View>

        <View style={styles.composeForm}>
          {/* Champ Destinataire avec suggestions */}
          <View style={[styles.composeField, { borderBottomColor: colors.border }]}>
            <Text style={[styles.composeLabel, { color: colors.foreground }]}>À</Text>
            <View style={{ flex: 1 }}>
              <TextInput
                style={[styles.composeInput, { color: colors.foreground }]}
                placeholder="Nom du destinataire"
                placeholderTextColor={colors.mutedForeground}
                value={to}
                onChangeText={handleToChange}
                autoCapitalize="none"
                autoCorrect={false}
              />
              {/* Liste des suggestions */}
              {suggestions.length > 0 && (
                <View style={[styles.suggestionsContainer, { backgroundColor: colors.card, borderColor: colors.border }]}>
                  {suggestions.map((user) => (
                    <TouchableOpacity
                      key={user.id}
                      style={[styles.suggestionItem, { borderBottomColor: colors.border }]}
                      onPress={() => selectUser(user)}
                    >
                      <View style={[styles.suggestionAvatar, { backgroundColor: colors.midGreen }]}>
                        <Text style={styles.suggestionAvatarText}>{user.name.slice(0, 2).toUpperCase()}</Text>
                      </View>
                      <View>
                        <Text style={[styles.suggestionName, { color: colors.foreground }]}>{user.name}</Text>
                        <Text style={[styles.suggestionEmail, { color: colors.mutedForeground }]}>{user.email || "Membre Sankofa"}</Text>
                      </View>
                    </TouchableOpacity>
                  ))}
                </View>
              )}
            </View>
          </View>

          {/* Champ Objet */}
          <View style={[styles.composeField, { borderBottomColor: colors.border }]}>
            <Text style={[styles.composeLabel, { color: colors.foreground }]}>Objet</Text>
            <TextInput
              style={[styles.composeInput, { color: colors.foreground }]}
              placeholder="Objet du message"
              placeholderTextColor={colors.mutedForeground}
              value={subject}
              onChangeText={setSubject}
            />
          </View>

          {/* Catégorie */}
          <View style={styles.composeCategoryRow}>
            <Text style={[styles.composeLabel, { color: colors.foreground }]}>Catégorie</Text>
            <View style={styles.categoryChips}>
              {(["primary", "social", "promotions"] as const).map((cat) => (
                <TouchableOpacity
                  key={cat}
                  style={[styles.categoryChip, { backgroundColor: category === cat ? colors.primary : colors.card, borderColor: colors.border }]}
                  onPress={() => setCategory(cat)}
                >
                  <Text style={[styles.categoryChipText, { color: category === cat ? "#fff" : colors.foreground }]}>
                    {cat === "primary" ? "Principal" : cat === "social" ? "Social" : "Promotions"}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>

          {/* Corps du message */}
          <TextInput
            style={[styles.composeBody, { color: colors.foreground, backgroundColor: colors.card }]}
            placeholder="Écrivez votre message..."
            placeholderTextColor={colors.mutedForeground}
            value={body}
            onChangeText={setBody}
            multiline
            textAlignVertical="top"
          />
        </View>
      </View>
    </Modal>
  );
}

// ─── Composant de lecture d'email (Thread) ─────────────────────────────────────
function EmailThread({ email, onClose, onArchive, userId }: { email: Conversation; onClose: () => void; onArchive: () => void; userId: string }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadThread();
  }, [email.id]);

  const loadThread = async () => {
    const msgs = await EmailStorage.getConversation(userId, email.withId);
    setMessages(msgs);
    await EmailStorage.markAsRead(userId, email.withId);
    setLoading(false);
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString() + " à " + date.toLocaleTimeString().slice(0, 5);
  };

  if (loading) {
    return (
      <View style={[styles.threadContainer, { backgroundColor: colors.background, justifyContent: "center", alignItems: "center" }]}>
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  return (
    <View style={[styles.threadContainer, { backgroundColor: colors.background }]}>
      <View style={[styles.threadHeader, { borderBottomColor: colors.border, paddingTop: insets.top }]}>
        <Pressable onPress={onClose} style={styles.threadBackBtn}>
          <Feather name="arrow-left" size={24} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.threadTitle, { color: colors.foreground }]} numberOfLines={1}>
          {email.subject}
        </Text>
        <Pressable onPress={onArchive} style={styles.threadArchiveBtn}>
          <Feather name="archive" size={22} color={colors.mutedForeground} />
        </Pressable>
      </View>

      <FlatList
        data={messages}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.threadList}
        renderItem={({ item }) => {
          const isMe = item.fromId === userId;
          return (
            <View style={[styles.emailCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
              <View style={styles.emailHeader}>
                <View style={[styles.emailAvatar, { backgroundColor: colors.primary }]}>
                  <Text style={styles.emailAvatarText}>{(isMe ? item.toName : item.fromName).slice(0, 2).toUpperCase()}</Text>
                </View>
                <View style={styles.emailHeaderInfo}>
                  <Text style={[styles.emailFrom, { color: colors.foreground }]}>
                    {isMe ? `Moi → ${item.toName}` : item.fromName}
                  </Text>
                  <Text style={[styles.emailDate, { color: colors.mutedForeground }]}>{formatDate(item.createdAt)}</Text>
                </View>
              </View>
              <Text style={[styles.emailSubject, { color: colors.foreground }]}>{item.subject}</Text>
              <Text style={[styles.emailBody, { color: colors.foreground }]}>{item.body}</Text>
            </View>
          );
        }}
      />
    </View>
  );
}

// ─── Composant principal (Boîte de réception style Gmail) ──────────────────────
export default function MessagesScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { lang } = useI18n();
  const { user, friends, getAllUsers } = useApp();
  const { impact } = useHaptics();

  const [activeTab, setActiveTab] = useState<"inbox" | "sent" | "starred">("inbox");
  const [category, setCategory] = useState<"all" | "primary" | "social" | "promotions">("all");
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [sentEmails, setSentEmails] = useState<Message[]>([]);
  const [starredEmails, setStarredEmails] = useState<Conversation[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [showCompose, setShowCompose] = useState(false);
  const [selectedEmail, setSelectedEmail] = useState<Conversation | null>(null);

  const loadData = useCallback(async () => {
    if (!user) return;

    if (activeTab === "inbox") {
      const inbox = await EmailStorage.getInbox(user.id, category === "all" ? undefined : category);
      setConversations(inbox);
    } else if (activeTab === "sent") {
      const sent = await EmailStorage.getSent(user.id);
      setSentEmails(sent);
    } else if (activeTab === "starred") {
      const starred = await EmailStorage.getStarred(user.id);
      setStarredEmails(starred);
    }

    setLoading(false);
    setRefreshing(false);
  }, [user, activeTab, category]);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, [loadData]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadData();
  };

  const handleArchive = async (friendId: string) => {
    if (user) {
      await EmailStorage.archiveConversation(user.id, friendId);
      await loadData();
      impact();
      setSelectedEmail(null);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));

    if (days === 0) return date.toLocaleTimeString().slice(0, 5);
    if (days === 1) return "hier";
    if (days < 7) return `${days}j`;
    return date.toLocaleDateString();
  };

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  if (selectedEmail) {
    return (
      <EmailThread
        email={selectedEmail}
        onClose={() => setSelectedEmail(null)}
        onArchive={() => handleArchive(selectedEmail.withId)}
        userId={user?.id || ""}
      />
    );
  }

  if (showCompose) {
    return <ComposeEmail visible={showCompose} onClose={() => setShowCompose(false)} onSend={loadData} />;
  }

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Header Gmail */}
      <GradientView colors={[colors.deepGreen || "#2E7D32", colors.midGreen || "#4CAF50"]} style={[styles.header, { paddingTop: topPad }]}>
        <View style={styles.headerTop}>
          <Feather name="menu" size={24} color="#fff" />
          <Text style={styles.headerTitle}>Sankofa Mail</Text>
          <Pressable onPress={() => setShowCompose(true)}>
            <Feather name="edit-2" size={22} color="#fff" />
          </Pressable>
        </View>
        <View style={styles.tabsContainer}>
          <Pressable onPress={() => setActiveTab("inbox")} style={[styles.tab, activeTab === "inbox" && styles.tabActive]}>
            <Feather name="inbox" size={20} color={activeTab === "inbox" ? "#fff" : "rgba(255,255,255,0.7)"} />
            <Text style={[styles.tabText, activeTab === "inbox" && styles.tabTextActive]}>Reçu</Text>
          </Pressable>
          <Pressable onPress={() => setActiveTab("sent")} style={[styles.tab, activeTab === "sent" && styles.tabActive]}>
            <Feather name="send" size={20} color={activeTab === "sent" ? "#fff" : "rgba(255,255,255,0.7)"} />
            <Text style={[styles.tabText, activeTab === "sent" && styles.tabTextActive]}>Envoyés</Text>
          </Pressable>
          <Pressable onPress={() => setActiveTab("starred")} style={[styles.tab, activeTab === "starred" && styles.tabActive]}>
            <Feather name="star" size={20} color={activeTab === "starred" ? "#fff" : "rgba(255,255,255,0.7)"} />
            <Text style={[styles.tabText, activeTab === "starred" && styles.tabTextActive]}>Starred</Text>
          </Pressable>
        </View>
      </GradientView>

      {/* Catégories (style Gmail) */}
      {activeTab === "inbox" && (
        <View style={[styles.categoriesContainer, { borderBottomColor: colors.border }]}>
          {(["all", "primary", "social", "promotions"] as const).map((cat) => (
            <Pressable key={cat} onPress={() => setCategory(cat)} style={[styles.categoryTab, category === cat && { borderBottomColor: colors.primary, borderBottomWidth: 2 }]}>
              <Text style={[styles.categoryText, { color: category === cat ? colors.primary : colors.mutedForeground }]}>
                {cat === "all" ? "Tout" : cat === "primary" ? "Principal" : cat === "social" ? "Social" : "Promotions"}
              </Text>
            </Pressable>
          ))}
        </View>
      )}

      {/* Liste des conversations */}
      <FlatList
        data={activeTab === "inbox" ? conversations : activeTab === "sent" ? sentEmails : starredEmails}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ paddingBottom: 84 }}
        showsVerticalScrollIndicator={false}
        refreshing={refreshing}
        onRefresh={handleRefresh}
        renderItem={({ item, index }) => {
          const isSent = activeTab === "sent";
          const convo = item as any;
          return (
            <Pressable
              style={[styles.emailRow, { backgroundColor: colors.card, borderBottomColor: colors.border }]}
              onPress={() => {
                impact();
                if (isSent) {
                  Alert.alert(
                    convo.subject, 
                    `À: ${convo.toName}\n\n${convo.body}`,
                    [{ text: "OK" }]
                  );
                } else {
                  setSelectedEmail(convo);
                }
              }}
            >
              <View style={styles.emailRowLeft}>
                <View style={[styles.emailRowAvatar, { backgroundColor: colors.midGreen }]}>
                  <Text style={styles.emailRowAvatarText}>
                    {(isSent ? convo.toName : convo.withName).slice(0, 2).toUpperCase()}
                  </Text>
                </View>
                <View style={styles.emailRowContent}>
                  <Text style={[styles.emailRowName, { color: colors.foreground }]} numberOfLines={1}>
                    {isSent ? convo.toName : convo.withName}
                  </Text>
                  <Text style={[styles.emailRowSubject, { color: colors.foreground }]} numberOfLines={1}>
                    {convo.subject}
                  </Text>
                  <Text style={[styles.emailRowPreview, { color: colors.mutedForeground }]} numberOfLines={1}>
                    {convo.lastMessage || convo.body}
                  </Text>
                </View>
              </View>
              <View style={styles.emailRowRight}>
                <Text style={[styles.emailRowDate, { color: colors.mutedForeground }]}>
                  {formatDate(isSent ? convo.createdAt : convo.lastMessageDate)}
                </Text>
                {!isSent && (convo.unreadCount > 0) && (
                  <View style={[styles.unreadDot, { backgroundColor: colors.primary }]} />
                )}
              </View>
            </Pressable>
          );
        }}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Feather name="mail" size={48} color={colors.mutedForeground} />
            <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
              {activeTab === "inbox" ? "Boîte de réception vide" : activeTab === "sent" ? "Aucun email envoyé" : "Aucun email favori"}
            </Text>
          </View>
        }
      />

      {/* Bouton flottant "Nouvel email" */}
      <Pressable style={[styles.fab, { backgroundColor: colors.primary }]} onPress={() => setShowCompose(true)}>
        <Feather name="edit-2" size={24} color="#fff" />
      </Pressable>
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────
const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { paddingHorizontal: 16, paddingBottom: 12 },
  headerTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  headerTitle: { color: "#fff", fontSize: 22, fontWeight: "700" },
  tabsContainer: { flexDirection: "row", gap: 24 },
  tab: { flexDirection: "row", alignItems: "center", gap: 6, paddingBottom: 8 },
  tabActive: { borderBottomWidth: 2, borderBottomColor: "#fff" },
  tabText: { color: "rgba(255,255,255,0.7)", fontSize: 14 },
  tabTextActive: { color: "#fff", fontWeight: "600" },

  categoriesContainer: { flexDirection: "row", paddingHorizontal: 16, paddingVertical: 10, borderBottomWidth: 1, gap: 20 },
  categoryTab: { paddingBottom: 8 },
  categoryText: { fontSize: 14, fontWeight: "500" },

  emailRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1 },
  emailRowLeft: { flexDirection: "row", alignItems: "center", flex: 1, gap: 12 },
  emailRowAvatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  emailRowAvatarText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  emailRowContent: { flex: 1, gap: 3 },
  emailRowName: { fontSize: 15, fontWeight: "600" },
  emailRowSubject: { fontSize: 13, fontWeight: "500" },
  emailRowPreview: { fontSize: 12 },
  emailRowRight: { alignItems: "flex-end", gap: 6, marginLeft: 8 },
  emailRowDate: { fontSize: 11 },
  unreadDot: { width: 8, height: 8, borderRadius: 4 },

  emptyContainer: { alignItems: "center", paddingVertical: 80, gap: 12 },
  emptyTitle: { fontSize: 18, fontWeight: "700", marginTop: 12 },

  fab: { position: "absolute", bottom: 24, right: 24, width: 56, height: 56, borderRadius: 28, alignItems: "center", justifyContent: "center", elevation: 4, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.25, shadowRadius: 4 },

  // Compose styles
  composeContainer: { flex: 1 },
  composeHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  composeCloseBtn: { padding: 8, width: 44 },
  composeTitle: { fontSize: 18, fontWeight: "700" },
  composeSendBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20 },
  composeSendText: { color: "#fff", fontWeight: "600", fontSize: 14 },
  composeForm: { flex: 1, padding: 16, gap: 16 },
  composeField: { flexDirection: "row", alignItems: "center", borderBottomWidth: 1, paddingVertical: 12 },
  composeLabel: { width: 50, fontSize: 16, fontWeight: "500" },
  composeInput: { flex: 1, fontSize: 16, paddingVertical: 0 },
  composeCategoryRow: { flexDirection: "row", alignItems: "center", gap: 16, marginTop: 8 },
  categoryChips: { flexDirection: "row", gap: 8 },
  categoryChip: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, borderWidth: 1 },
  categoryChipText: { fontSize: 12, fontWeight: "500" },
  composeBody: { flex: 1, borderRadius: 12, padding: 14, fontSize: 15, textAlignVertical: "top", minHeight: 200 },

  // Suggestion styles
  suggestionsContainer: { position: "absolute", top: 50, left: 0, right: 0, borderRadius: 12, borderWidth: 1, zIndex: 1000 },
  suggestionItem: { flexDirection: "row", alignItems: "center", gap: 12, padding: 12, borderBottomWidth: 0.5 },
  suggestionAvatar: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  suggestionAvatarText: { color: "#fff", fontWeight: "600", fontSize: 14 },
  suggestionName: { fontSize: 14, fontWeight: "500" },
  suggestionEmail: { fontSize: 11 },

  // Thread styles
  threadContainer: { flex: 1 },
  threadHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 16, paddingBottom: 12, borderBottomWidth: 1 },
  threadBackBtn: { padding: 8, width: 44 },
  threadTitle: { flex: 1, fontSize: 16, fontWeight: "600", textAlign: "center" },
  threadArchiveBtn: { padding: 8, width: 44, alignItems: "flex-end" },
  threadList: { padding: 16, gap: 16 },
  emailCard: { borderRadius: 12, borderWidth: 1, padding: 16, gap: 12 },
  emailHeader: { flexDirection: "row", alignItems: "center", gap: 12 },
  emailAvatar: { width: 44, height: 44, borderRadius: 22, alignItems: "center", justifyContent: "center" },
  emailAvatarText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  emailHeaderInfo: { flex: 1 },
  emailFrom: { fontSize: 15, fontWeight: "600" },
  emailDate: { fontSize: 11, marginTop: 2 },
  emailSubject: { fontSize: 16, fontWeight: "700" },
  emailBody: { fontSize: 14, lineHeight: 20 },
});

// ─── Export du service ─────────────────────────────────────────────────────────
export { EmailStorage };