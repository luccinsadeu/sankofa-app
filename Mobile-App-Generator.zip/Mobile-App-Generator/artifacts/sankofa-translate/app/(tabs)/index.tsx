// app/(tabs)/index.tsx
import { MaterialIcons } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import { GradientView } from "@/components/GradientView";
import {
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { FadeInDownView, FadeInView, ZoomInView } from "@/components/AnimatedContainers";
import { Card, ScoreBadge } from "@/components/ui";
import { useApp } from "@/context/AppContext";
import { useI18n } from "@/context/I18nContext";
import { useColors } from "@/hooks/useColors";
import { useHaptics } from "@/hooks/useHaptics";
import { QUIZ_LANGUAGES } from "@/theme/quiz";

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, totalScore, posts, friends } = useApp();
  const { lang } = useI18n();
  const { impact } = useHaptics();

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 + 84 : insets.bottom + 84;

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return lang === "fr" ? "Bonjour" : "Good morning";
    if (h < 18) return lang === "fr" ? "Bon après-midi" : "Good afternoon";
    return lang === "fr" ? "Bonsoir" : "Good evening";
  };

  const recentPosts = posts.slice(0, 3);

  const quickActions = [
    { icon: "language", label: lang === "fr" ? "Traduire" : "Translate", color: colors.midGreen, route: "/(tabs)/translate" },
    { icon: "emoji-events", label: "Quiz", color: colors.gold, route: "/(tabs)/games" },
    { icon: "group", label: "Social", color: colors.terracotta, route: "/(tabs)/social" },
    { icon: "chat-bubble", label: lang === "fr" ? "Messages" : "Messages", color: colors.accent, route: "/(tabs)/messages" },
  ];

  const languesNonCamerounaises = QUIZ_LANGUAGES.filter(
    l => !["ew", "du", "gh", "ff", "bu", "gb"].includes(l.code)
  );

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={{ paddingTop: topPad + 16, paddingBottom: bottomPad, paddingHorizontal: 16, gap: 20 }}
      showsVerticalScrollIndicator={false}
    >
      <FadeInView>
        <GradientView
          colors={[colors.deepGreen, colors.midGreen]}
          style={styles.heroCard}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <View style={styles.heroTop}>
            <View>
              <Text style={styles.heroGreeting}>{greeting()},</Text>
              <Text style={styles.heroName}>{user?.name?.split(" ")[0] ?? "Voyageur"} 👋</Text>
            </View>
            <ScoreBadge score={totalScore} />
          </View>
          <Text style={styles.heroSub}>
            {friends.length} {lang === "fr" ? `ami${friends.length !== 1 ? "s" : ""}` : "friends"} · {posts.length} {lang === "fr" ? `publication${posts.length !== 1 ? "s" : ""}` : "posts"}
          </Text>
          <Pressable style={styles.heroBtn} onPress={() => { impact(); router.push("/(tabs)/translate"); }}>
            <MaterialIcons name="language" size={16} color="#fff" />
            <Text style={styles.heroBtnText}>{lang === "fr" ? "Traduire maintenant" : "Translate now"}</Text>
            <MaterialIcons name="arrow-forward" size={16} color="#fff" />
          </Pressable>
        </GradientView>
      </FadeInView>

      <View style={styles.statsRow}>
        <StatCard icon="show-chart" value={totalScore} label={lang === "fr" ? "Score" : "Score"} color={colors.gold} delay={100} />
        <StatCard icon="group" value={friends.length} label={lang === "fr" ? "Amis" : "Friends"} color={colors.midGreen} delay={160} />
        <StatCard icon="menu-book" value={languesNonCamerounaises.length} label={lang === "fr" ? "Langues" : "Languages"} color={colors.terracotta} delay={220} />
      </View>

      <FadeInDownView delay={150}>
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            {lang === "fr" ? "Langues disponibles" : "Available languages"}
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.langRow}>
            {languesNonCamerounaises.map(l => (
              <Pressable key={l.code} style={[styles.langChip, { backgroundColor: colors.secondary, borderColor: colors.border }]} onPress={() => { impact(); router.push("/(tabs)/translate"); }}>
                <Text style={{ fontSize: 18 }}>{l.flag}</Text>
                <Text style={[styles.langChipText, { color: colors.foreground }]}>{l.name}</Text>
              </Pressable>
            ))}
          </ScrollView>
        </View>
      </FadeInDownView>

      <FadeInDownView delay={220}>
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              {lang === "fr" ? "Actions rapides" : "Quick actions"}
            </Text>
          </View>
          <View style={styles.actionsGrid}>
            {quickActions.map((a, i) => (
              <Pressable key={i} style={[styles.actionCard, { backgroundColor: colors.card, borderColor: colors.border }]} onPress={() => { impact(); router.push(a.route as any); }}>
                <View style={[styles.actionIcon, { backgroundColor: a.color + "20" }]}>
                  <MaterialIcons name={a.icon as any} size={24} color={a.color} />
                </View>
                <Text style={[styles.actionLabel, { color: colors.foreground }]}>{a.label}</Text>
              </Pressable>
            ))}
          </View>
        </View>
      </FadeInDownView>

      {recentPosts.length > 0 && (
        <FadeInDownView delay={300}>
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
                {lang === "fr" ? "Publications récentes" : "Recent posts"}
              </Text>
              <Pressable onPress={() => router.push("/(tabs)/social")}>
                <Text style={[styles.seeAll, { color: colors.accent }]}>
                  {lang === "fr" ? "Voir tout" : "See all"}
                </Text>
              </Pressable>
            </View>
            {recentPosts.map(p => (
              <Card key={p.id} style={styles.postCard}>
                <View style={styles.postHeader}>
                  <View style={[styles.avatar, { backgroundColor: colors.deepGreen }]}>
                    <Text style={styles.avatarText}>{p.authorName[0]}</Text>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.postAuthor, { color: colors.foreground }]}>{p.authorName}</Text>
                    <Text style={[styles.postLang, { color: colors.mutedForeground }]}>
                      {languesNonCamerounaises.find(l => l.code === p.language)?.name ?? p.language}
                    </Text>
                  </View>
                </View>
                <Text style={[styles.postContent, { color: colors.foreground }]}>{p.content}</Text>
                {p.translation && (
                  <Text style={[styles.postTranslation, { color: colors.mutedForeground }]}>
                    ↳ {p.translation}
                  </Text>
                )}
              </Card>
            ))}
          </View>
        </FadeInDownView>
      )}
    </ScrollView>
  );
}

function StatCard({ icon, value, label, color, delay = 0 }: { icon: string; value: string | number; label: string; color: string; delay?: number }) {
  const colors = useColors();
  return (
    <ZoomInView delay={delay} style={{ flex: 1 }}>
      <Card style={styles.statCard}>
        <View style={[styles.statIcon, { backgroundColor: color + "20" }]}>
          <MaterialIcons name={icon as any} size={20} color={color} />
        </View>
        <Text style={[styles.statValue, { color: colors.foreground }]}>{value}</Text>
        <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
      </Card>
    </ZoomInView>
  );
}

const styles = StyleSheet.create({
  heroCard: { borderRadius: 20, padding: 20, gap: 8 },
  heroTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" },
  heroGreeting: { color: "rgba(255,255,255,0.7)", fontSize: 14 },
  heroName: { color: "#fff", fontSize: 22, fontWeight: "800" },
  heroSub: { color: "rgba(255,255,255,0.65)", fontSize: 13 },
  heroBtn: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 100, paddingVertical: 10, paddingHorizontal: 16, alignSelf: "flex-start", marginTop: 4 },
  heroBtnText: { color: "#fff", fontWeight: "600", fontSize: 14 },
  statsRow: { flexDirection: "row", gap: 10 },
  statCard: { flex: 1, alignItems: "center", gap: 4, padding: 14 },
  statIcon: { width: 36, height: 36, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  statValue: { fontSize: 18, fontWeight: "800" },
  statLabel: { fontSize: 11, fontWeight: "500" },
  section: { gap: 12 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sectionTitle: { fontSize: 17, fontWeight: "700" },
  seeAll: { fontSize: 13, fontWeight: "600" },
  langRow: { marginHorizontal: -4, flexDirection: "row" },
  langChip: { flexDirection: "row", alignItems: "center", gap: 6, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 100, borderWidth: 1, marginHorizontal: 4 },
  langChipText: { fontSize: 13, fontWeight: "600" },
  actionsGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  actionCard: { width: "47%", borderRadius: 16, borderWidth: 1, padding: 16, alignItems: "center", gap: 10 },
  actionIcon: { width: 48, height: 48, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  actionLabel: { fontSize: 14, fontWeight: "600" },
  postCard: { gap: 10, padding: 14 },
  postHeader: { flexDirection: "row", alignItems: "center", gap: 10 },
  avatar: { width: 36, height: 36, borderRadius: 18, alignItems: "center", justifyContent: "center" },
  avatarText: { color: "#fff", fontWeight: "700", fontSize: 15 },
  postAuthor: { fontSize: 14, fontWeight: "700" },
  postLang: { fontSize: 12 },
  postContent: { fontSize: 15, fontWeight: "500" },
  postTranslation: { fontSize: 13, fontStyle: "italic" },
});