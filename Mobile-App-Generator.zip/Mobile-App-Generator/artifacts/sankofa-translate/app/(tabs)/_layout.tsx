import { MaterialIcons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import React from "react";
import { Platform, StyleSheet, View, useColorScheme } from "react-native";
import { useI18n } from "@/context/I18nContext";
import { useColors } from "@/hooks/useColors";

export default function TabLayout() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const { t } = useI18n();
  const isDark = colorScheme === "dark";
  const isIOS = Platform.OS === "ios";
  const isAndroid = Platform.OS === "android";

  // Couleurs personnalisées pour chaque onglet
  const iconColors = {
    index: { default: "#4CAF50", active: "#2E7D32" },        // vert
    translate: { default: "#2196F3", active: "#0B5E9E" },    // bleu
    games: { default: "#FFC107", active: "#FF8F00" },        // jaune/or
    social: { default: "#9C27B0", active: "#6A1B9A" },       // violet
    messages: { default: "#00BCD4", active: "#00838F" },     // cyan
    profile: { default: "#FF5722", active: "#BF360C" },      // orange
  };

  // Valeurs par défaut si les couleurs ne sont pas définies dans useColors()
  const activeColorGlobal = colors.primary || "#0D2E0F";
  const inactiveColorGlobal = colors.mutedForeground || "#9CA3AF";

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: activeColorGlobal,
        tabBarInactiveTintColor: inactiveColorGlobal,
        tabBarStyle: {
          ...(isIOS && {
            position: "absolute",
            backgroundColor: "transparent",
            borderTopWidth: 0,
            elevation: 0,
          }),
          ...(isAndroid && {
            backgroundColor: colors.background,
            borderTopWidth: 0,
            height: 60,
            paddingBottom: 8,
            paddingTop: 6,
            elevation: 0,
          }),
          ...(Platform.OS === "web" && {
            position: "absolute",
            backgroundColor: colors.background,
            borderTopWidth: 1,
            borderTopColor: colors.border,
            height: 84,
            elevation: 0,
          }),
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: "600",
          marginTop: isAndroid ? 2 : 0,
        },
        tabBarItemStyle: {
          paddingVertical: isAndroid ? 6 : 0,
        },
        tabBarBackground: () =>
          isIOS ? (
            <View
              style={[
                StyleSheet.absoluteFill,
                {
                  backgroundColor: isDark
                    ? "rgba(13,27,14,0.92)"
                    : "rgba(255,255,255,0.92)",
                },
              ]}
            />
          ) : undefined,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: t("home"),
          tabBarIcon: ({ focused }) => (
            <MaterialIcons
              name="home"
              size={22}
              color={focused ? iconColors.index.active : iconColors.index.default}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="translate"
        options={{
          title: t("translate"),
          tabBarIcon: ({ focused }) => (
            <MaterialIcons
              name="language"
              size={22}
              color={focused ? iconColors.translate.active : iconColors.translate.default}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="games"
        options={{
          title: t("games"),
          tabBarIcon: ({ focused }) => (
            <MaterialIcons
              name="emoji-events"
              size={22}
              color={focused ? iconColors.games.active : iconColors.games.default}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="social"
        options={{
          title: t("social"),
          tabBarIcon: ({ focused }) => (
            <MaterialIcons
              name="group"
              size={22}
              color={focused ? iconColors.social.active : iconColors.social.default}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          title: t("messages"),
          tabBarIcon: ({ focused }) => (
            <MaterialIcons
              name="chat-bubble"
              size={22}
              color={focused ? iconColors.messages.active : iconColors.messages.default}
            />
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: t("profile"),
          tabBarIcon: ({ focused }) => (
            <MaterialIcons
              name="person"
              size={22}
              color={focused ? iconColors.profile.active : iconColors.profile.default}
            />
          ),
        }}
      />
    </Tabs>
  );
}