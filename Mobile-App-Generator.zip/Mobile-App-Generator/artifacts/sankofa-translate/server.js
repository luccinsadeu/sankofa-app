import express from "express";
import cors from "cors";
import pg from "pg";
import path from "node:path";
import { fileURLToPath } from "node:url";

const { Pool } = pg;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Connexion PostgreSQL.
// Configure DATABASE_URL avec les identifiants réels de ta base.
const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ||
    "postgresql://postgres:password@helium/heliumdb?sslmode=disable",
});

const landingPagePath = path.join(
  __dirname,
  "server",
  "templates",
  "landing-page.html",
);

app.use(cors());
app.use(express.json({ limit: "10mb" }));

// Page d'accueil Sankofa Traduction
app.get("/", (req, res) => {
  res.sendFile(landingPagePath, (error) => {
    if (error && !res.headersSent) {
      console.error("Erreur page d’accueil :", error.message);
      res.status(500).send("Impossible de charger la page Sankofa Traduction.");
    }
  });
});

// Vérification du serveur et de la base de données
app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ status: "ok", database: "connected" });
  } catch (error) {
    console.error("Erreur base de données :", error.message);
    res.status(503).json({
      status: "error",
      database: "unavailable",
    });
  }
});

// Récupérer les publications et leur nombre de mentions J’aime
app.get("/posts", async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        p.*,
        COALESCE(l.likes_count, 0)::int AS likes_count
      FROM posts p
      LEFT JOIN (
        SELECT post_id, COUNT(*)::int AS likes_count
        FROM likes
        GROUP BY post_id
      ) l ON l.post_id = p.id
      ORDER BY p.created_at DESC NULLS LAST, p.id DESC
    `);

    res.json(result.rows);
  } catch (error) {
    console.error("GET /posts :", error.message);
    res.status(500).json({
      error: "Impossible de récupérer les publications.",
    });
  }
});

// Créer une publication
app.post("/posts", async (req, res) => {
  const {
    author_id,
    author_name,
    content,
    language,
    translation,
    image_uri,
    created_at,
  } = req.body ?? {};

  if (!author_id || !author_name || !content) {
    return res.status(400).json({
      error: "author_id, author_name et content sont obligatoires.",
    });
  }

  try {
    const result = await pool.query(
      `INSERT INTO posts (
        author_id,
        author_name,
        content,
        language,
        translation,
        image_uri,
        created_at
      )
      VALUES ($1, $2, $3, $4, $5, $6, COALESCE($7::timestamptz, NOW()))
      RETURNING *`,
      [
        author_id,
        author_name,
        content,
        language ?? null,
        translation ?? null,
        image_uri ?? null,
        created_at ?? null,
      ],
    );

    res.status(201).json({
      ...result.rows[0],
      likes_count: 0,
    });
  } catch (error) {
    console.error("POST /posts :", error.message);
    res.status(500).json({
      error: "Impossible de créer la publication.",
    });
  }
});

// Ajouter ou retirer une mention J’aime
app.post("/posts/:id/like", async (req, res) => {
  const postId = Number.parseInt(req.params.id, 10);
  const { user_id } = req.body ?? {};

  if (!Number.isInteger(postId) || postId <= 0) {
    return res.status(400).json({ error: "ID de publication invalide." });
  }

  if (user_id === undefined || user_id === null || user_id === "") {
    return res.status(400).json({ error: "user_id est obligatoire." });
  }

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    const post = await client.query("SELECT id FROM posts WHERE id = $1", [
      postId,
    ]);

    if (post.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ error: "Publication introuvable." });
    }

    const existingLike = await client.query(
      "SELECT 1 FROM likes WHERE post_id = $1 AND user_id = $2",
      [postId, user_id],
    );

    let liked;

    if (existingLike.rowCount > 0) {
      await client.query(
        "DELETE FROM likes WHERE post_id = $1 AND user_id = $2",
        [postId, user_id],
      );
      liked = false;
    } else {
      await client.query(
        "INSERT INTO likes (post_id, user_id) VALUES ($1, $2)",
        [postId, user_id],
      );
      liked = true;
    }

    const count = await client.query(
      "SELECT COUNT(*)::int AS likes_count FROM likes WHERE post_id = $1",
      [postId],
    );

    await client.query("COMMIT");

    res.json({
      post_id: postId,
      user_id,
      liked,
      likes_count: count.rows[0].likes_count,
    });
  } catch (error) {
    await client.query("ROLLBACK").catch(() => {});
    console.error("POST /posts/:id/like :", error.message);
    res.status(500).json({
      error: "Impossible de modifier la mention J’aime.",
    });
  } finally {
    client.release();
  }
});

// Ajouter un commentaire
app.post("/posts/:id/comments", async (req, res) => {
  const postId = Number.parseInt(req.params.id, 10);
  const { author_id, author_name, content, created_at } = req.body ?? {};

  if (!Number.isInteger(postId) || postId <= 0) {
    return res.status(400).json({ error: "ID de publication invalide." });
  }

  if (!author_id || !author_name || !content) {
    return res.status(400).json({
      error: "author_id, author_name et content sont obligatoires.",
    });
  }

  try {
    const post = await pool.query("SELECT id FROM posts WHERE id = $1", [
      postId,
    ]);

    if (post.rowCount === 0) {
      return res.status(404).json({ error: "Publication introuvable." });
    }

    const result = await pool.query(
      `INSERT INTO comments (
        post_id,
        author_id,
        author_name,
        content,
        created_at
      )
      VALUES ($1, $2, $3, $4, COALESCE($5::timestamptz, NOW()))
      RETURNING *`,
      [postId, author_id, author_name, content, created_at ?? null],
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error("POST /posts/:id/comments :", error.message);
    res.status(500).json({
      error: "Impossible d’ajouter le commentaire.",
    });
  }
});

// Récupérer les commentaires d’une publication
app.get("/posts/:id/comments", async (req, res) => {
  const postId = Number.parseInt(req.params.id, 10);

  if (!Number.isInteger(postId) || postId <= 0) {
    return res.status(400).json({ error: "ID de publication invalide." });
  }

  try {
    const result = await pool.query(
      `SELECT *
       FROM comments
       WHERE post_id = $1
       ORDER BY created_at ASC NULLS LAST, id ASC`,
      [postId],
    );

    res.json(result.rows);
  } catch (error) {
    console.error("GET /posts/:id/comments :", error.message);
    res.status(500).json({
      error: "Impossible de récupérer les commentaires.",
    });
  }
});

// Rechercher un utilisateur par e-mail ou en créer un
app.post("/users", async (req, res) => {
  const { name, email } = req.body ?? {};

  if (typeof email !== "string" || !email.trim()) {
    return res.status(400).json({
      error: "Une adresse e-mail valide est obligatoire.",
    });
  }

  const normalizedEmail = email.trim().toLowerCase();

  try {
    const existing = await pool.query(
      "SELECT * FROM users WHERE LOWER(email) = $1 LIMIT 1",
      [normalizedEmail],
    );

    if (existing.rowCount > 0) {
      return res.json(existing.rows[0]);
    }

    if (typeof name !== "string" || !name.trim()) {
      return res.status(404).json({
        error: "Utilisateur introuvable. Un nom est nécessaire pour le créer.",
      });
    }

    const created = await pool.query(
      `INSERT INTO users (name, email)
       VALUES ($1, $2)
       RETURNING *`,
      [name.trim(), normalizedEmail],
    );

    res.status(201).json(created.rows[0]);
  } catch (error) {
    console.error("POST /users :", error.message);
    res.status(500).json({
      error: "Impossible de rechercher ou de créer cet utilisateur.",
    });
  }
});

// Informations sur l’API
app.get("/api", (req, res) => {
  res.json({
    name: "Sankofa Traduction API",
    status: "running",
    endpoints: [
      "GET /api/health",
      "GET /posts",
      "POST /posts",
      "POST /posts/:id/like",
      "GET /posts/:id/comments",
      "POST /posts/:id/comments",
      "POST /users",
    ],
  });
});

// Route API inconnue
app.use("/api", (req, res) => {
  res.status(404).json({ error: "Route API introuvable." });
});

// Gestion des erreurs
app.use((error, req, res, next) => {
  console.error("Erreur serveur :", error.message);

  if (res.headersSent) {
    return next(error);
  }

  if (error instanceof SyntaxError && "body" in error) {
    return res.status(400).json({ error: "Corps JSON invalide." });
  }

  return res.status(500).json({ error: "Erreur interne du serveur." });
});

// Démarrer le serveur
const server = app.listen(PORT, () => {
  console.log(`Sankofa Traduction écoute sur le port ${PORT}`);
});

// Fermeture propre du serveur et de la connexion PostgreSQL
async function shutdown(signal) {
  console.log(`${signal} reçu. Arrêt du serveur...`);

  server.close(async () => {
    await pool.end().catch((error) => {
      console.error("Erreur de fermeture PostgreSQL :", error.message);
    });

    process.exit(0);
  });
}

process.on("SIGINT", () => shutdown("SIGINT"));
process.on("SIGTERM", () => shutdown("SIGTERM"));
