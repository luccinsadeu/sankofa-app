const path = require('node:path');
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// The workspace Node 24 compatibility patch adds a build/index.js stub for
// Node tooling. Metro must bundle the real Expo module core implementation.
const expoPackageJson = require.resolve('expo/package.json');
const expoModulesCorePackageJson = require.resolve(
  'expo-modules-core/package.json',
  { paths: [path.dirname(expoPackageJson)] },
);
const expoModulesCoreSource = path.join(
  path.dirname(expoModulesCorePackageJson),
  'src/index.ts',
);

// Fix PNPM + expo-router path
config.resolver.nodeModulesPaths = [
  __dirname + '/node_modules',
  __dirname + '/../../node_modules'  // Monorepo root
];

config.resolver.resolveRequest = (context, moduleName, platform) => {
  if (moduleName === 'expo-modules-core') {
    return { type: 'sourceFile', filePath: expoModulesCoreSource };
  }
  return context.resolveRequest(context, moduleName, platform);
};

module.exports = config;