import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useRef, useState } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────
export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  joinedAt: string;
}

export interface Comment {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  createdAt: string;
}

export interface Post {
  id: string;
  authorId: string;
  authorName: string;
  content: string;
  language: string;
  translation?: string;
  imageUri?: string;
  likes: string[];
  comments: Comment[];
  createdAt: string;
}

export interface Friend {
  id: string;
  name: string;
  email: string;
  score: number;
}

export interface TierProgress {
  unlockedTier: number;
  bestScores: number[];
}

export interface AppContextType {
  user: User | null;
  setUser: (user: User | null) => void;
  posts: Post[];
  setPosts: React.Dispatch<React.SetStateAction<Post[]>>;
  friends: Friend[];
  setFriends: React.Dispatch<React.SetStateAction<Friend[]>>;
  totalScore: number;
  addScore: (points: number) => void;
  logout: () => void;
  isLoading: boolean;
  tierProgress: Record<string, TierProgress>;
  saveTierProgress: (langCode: string, tierIdx: number, score: number, passed: boolean) => void;
  addComment: (postId: string, comment: Omit<Comment, "id" | "createdAt">) => Promise<void>;
  toggleLike: (postId: string) => Promise<void>;
  createPost: (post: Omit<Post, "id" | "createdAt" | "likes" | "comments">) => Promise<void>;
  refreshPosts: () => Promise<void>;
  signup: (name: string, email: string) => Promise<{ success: boolean; user?: User; error?: string }>;
  login: (email: string) => Promise<{ success: boolean; user?: User }>;
  updateUserProfile: (updates: { avatar?: string; name?: string; totalScore?: number }) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const STORAGE_KEYS = {
  USER: "@sankofa_user",
  SCORE: "@sankofa_score",
  TIER_PROGRESS: "@sankofa_tier_progress",
  AVATAR: "@sankofa_avatar",
};

// ─── URL du serveur Replit (backend) ─────────────────────────────────────────
// ⚠️ Remplacez par l'URL de votre serveur backend (celui qui tourne avec node server.js)
const API_BASE = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
  : (process.env.EXPO_PUBLIC_API_URL || "");

// ─── Fonction fetch avec timeout pour éviter les blocages ─────────────────────
async function fetchWithTimeout(url: string, options: RequestInit = {}, timeout = 10000) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    clearTimeout(timeoutId);
    return response;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

async function apiGet(path: string) {
  const res = await fetchWithTimeout(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`GET ${path} failed: ${res.status}`);
  return res.json();
}

async function apiPost(path: string, data: any) {
  const res = await fetchWithTimeout(`${API_BASE}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`POST ${path} failed: ${res.status}`);
  return res.json();
}

async function apiPatch(path: string, data: any) {
  const res = await fetchWithTimeout(`${API_BASE}${path}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`PATCH ${path} failed: ${res.status}`);
  return res.json();
}

// ─── Posts par défaut (20 exemples culturels) ─────────────────────────────────
const DEFAULT_POSTS = [
  {
    id: "seed_1",
    authorId: "system",
    authorName: "Amina Diallo",
    content: "🇸🇳 'Sankofa' - Retourner chercher ce qu'on a oublié pour mieux avancer.",
    language: "fr",
    translation: "Go back to fetch what you forgot to move forward.",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 7 * 24 * 3600_000).toISOString(),
  },
  {
    id: "seed_2",
    authorId: "system",
    authorName: "Kwame Asante",
    content: "🇬🇭 'Akwaaba' signifie 'Bienvenue' en Twi. Au Ghana, l'hospitalité est sacrée !",
    language: "fr",
    translation: "'Akwaaba' means 'Welcome' in Twi. In Ghana, hospitality is sacred!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 6 * 24 * 3600_000).toISOString(),
  },
  {
    id: "seed_3",
    authorId: "system",
    authorName: "Zuri Okonkwo",
    content: "🇳🇬 'Oya' en Yoruba - 'Allez, c'est parti !' Une expression pleine d'énergie !",
    language: "fr",
    translation: "'Oya' in Yoruba - 'Let's go!' An energetic expression!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 5 * 24 * 3600_000).toISOString(),
  },
  {
    id: "seed_4",
    authorId: "system",
    authorName: "Juma Mwangi",
    content: "🇰🇪 'Hakuna Matata' - 'Il n'y a pas de souci'. Une philosophie de vie positive.",
    language: "fr",
    translation: "'Hakuna Matata' - 'No worries'. A positive life philosophy.",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 4 * 24 * 3600_000).toISOString(),
  },
  {
    id: "seed_5",
    authorId: "system",
    authorName: "Fatima Benali",
    content: "🇲🇦 'Saha' - On dit 'Saha' pour souhaiter santé et joie, ou 'Bon appétit' !",
    language: "fr",
    translation: "'Saha' - A word to wish health, joy, or 'Enjoy your meal!'",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 3 * 24 * 3600_000).toISOString(),
  },
  {
    id: "seed_6",
    authorId: "system",
    authorName: "Thabo Nkosi",
    content: "🇿🇦 'Ubuntu' - 'Je suis parce que nous sommes'. L'humanité partagée.",
    language: "fr",
    translation: "'Ubuntu' - 'I am because we are'. Shared humanity.",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 2 * 24 * 3600_000).toISOString(),
  },
  {
    id: "seed_7",
    authorId: "system",
    authorName: "Yara Mansour",
    content: "🇪🇬 'Yalla' - 'Allons-y !', 'Vite !', 'Dépêche-toi !' Un mot magique égyptien.",
    language: "fr",
    translation: "'Yalla' - 'Let's go!', 'Hurry up!' A magic Egyptian word.",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 1 * 24 * 3600_000).toISOString(),
  },
  {
    id: "seed_8",
    authorId: "system",
    authorName: "Idriss Mahamat",
    content: "🇹🇩 'Salam Alaikum' - 'Paix sur vous'. Une salutation universelle.",
    language: "fr",
    translation: "'Salam Alaikum' - 'Peace be upon you'. A universal greeting.",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 20 * 3600_000).toISOString(),
  },
  {
    id: "seed_9",
    authorId: "system",
    authorName: "Amina Diallo",
    content: "🇸🇳 'Teranga' - L'art de l'hospitalité sénégalaise. Un mode de vie !",
    language: "fr",
    translation: "'Teranga' - The Senegalese art of hospitality. A way of life!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 18 * 3600_000).toISOString(),
  },
  {
    id: "seed_10",
    authorId: "system",
    authorName: "Kwame Asante",
    content: "🇬🇭 'Kente' - Ce tissu traditionnel ghanéen raconte des histoires. Chaque motif a une signification !",
    language: "fr",
    translation: "'Kente' - This traditional Ghanaian fabric tells stories. Each pattern has a meaning!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 16 * 3600_000).toISOString(),
  },
  {
    id: "seed_11",
    authorId: "system",
    authorName: "Zuri Okonkwo",
    content: "🇳🇬 'Naija' - Le surnom affectueux du Nigeria. 'No wahala' ! 🇳🇬💚",
    language: "fr",
    translation: "'Naija' - The affectionate nickname for Nigeria. 'No wahala'!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 14 * 3600_000).toISOString(),
  },
  {
    id: "seed_12",
    authorId: "system",
    authorName: "Juma Mwangi",
    content: "🇰🇪 'Pole Pole' - Lentement, doucement... Tout vient à point à qui sait attendre.",
    language: "fr",
    translation: "'Pole Pole' - Slowly, gently... Good things come to those who wait.",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 12 * 3600_000).toISOString(),
  },
  {
    id: "seed_13",
    authorId: "system",
    authorName: "Fatima Benali",
    content: "🇲🇦 'Beslama' - 'Au revoir' en darija marocain, en espérant se revoir en paix.",
    language: "fr",
    translation: "'Beslama' - 'Goodbye' in Moroccan Arabic.",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 10 * 3600_000).toISOString(),
  },
  {
    id: "seed_14",
    authorId: "system",
    authorName: "Thabo Nkosi",
    content: "🇿🇦 'Shap shap' - 'Ça roule !', 'Tout va bien !' Une expression sud-africaine.",
    language: "fr",
    translation: "'Shap shap' - 'All good!', 'Everything is fine!'",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 8 * 3600_000).toISOString(),
  },
  {
    id: "seed_15",
    authorId: "system",
    authorName: "Yara Mansour",
    content: "🇪🇬 'Habibi/Habibti' - 'Mon cher/Ma chère'. Un mot d'affection très utilisé !",
    language: "fr",
    translation: "'Habibi/Habibti' - 'My dear'. A very common word of endearment!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 6 * 3600_000).toISOString(),
  },
  {
    id: "seed_16",
    authorId: "system",
    authorName: "Idriss Mahamat",
    content: "🎶 La musique tchadienne est riche ! Découvrez le 'Soukous' et la 'Sara' 🎶",
    language: "fr",
    translation: "Chadian music is rich! Discover 'Soukous' and 'Sara' 🎶",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 5 * 3600_000).toISOString(),
  },
  {
    id: "seed_17",
    authorId: "system",
    authorName: "Amina Diallo",
    content: "🎶 L'Afrobeat de Fela Kuti au Mbalax sénégalais, la musique africaine voyage !",
    language: "fr",
    translation: "From Fela Kuti's Afrobeat to Senegalese Mbalax, African music travels!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 4 * 3600_000).toISOString(),
  },
  {
    id: "seed_18",
    authorId: "system",
    authorName: "Kwame Asante",
    content: "🍲 Jollof Rice - Le grand débat ! Ghana ou Nigeria ? À vous de juger !",
    language: "fr",
    translation: "Jollof Rice - The great debate! Ghana or Nigeria? You decide!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 3 * 3600_000).toISOString(),
  },
  {
    id: "seed_19",
    authorId: "system",
    authorName: "Juma Mwangi",
    content: "🦁 'Safari' vient du swahili et signifie 'voyage'. Chaque jour est une aventure !",
    language: "fr",
    translation: "'Safari' comes from Swahili and means 'journey'. Every day is an adventure!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 2 * 3600_000).toISOString(),
  },
  {
    id: "seed_20",
    authorId: "system",
    authorName: "Fatima Benali",
    content: "🌍 L'Afrique compte plus de 2000 langues ! Quelle richesse culturelle incroyable !",
    language: "fr",
    translation: "Africa has over 2000 languages! What incredible cultural richness!",
    likes: [],
    comments: [],
    createdAt: new Date(Date.now() - 1 * 3600_000).toISOString(),
  },
];

function defaultTierProgress(): TierProgress {
  return { unlockedTier: 0, bestScores: [0, 0, 0] };
}

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [user, setUserState] = useState<User | null>(null);
  const [posts, setPosts] = useState<Post[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [totalScore, setTotalScore] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [tierProgress, setTierProgress] = useState<Record<string, TierProgress>>({});
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const userRef = useRef<User | null>(null);

  useEffect(() => {
    loadLocalData();
    initDefaultPosts();
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, []);

  useEffect(() => {
    refreshPosts();
    pollRef.current = setInterval(refreshPosts, 10000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, []);

  useEffect(() => { userRef.current = user; }, [user]);

  async function loadLocalData() {
    try {
      const [userData, scoreData, tierData, avatarData] = await Promise.all([
        AsyncStorage.getItem(STORAGE_KEYS.USER),
        AsyncStorage.getItem(STORAGE_KEYS.SCORE),
        AsyncStorage.getItem(STORAGE_KEYS.TIER_PROGRESS),
        AsyncStorage.getItem(STORAGE_KEYS.AVATAR),
      ]);
      if (userData) {
        const u = JSON.parse(userData) as User;
        if (avatarData && !u.avatar) {
          u.avatar = avatarData;
        }
        setUserState(u);
        userRef.current = u;
      }
      if (scoreData) setTotalScore(parseInt(scoreData, 10));
      if (tierData) setTierProgress(JSON.parse(tierData));
    } catch (e) {
      console.error("loadLocalData error:", e);
    } finally {
      setIsLoading(false);
    }
  }

  async function initDefaultPosts() {
    try {
      const existingPosts = await apiGet("/api/posts");
      const hasDefaultPosts = existingPosts.some((p: any) => p.id?.startsWith("seed_"));
      if (!hasDefaultPosts) {
        console.log("📝 Ajout des 20 posts par défaut...");
        for (const post of DEFAULT_POSTS) {
          await apiPost("/api/posts", post);
        }
        console.log("✅ 20 posts par défaut ajoutés !");
        await refreshPosts();
      } else {
        console.log("✅ Les posts par défaut sont déjà présents");
      }
    } catch (e: any) {
      console.warn("⚠️ Impossible de contacter le serveur API:", e?.message);
    }
  }

  async function refreshPosts() {
    try {
      const data = await apiGet("/api/posts");
      if (Array.isArray(data)) {
        setPosts(data.sort((a: Post, b: Post) =>
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        ));
      }
    } catch (e) {
      console.warn("refreshPosts error:", e);
    }
  }

  async function createPost(postData: Omit<Post, "id" | "createdAt" | "likes" | "comments">) {
    const u = userRef.current;
    if (!u) return;
    try {
      await apiPost("/api/posts", {
        authorId: u.id,
        authorName: u.name,
        content: postData.content,
        language: postData.language,
        translation: postData.translation || null,
        imageUri: postData.imageUri || null,
        likes: [],
        comments: [],
      });
      await refreshPosts();
    } catch (e) {
      console.error("createPost error:", e);
    }
  }

  async function toggleLike(postId: string) {
    const u = userRef.current;
    if (!u) return;

    setPosts(prev => prev.map(p => {
      if (p.id !== postId) return p;
      const isLiked = p.likes.includes(u.id);
      return {
        ...p,
        likes: isLiked ? p.likes.filter(id => id !== u.id) : [...p.likes, u.id],
      };
    }));

    try {
      const current = posts.find(p => p.id === postId);
      if (!current) return;
      const isLiked = current.likes.includes(u.id);
      const newLikes = isLiked
        ? current.likes.filter(id => id !== u.id)
        : [...current.likes, u.id];
      await apiPatch(`/api/posts/${postId}`, { likes: newLikes });
    } catch (e) {
      console.error("toggleLike error:", e);
      await refreshPosts();
    }
  }

  async function addComment(postId: string, comment: Omit<Comment, "id" | "createdAt">) {
    const u = userRef.current;
    if (!u) return;
    const newComment: Comment = {
      id: `c_${Date.now()}_${Math.random().toString(36).slice(2)}`,
      authorId: comment.authorId,
      authorName: comment.authorName,
      content: comment.content,
      createdAt: new Date().toISOString(),
    };

    setPosts(prev => prev.map(p => {
      if (p.id !== postId) return p;
      return { ...p, comments: [...(p.comments ?? []), newComment] };
    }));

    try {
      const current = posts.find(p => p.id === postId);
      if (!current) return;
      const updatedComments = [...(current.comments ?? []), newComment];
      await apiPatch(`/api/posts/${postId}`, { comments: updatedComments });
    } catch (e) {
      console.error("addComment error:", e);
      await refreshPosts();
    }
  }

  // ─── Utilisateurs ─────────────────────────────────────────────────────────
  async function signup(name: string, email: string): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const response = await fetchWithTimeout(`${API_BASE}/api/users`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email }),
      });
      const data = await response.json();
      if (data.success && data.user) {
        setUserState(data.user);
        userRef.current = data.user;
        await AsyncStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(data.user));
        return { success: true, user: data.user };
      }
      return { success: false, error: data.error || "Inscription échouée" };
    } catch (e: any) {
      return { success: false, error: "Connexion impossible. Vérifiez votre réseau." };
    }
  }

  async function login(email: string): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const response = await fetchWithTimeout(`${API_BASE}/api/users`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      const data = await response.json();
      if (data.success && data.user) {
        const savedAvatar = await AsyncStorage.getItem(STORAGE_KEYS.AVATAR);
        const userWithAvatar = savedAvatar ? { ...data.user, avatar: savedAvatar } : data.user;
        setUserState(userWithAvatar);
        userRef.current = userWithAvatar;
        await AsyncStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(userWithAvatar));
        return { success: true, user: userWithAvatar };
      }
      return { success: false, error: data.error || "Email non trouvé" };
    } catch (e) {
      return { success: false, error: "Connexion impossible. Vérifiez votre réseau." };
    }
  }

  async function updateUserProfile(updates: { avatar?: string; name?: string; totalScore?: number }) {
    const u = userRef.current;
    if (!u) return;
    const updated = { ...u, ...updates };
    setUserState(updated);
    userRef.current = updated;
    await AsyncStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updated));
    if (updates.avatar) {
      await AsyncStorage.setItem(STORAGE_KEYS.AVATAR, updates.avatar);
    }
    try {
      await apiPatch(`/api/users/${u.id}`, updates);
    } catch (_) {}
  }

  function setUser(u: User | null) {
    setUserState(u);
    userRef.current = u;
    if (u) {
      AsyncStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(u));
      if (u.avatar) {
        AsyncStorage.setItem(STORAGE_KEYS.AVATAR, u.avatar);
      }
    } else {
      AsyncStorage.removeItem(STORAGE_KEYS.USER);
    }
  }

  function addScore(points: number) {
    setTotalScore(prev => {
      const next = prev + points;
      AsyncStorage.setItem(STORAGE_KEYS.SCORE, String(next));
      const u = userRef.current;
      if (u) {
        apiPatch(`/api/users/${u.id}`, { totalScore: next }).catch(() => {});
      }
      return next;
    });
  }

  function saveTierProgress(langCode: string, tierIdx: number, score: number, passed: boolean) {
    setTierProgress(prev => {
      const current = prev[langCode] ?? defaultTierProgress();
      const newBestScores = [...current.bestScores];
      if (!newBestScores[tierIdx] || score > newBestScores[tierIdx]) newBestScores[tierIdx] = score;
      const newUnlocked = passed && tierIdx >= current.unlockedTier
        ? Math.min(tierIdx + 1, 2) : current.unlockedTier;
      const updated: TierProgress = { unlockedTier: newUnlocked, bestScores: newBestScores };
      const next = { ...prev, [langCode]: updated };
      AsyncStorage.setItem(STORAGE_KEYS.TIER_PROGRESS, JSON.stringify(next));
      const u = userRef.current;
      if (u) {
        apiPatch(`/api/users/${u.id}`, { tierProgress: next }).catch(() => {});
      }
      return next;
    });
  }

  function logout() {
    setUserState(null);
    userRef.current = null;
    AsyncStorage.removeItem(STORAGE_KEYS.USER);
    AsyncStorage.removeItem(STORAGE_KEYS.AVATAR);
  }

  return (
    <AppContext.Provider
      value={{
        user, setUser, posts, setPosts, friends, setFriends,  // ← setFriends directement (correction)
        totalScore, addScore, logout, isLoading,
        tierProgress, saveTierProgress,
        addComment, toggleLike, createPost, refreshPosts,
        signup, login, updateUserProfile,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}