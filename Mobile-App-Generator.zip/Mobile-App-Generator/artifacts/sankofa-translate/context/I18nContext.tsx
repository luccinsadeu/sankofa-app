import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

export type AppLang = "fr" | "en";

const STORAGE_KEY = "@sankofa_ui_lang";

const translations = {
  fr: {
    home: "Accueil",
    translate: "Traduire",
    games: "Quiz",
    social: "Social",
    profile: "Profil",
    messages: "Messages",
    welcome: "Bienvenue",
    good_morning: "Bonjour",
    good_afternoon: "Bon après-midi",
    good_evening: "Bonsoir",
    translate_now: "Traduire maintenant",
    score: "Score",
    friends: "Amis",
    languages: "Langues",
    quick_actions: "Actions rapides",
    recent_posts: "Publications récentes",
    see_all: "Voir tout",
    translate_title: "Traducteur",
    translate_placeholder: "Entrez votre texte...",
    translate_btn: "Traduire",
    translating: "Traduction...",
    copy: "Copier",
    copied: "Copié !",
    quiz_title: "Quiz Africain",
    total_score: "Score total",
    choose_lang: "Choisissez une langue",
    questions: "questions",
    replay: "Rejouer",
    change_lang: "Changer de langue",
    community: "Communauté",
    posts: "Publications",
    share_placeholder: "Partagez une phrase africaine...",
    publish: "Publier",
    cancel: "Annuler",
    settings: "Paramètres",
    groq_api: "API Groq",
    saved_key: "Clé configurée",
    no_key: "Aucune clé configurée",
    logout: "Se déconnecter",
    supported_langs: "Langues supportées",
    profile_title: "Mon Profil",
    app_language: "Langue de l'interface",
    translation_engine: "Moteur de traduction",
    free_translation: "Gratuit (MyMemory)",
    premium_translation: "Avancé (Groq AI)",
    member_since: "Membre depuis",
    edit_profile: "Modifier le profil",
    total_translations: "Traductions",
    quiz_completed: "Quiz terminés",
    excellent: "Excellent !",
    well_done: "Bien joué !",
    keep_learning: "Continue d'apprendre !",
    correct_answers: "bonnes réponses",
    points_earned: "points gagnés",
    enter_text: "Entrez du texte à traduire",
    translation_error: "Erreur de traduction",
    language_saved: "Langue enregistrée",
    haptics: "Vibrations",
    haptics_desc: "Retour haptique lors des interactions",
    notifications: "Notifications",
    notifications_desc: "Rappels quotidiens pour pratiquer",
    notif_time: "Heure du rappel",
    notif_freq: "Fréquence",
    daily: "Quotidien",
    weekly: "Hebdomadaire",
    save: "Enregistrer",
    comments: "Commentaires",
    add_comment: "Ajouter un commentaire...",
    post_comment: "Publier",
  },
  en: {
    home: "Home",
    translate: "Translate",
    games: "Quiz",
    social: "Social",
    profile: "Profile",
    messages: "Messages",
    welcome: "Welcome",
    good_morning: "Good morning",
    good_afternoon: "Good afternoon",
    good_evening: "Good evening",
    translate_now: "Translate now",
    score: "Score",
    friends: "Friends",
    languages: "Languages",
    quick_actions: "Quick actions",
    recent_posts: "Recent posts",
    see_all: "See all",
    translate_title: "Translator",
    translate_placeholder: "Enter your text...",
    translate_btn: "Translate",
    translating: "Translating...",
    copy: "Copy",
    copied: "Copied!",
    quiz_title: "African Quiz",
    total_score: "Total score",
    choose_lang: "Choose a language",
    questions: "questions",
    replay: "Play again",
    change_lang: "Change language",
    community: "Community",
    posts: "Posts",
    share_placeholder: "Share an African phrase...",
    publish: "Publish",
    cancel: "Cancel",
    settings: "Settings",
    groq_api: "Groq API",
    saved_key: "Key configured",
    no_key: "No key configured",
    logout: "Log out",
    supported_langs: "Supported languages",
    profile_title: "My Profile",
    app_language: "Interface language",
    translation_engine: "Translation engine",
    free_translation: "Free (MyMemory)",
    premium_translation: "Advanced (Groq AI)",
    member_since: "Member since",
    edit_profile: "Edit profile",
    total_translations: "Translations",
    quiz_completed: "Quiz completed",
    excellent: "Excellent!",
    well_done: "Well done!",
    keep_learning: "Keep learning!",
    correct_answers: "correct answers",
    points_earned: "points earned",
    enter_text: "Enter text to translate",
    translation_error: "Translation error",
    language_saved: "Language saved",
    haptics: "Haptics",
    haptics_desc: "Vibration feedback during interactions",
    notifications: "Notifications",
    notifications_desc: "Daily reminders to practice",
    notif_time: "Reminder time",
    notif_freq: "Frequency",
    daily: "Daily",
    weekly: "Weekly",
    save: "Save",
    comments: "Comments",
    add_comment: "Add a comment...",
    post_comment: "Post",
  },
};

export type TranslationKey = keyof typeof translations.fr;

interface I18nContextType {
  lang: AppLang;
  setLang: (l: AppLang) => void;
  t: (key: TranslationKey) => string;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<AppLang>("fr");

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(v => {
      if (v === "en" || v === "fr") setLangState(v);
    });
  }, []);

  function setLang(l: AppLang) {
    setLangState(l);
    AsyncStorage.setItem(STORAGE_KEY, l);
  }

  function t(key: TranslationKey): string {
    return translations[lang][key] ?? translations.fr[key] ?? key;
  }

  return (
    <I18nContext.Provider value={{ lang, setLang, t }}>
      {children}
    </I18nContext.Provider>
  );
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be inside I18nProvider");
  return ctx;
}
