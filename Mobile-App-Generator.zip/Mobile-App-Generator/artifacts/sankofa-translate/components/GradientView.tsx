import React from "react";
import { StyleProp, View, ViewStyle } from "react-native";

interface GradientViewProps {
  colors: readonly string[] | string[];
  style?: StyleProp<ViewStyle>;
  children?: React.ReactNode;
  start?: { x: number; y: number };
  end?: { x: number; y: number };
}

export function GradientView({ colors, style, children }: GradientViewProps) {
  return (
    <View style={[{ backgroundColor: colors[0] as string }, style]}>
      {children}
    </View>
  );
}
