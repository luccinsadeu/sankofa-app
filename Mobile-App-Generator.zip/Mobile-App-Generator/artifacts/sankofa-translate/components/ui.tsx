import { Feather } from "@expo/vector-icons";
import { GradientView } from "@/components/GradientView";
import React, { useEffect, useRef } from "react";
import {
  ActivityIndicator,
  Animated,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type PressableProps,
  type TextInputProps,
  type ViewStyle,
} from "react-native";
import { useColors } from "@/hooks/useColors";

export function GradientButton({
  title,
  onPress,
  loading,
  disabled,
  style,
  variant = "primary",
}: {
  title: string;
  onPress: () => void;
  loading?: boolean;
  disabled?: boolean;
  style?: ViewStyle;
  variant?: "primary" | "secondary" | "gold";
}) {
  const colors = useColors();
  const scale = useRef(new Animated.Value(1)).current;

  function handlePressIn() {
    Animated.spring(scale, { toValue: 0.96, useNativeDriver: true, speed: 20 }).start();
  }
  function handlePressOut() {
    Animated.spring(scale, { toValue: 1, useNativeDriver: true, speed: 20 }).start();
  }

  const gradientColors: [string, string] =
    variant === "gold"
      ? [colors.gold, "#A0700A"]
      : variant === "secondary"
      ? [colors.muted, colors.border]
      : [colors.midGreen, colors.deepGreen];

  return (
    <Animated.View style={[{ transform: [{ scale }] }, style]}>
      <Pressable
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        disabled={disabled || loading}
      >
        <GradientView
          colors={gradientColors}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[styles.btn, (disabled || loading) && styles.btnDisabled]}
        >
          {loading ? (
            <ActivityIndicator color="#fff" size="small" />
          ) : (
            <Text
              style={[
                styles.btnText,
                variant === "secondary" && { color: colors.foreground },
              ]}
            >
              {title}
            </Text>
          )}
        </GradientView>
      </Pressable>
    </Animated.View>
  );
}

export function Card({
  children,
  style,
}: {
  children: React.ReactNode;
  style?: ViewStyle;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function DarkInput({
  style,
  ...props
}: TextInputProps & { style?: ViewStyle }) {
  const colors = useColors();
  return (
    <TextInput
      style={[
        styles.input,
        {
          backgroundColor: colors.muted,
          borderColor: colors.border,
          color: colors.foreground,
        },
        style,
      ]}
      placeholderTextColor={colors.mutedForeground}
      {...props}
    />
  );
}

export function Toast({
  message,
  visible,
  type = "success",
}: {
  message: string;
  visible: boolean;
  type?: "success" | "error" | "info";
}) {
  const colors = useColors();
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(opacity, { toValue: 1, duration: 200, useNativeDriver: true }),
        Animated.spring(translateY, { toValue: 0, useNativeDriver: true }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(opacity, { toValue: 0, duration: 200, useNativeDriver: true }),
        Animated.timing(translateY, { toValue: 20, duration: 200, useNativeDriver: true }),
      ]).start();
    }
  }, [visible]);

  const bg =
    type === "error" ? colors.destructive : type === "info" ? colors.accent : colors.deepGreen;

  return (
    <Animated.View
      style={[
        styles.toast,
        { backgroundColor: bg, opacity, transform: [{ translateY }] },
      ]}
    >
      <Feather
        name={type === "error" ? "x-circle" : type === "info" ? "info" : "check-circle"}
        color="#fff"
        size={16}
      />
      <Text style={styles.toastText}>{message}</Text>
    </Animated.View>
  );
}

export function FloatingOrbs({ count = 6 }: { count?: number }) {
  const colors = useColors();
  const anims = useRef(
    Array.from({ length: count }, () => ({
      x: new Animated.Value(Math.random() * 300),
      y: new Animated.Value(Math.random() * 600),
      opacity: new Animated.Value(0.05 + Math.random() * 0.12),
      scale: new Animated.Value(0.5 + Math.random()),
    }))
  ).current;

  useEffect(() => {
    anims.forEach((orb, i) => {
      const duration = 6000 + i * 1200;
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(orb.y, {
            toValue: (orb.y as any)._value - 40 - Math.random() * 60,
            duration: duration / 2,
            useNativeDriver: true,
          }),
          Animated.timing(orb.y, {
            toValue: (orb.y as any)._value + 40 + Math.random() * 60,
            duration: duration / 2,
            useNativeDriver: true,
          }),
        ])
      );
      setTimeout(() => loop.start(), i * 400);
    });
  }, []);

  return (
    <View style={[StyleSheet.absoluteFill, { pointerEvents: "none" }]}>
      {anims.map((orb, i) => (
        <Animated.View
          key={i}
          style={{
            position: "absolute",
            width: 60 + i * 25,
            height: 60 + i * 25,
            borderRadius: 100,
            backgroundColor: i % 2 === 0 ? colors.gold : colors.deepGreen,
            opacity: orb.opacity,
            left: (i * 53) % 350,
            top: 50 + (i * 97) % 500,
            transform: [{ scale: orb.scale }],
          }}
        />
      ))}
    </View>
  );
}

export function ScoreBadge({ score }: { score: number }) {
  const colors = useColors();
  return (
    <View style={[styles.scoreBadge, { backgroundColor: colors.gold }]}>
      <Feather name="star" size={12} color="#fff" />
      <Text style={styles.scoreText}>{score}</Text>
    </View>
  );
}

export function LanguageFlag({ code }: { code: string }) {
  const flags: Record<string, string> = {
    sw: "🇹🇿",
    ln: "🇨🇩",
    yo: "🇳🇬",
    ha: "🇳🇬",
    zu: "🇿🇦",
    ew: "🇨🇲",
    du: "🇨🇲",
    gh: "🇨🇲",
    ff: "🇬🇳",
    bu: "🇨🇲",
    gb: "🇨🇫",
    fr: "🇫🇷",
    en: "🇬🇧",
  };
  return <Text style={{ fontSize: 20 }}>{flags[code] || "🌍"}</Text>;
}

const styles = StyleSheet.create({
  btn: {
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row",
    gap: 8,
    minHeight: 52,
  },
  btnDisabled: { opacity: 0.5 },
  btnText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 16,
    letterSpacing: 0.3,
  },
  card: {
    borderRadius: 16,
    borderWidth: 1,
    padding: 16,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  input: {
    borderRadius: 12,
    borderWidth: 1.5,
    paddingHorizontal: 16,
    paddingVertical: 12,
    fontSize: 16,
    minHeight: 50,
  },
  toast: {
    position: "absolute",
    bottom: 100,
    alignSelf: "center",
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 100,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
    zIndex: 9999,
  },
  toastText: {
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
  },
  scoreBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 100,
  },
  scoreText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 13,
  },
});
