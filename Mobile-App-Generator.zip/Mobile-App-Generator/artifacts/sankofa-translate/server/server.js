/**
 * Serveur tout-en-un pour Sankofa Translate.
 * Stockage : utilisateurs dans une clé "users", posts dans des clés individuelles "post:ID"
 * 5 langues supportées : Swahili, Yoruba, Haoussa, Zulu, Lingala
 */

const http = require("http");
const fs = require("fs");
const path = require("path");
const Database = require("@replit/database");

const db = new Database();

const STATIC_ROOT = path.resolve(__dirname, "..", "static-build");
const TEMPLATE_PATH = path.resolve(__dirname, "templates", "landing-page.html");
const basePath = (process.env.BASE_PATH || "/").replace(/\/+$/, "");

const MIME_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "application/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".otf": "font/otf",
  ".map": "application/json",
};

// ─── 5 Langues supportées ─────────────────────────────────────────────────────
const SUPPORTED_LANGUAGES = [
  { id: "swahili", name: "Swahili", flag: "🇹🇿", region: "Afrique de l'Est", color: "#4CAF50" },
  { id: "yoruba", name: "Yoruba", flag: "🇳🇬", region: "Nigeria", color: "#E8B647" },
  { id: "hausa", name: "Haoussa", flag: "🇳🇬", region: "Nigeria/Niger", color: "#FF9800" },
  { id: "zulu", name: "Zulu", flag: "🇿🇦", region: "Afrique du Sud", color: "#2196F3" },
  { id: "lingala", name: "Lingala", flag: "🇨🇩", region: "RDC/Congo", color: "#9C27B0" },
];

// ─── DB Helpers ───────────────────────────────────────────────────────────────

function unwrapDatabaseResult(result, operation) {
  if (!result || result.ok !== true) {
    const reason = result?.error?.message || "Unknown database error";
    throw new Error(`Replit Database ${operation} failed: ${reason}`);
  }
  return result.value;
}

async function getDatabaseValue(key) {
  return unwrapDatabaseResult(await db.get(key), `get(${key})`);
}

async function setDatabaseValue(key, value) {
  unwrapDatabaseResult(await db.set(key, value), `set(${key})`);
}

async function listDatabaseKeys(prefix) {
  return unwrapDatabaseResult(await db.list(prefix), `list(${prefix})`);
}

async function deleteDatabaseValue(key) {
  unwrapDatabaseResult(await db.delete(key), `delete(${key})`);
}

// USERS — stockés dans une seule clé "users"
async function getAllUsers() {
  try {
    const usersData = await getDatabaseValue("users");
    return usersData ? JSON.parse(usersData) : [];
  } catch (error) {
    console.error("getAllUsers error:", error);
    return [];
  }
}

async function saveAllUsers(users) {
  await setDatabaseValue("users", JSON.stringify(users));
}

async function getUserByEmail(email) {
  const users = await getAllUsers();
  return users.find(u => u.email === email) || null;
}

async function getUserById(id) {
  const users = await getAllUsers();
  return users.find(u => u.id === id) || null;
}

async function createUser(userData) {
  const users = await getAllUsers();
  const newUser = {
    id: Date.now().toString(),
    name: userData.name,
    email: userData.email,
    avatar: userData.avatar || "🐘",
    language: userData.language || "swahili",
    dailyGoal: userData.dailyGoal || 10,
    totalScore: 0,
    tierProgress: {},
    joinedAt: new Date().toISOString(),
  };
  users.push(newUser);
  await saveAllUsers(users);
  return newUser;
}

async function updateUser(userId, updates) {
  const users = await getAllUsers();
  const index = users.findIndex(u => u.id === userId);
  if (index === -1) return null;
  users[index] = { ...users[index], ...updates };
  await saveAllUsers(users);
  return users[index];
}

// POSTS — chaque post dans sa propre clé "post:ID"
async function getAllPosts() {
  try {
    const keys = await listDatabaseKeys("post:");
    if (!keys || keys.length === 0) return [];
    const values = await Promise.all(keys.map(k => getDatabaseValue(k)));
    const posts = values
      .map(v => typeof v === "string" ? JSON.parse(v) : v)
      .filter(Boolean);
    return posts.sort((a, b) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  } catch (e) {
    console.error("getAllPosts error:", e);
    return [];
  }
}

async function getPost(id) {
  try {
    const val = await getDatabaseValue(`post:${id}`);
    if (!val) return null;
    return typeof val === "string" ? JSON.parse(val) : val;
  } catch (error) {
    console.error("getPost error:", error);
    return null;
  }
}

async function savePost(post) {
  await setDatabaseValue(`post:${post.id}`, JSON.stringify(post));
}

async function deletePost(id) {
  await deleteDatabaseValue(`post:${id}`);
}

// MESSAGES — conversations
async function getConversation(userId1, userId2) {
  try {
    const keys1 = await listDatabaseKeys(`msg:${userId1}:${userId2}:`);
    const keys2 = await listDatabaseKeys(`msg:${userId2}:${userId1}:`);
    const allKeys = [...new Set([...keys1, ...keys2])];
    if (allKeys.length === 0) return [];
    const values = await Promise.all(allKeys.map(k => getDatabaseValue(k)));
    return values
      .map(v => typeof v === "string" ? JSON.parse(v) : v)
      .filter(Boolean)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  } catch (error) {
    console.error("getConversation error:", error);
    return [];
  }
}

async function saveMessage(msg) {
  await setDatabaseValue(
    `msg:${msg.fromId}:${msg.toId}:${msg.id}`,
    JSON.stringify(msg),
  );
}

// ─── Posts par défaut (pour initialiser la base) ─────────────────────────────
const DEFAULT_POSTS = [
  { id: "seed_1", authorId: "system", authorName: "Sankofa", content: "🇹🇿 'Hakuna Matata' signifie 'Il n'y a pas de souci' en Swahili.", language: "swahili", translation: "'No worries' in Swahili.", likes: [], comments: [], createdAt: new Date(Date.now() - 7 * 24 * 3600_000).toISOString() },
  { id: "seed_2", authorId: "system", authorName: "Sankofa", content: "🇳🇬 'Bawo ni' signifie 'Comment vas-tu ?' en Yoruba.", language: "yoruba", translation: "'How are you?' in Yoruba.", likes: [], comments: [], createdAt: new Date(Date.now() - 6 * 24 * 3600_000).toISOString() },
  { id: "seed_3", authorId: "system", authorName: "Sankofa", content: "🇳🇬 'Sannu' signifie 'Bonjour' en Haoussa.", language: "hausa", translation: "'Hello' in Hausa.", likes: [], comments: [], createdAt: new Date(Date.now() - 5 * 24 * 3600_000).toISOString() },
  { id: "seed_4", authorId: "system", authorName: "Sankofa", content: "🇿🇦 'Sawubona' signifie 'Bonjour' en Zulu.", language: "zulu", translation: "'Hello' in Zulu.", likes: [], comments: [], createdAt: new Date(Date.now() - 4 * 24 * 3600_000).toISOString() },
  { id: "seed_5", authorId: "system", authorName: "Sankofa", content: "🇨🇩 'Mbote' signifie 'Bonjour' en Lingala.", language: "lingala", translation: "'Hello' in Lingala.", likes: [], comments: [], createdAt: new Date(Date.now() - 3 * 24 * 3600_000).toISOString() },
];

async function initDefaultPosts() {
  const existingPosts = await getAllPosts();
  const hasDefaultPosts = existingPosts.some(p => p.id?.startsWith("seed_"));
  if (!hasDefaultPosts) {
    console.log("📝 Ajout des posts par défaut...");
    for (const post of DEFAULT_POSTS) {
      await savePost(post);
    }
    console.log("✅ 5 posts par défaut ajoutés !");
  }
}

// ─── HTTP Helpers ─────────────────────────────────────────────────────────────
function sendJSON(res, data, status = 200) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
  });
  res.end(JSON.stringify(data));
}

function getBody(req) {
  return new Promise((resolve) => {
    let body = "";
    req.on("data", chunk => body += chunk);
    req.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { resolve({}); }
    });
  });
}

// ─── API Routes ───────────────────────────────────────────────────────────────
async function handleAPI(req, res, url) {
  // CORS preflight
  if (req.method === "OPTIONS") {
    res.writeHead(204, {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type",
    });
    return res.end();
  }

  // ── POSTS ──────────────────────────────────────────────────────────────────

  // GET /api/posts
  if (req.method === "GET" && url === "/api/posts") {
    const posts = await getAllPosts();
    return sendJSON(res, posts);
  }

  // POST /api/posts
  if (req.method === "POST" && url === "/api/posts") {
    const body = await getBody(req);
    const newPost = {
      ...body,
      id: Date.now().toString(),
      likes: body.likes || [],
      comments: body.comments || [],
      createdAt: new Date().toISOString(),
    };
    await savePost(newPost);
    return sendJSON(res, { success: true, post: newPost });
  }

  // PATCH /api/posts/:id
  const patchPost = url.match(/^\/api\/posts\/([^/?]+)$/);
  if (req.method === "PATCH" && patchPost) {
    const postId = patchPost[1];
    const body = await getBody(req);
    const existing = await getPost(postId);
    if (!existing) return sendJSON(res, { success: false, error: "Post non trouvé" }, 404);
    const updated = { ...existing, ...body };
    await savePost(updated);
    return sendJSON(res, { success: true, post: updated });
  }

  // DELETE /api/posts/:id
  const deletePostMatch = url.match(/^\/api\/posts\/([^/?]+)$/);
  if (req.method === "DELETE" && deletePostMatch) {
    const postId = deletePostMatch[1];
    await deletePost(postId);
    return sendJSON(res, { success: true });
  }

  // ── USERS ──────────────────────────────────────────────────────────────────

  // GET /api/users
  if (req.method === "GET" && url === "/api/users") {
    const users = await getAllUsers();
    const safeUsers = users.map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      avatar: u.avatar,
      language: u.language,
      dailyGoal: u.dailyGoal,
      joinedAt: u.joinedAt,
    }));
    return sendJSON(res, safeUsers);
  }

  // GET /api/users/:id
  const getUserMatch = url.match(/^\/api\/users\/([^/?]+)$/);
  if (req.method === "GET" && getUserMatch) {
    const userId = getUserMatch[1];
    const user = await getUserById(userId);
    if (!user) return sendJSON(res, { success: false, error: "Utilisateur non trouvé" }, 404);
    return sendJSON(res, {
      id: user.id,
      name: user.name,
      email: user.email,
      avatar: user.avatar,
      language: user.language,
      dailyGoal: user.dailyGoal,
      totalScore: user.totalScore,
      joinedAt: user.joinedAt,
    });
  }

  // POST /api/users (inscription ou connexion)
  if (req.method === "POST" && url === "/api/users") {
    const body = await getBody(req);

    // Connexion seulement (si email seul)
    if (body.email && !body.name) {
      const user = await getUserByEmail(body.email);
      if (user) {
        return sendJSON(res, { success: true, user: {
          id: user.id, name: user.name, email: user.email,
          avatar: user.avatar, language: user.language,
          dailyGoal: user.dailyGoal, joinedAt: user.joinedAt
        } });
      }
      return sendJSON(res, { success: false, error: "Utilisateur non trouvé" }, 404);
    }

    // Inscription complète
    if (body.name && body.email) {
      const existing = await getUserByEmail(body.email);
      if (existing) {
        return sendJSON(res, { success: true, user: {
          id: existing.id, name: existing.name, email: existing.email,
          avatar: existing.avatar, language: existing.language,
          dailyGoal: existing.dailyGoal, joinedAt: existing.joinedAt
        } });
      }
      const newUser = await createUser(body);
      return sendJSON(res, { success: true, user: {
        id: newUser.id, name: newUser.name, email: newUser.email,
        avatar: newUser.avatar, language: newUser.language,
        dailyGoal: newUser.dailyGoal, joinedAt: newUser.joinedAt
      } });
    }

    return sendJSON(res, { success: false, error: "Données manquantes" }, 400);
  }

  // PATCH /api/users/:id
  const patchUser = url.match(/^\/api\/users\/([^/?]+)$/);
  if (req.method === "PATCH" && patchUser) {
    const userId = patchUser[1];
    const body = await getBody(req);
    const updated = await updateUser(userId, body);
    if (!updated) return sendJSON(res, { success: false, error: "Utilisateur non trouvé" }, 404);
    return sendJSON(res, { success: true, user: updated });
  }

  // ── MESSAGES ───────────────────────────────────────────────────────────────

  // GET /api/messages?userId=xxx&withId=yyy
  if (req.method === "GET" && url.startsWith("/api/messages")) {
    const params = new URLSearchParams(url.split("?")[1] || "");
    const userId = params.get("userId");
    const withId = params.get("withId");
    if (userId && withId) {
      const msgs = await getConversation(userId, withId);
      return sendJSON(res, msgs);
    }
    return sendJSON(res, []);
  }

  // POST /api/messages
  if (req.method === "POST" && url === "/api/messages") {
    const body = await getBody(req);
    const { fromId, toId, text } = body;
    if (!fromId || !toId || !text) {
      return sendJSON(res, { success: false, error: "Données manquantes" }, 400);
    }
    const msg = {
      id: Date.now().toString(),
      fromId, toId, text,
      createdAt: new Date().toISOString(),
    };
    await saveMessage(msg);
    return sendJSON(res, { success: true, message: msg });
  }

  // ── LANGUAGES ──────────────────────────────────────────────────────────────

  // GET /api/languages
  if (req.method === "GET" && url === "/api/languages") {
    return sendJSON(res, SUPPORTED_LANGUAGES);
  }

  return false;
}

// ─── Static file serving ──────────────────────────────────────────────────────
function serveStaticFile(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mime = MIME_TYPES[ext] || "application/octet-stream";
  try {
    const data = fs.readFileSync(filePath);
    res.writeHead(200, { "Content-Type": mime });
    res.end(data);
  } catch {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not Found");
  }
}

// ─── Main server ──────────────────────────────────────────────────────────────
const server = http.createServer(async (req, res) => {
  const rawUrl = req.url || "/";
  const url = rawUrl.split("?")[0];

  if (url.startsWith("/api/")) {
    const urlForApi = url.startsWith("/api/messages") ? rawUrl : url;
    const handled = await handleAPI(req, res, urlForApi);
    if (handled !== false) return;
  }

  if (url === "/" || url === basePath || url === basePath + "/") {
    try {
      const template = fs.readFileSync(TEMPLATE_PATH, "utf-8");
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      return res.end(template);
    } catch {
      res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
      return res.end(`<h1>Sankofa Translate</h1><p>✅ API en cours d'exécution</p><p>📊 <a href="/api/posts">/api/posts</a></p><p>👥 <a href="/api/users">/api/users</a></p><p>🌍 <a href="/api/languages">/api/languages</a></p>`);
    }
  }

  const cleanUrl = url.startsWith(basePath) ? url.slice(basePath.length) : url;
  const filePath = path.join(STATIC_ROOT, cleanUrl);
  if (fs.existsSync(filePath) && fs.statSync(filePath).isFile()) {
    return serveStaticFile(res, filePath);
  }

  res.writeHead(404, { "Content-Type": "text/plain" });
  res.end("Not Found");
});

// Initialisation des posts par défaut
initDefaultPosts().then(() => {
  console.log("✅ Posts par défaut initialisés");
}).catch(err => {
  console.error("Erreur initialisation posts:", err);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`✅ Serveur Sankofa sur http://localhost:${PORT}`);
  console.log(`📊 GET /api/posts`);
  console.log(`👥 POST /api/users`);
  console.log(`🌍 GET /api/languages - ${SUPPORTED_LANGUAGES.length} langues`);
  console.log(`💬 GET /api/messages?userId=xxx&withId=yyy`);
});