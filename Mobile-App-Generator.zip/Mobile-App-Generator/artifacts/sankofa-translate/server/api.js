// services/api.js
const API = 'https://ton-replit-url.repl.co'; // REMPLACE PAR TON URL

export async function getPosts() {
  const res = await fetch(`${API}/api/posts`);
  return res.json();
}

export async function createPost(data) {
  const res = await fetch(`${API}/api/posts`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  return res.json();
}

export async function likePost(postId, userId) {
  const res = await fetch(`${API}/api/posts/${postId}/like`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({userId})
  });
  return res.json();
}

export async function commentPost(postId, data) {
  const res = await fetch(`${API}/api/posts/${postId}/comments`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(data)
  });
  return res.json();
}