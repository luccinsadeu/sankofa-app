import * as Haptics from "expo-haptics";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useEffect, useState } from "react";

const HAPTICS_KEY = "@sankofa_haptics_enabled";

let _globalEnabled = true;

AsyncStorage.getItem(HAPTICS_KEY).then(v => {
  if (v !== null) _globalEnabled = v === "true";
});

export function useHaptics() {
  const [enabled, setEnabled] = useState(_globalEnabled);

  useEffect(() => {
    AsyncStorage.getItem(HAPTICS_KEY).then(v => {
      const val = v === null ? true : v === "true";
      setEnabled(val);
      _globalEnabled = val;
    });
  }, []);

  const toggle = useCallback(async () => {
    const next = !_globalEnabled;
    _globalEnabled = next;
    setEnabled(next);
    await AsyncStorage.setItem(HAPTICS_KEY, String(next));
  }, []);

  const impact = useCallback(
    (style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) => {
      if (_globalEnabled) Haptics.impactAsync(style);
    },
    [],
  );

  const notification = useCallback(
    (type: Haptics.NotificationFeedbackType = Haptics.NotificationFeedbackType.Success) => {
      if (_globalEnabled) Haptics.notificationAsync(type);
    },
    [],
  );

  const selection = useCallback(() => {
    if (_globalEnabled) Haptics.selectionAsync();
  }, []);

  return { enabled, toggle, impact, notification, selection };
}
