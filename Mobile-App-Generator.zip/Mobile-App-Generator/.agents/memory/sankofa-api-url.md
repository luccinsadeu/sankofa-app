---
name: Sankofa API URL pattern
description: How API_BASE is constructed in AppContext.tsx and why /api must not be included in the base
---

## Rule
`API_BASE` must be just the domain (no `/api` suffix) because every path passed to `apiGet/apiPost/apiPatch` already starts with `/api/`.

```typescript
// CORRECT
const API_BASE = process.env.EXPO_PUBLIC_DOMAIN
  ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
  : (process.env.EXPO_PUBLIC_API_URL || "");

apiGet("/api/posts")  // → https://domain.com/api/posts ✓
```

**Why:** Adding `/api` to `API_BASE` gives double-prefix: `/api/api/posts` → 404.

**How to apply:** When changing API_BASE or the .env EXPO_PUBLIC_API_URL, never include `/api` at the end. The .env file at `artifacts/sankofa-translate/.env` stores the base domain only.

## Dev script injection
`EXPO_PUBLIC_DOMAIN=$REPLIT_DEV_DOMAIN` is injected by the Expo dev script and takes priority over `.env` values. `EXPO_PUBLIC_DOMAIN` is just the domain without protocol or path.
