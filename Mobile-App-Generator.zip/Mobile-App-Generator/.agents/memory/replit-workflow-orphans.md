---
name: Replit workflow orphan processes
description: Handling artifact workflows whose old child processes survive restarts and keep ports occupied.
---

When an artifact workflow restart reports `EADDRINUSE`, inspect the process tree and listeners before retrying. In this workspace, multiple old Expo/API workflow process groups survived restarts and continued occupying their ports even while the managed workflow reported failure. When multiple Expo URLs are present, check `X-React-Native-Project-Root` on `/status`; a root-workspace server is not the Sankofa artifact server.

**Why:** Repeated restart attempts did not clean up the previous Expo and API child processes; the duplicate instances caused port conflicts and confusing Expo CLI prompts.

**How to apply:** For Sankofa workflow port conflicts or competing QR codes, confirm the exact listeners, process groups, and project-root response first; stop only stale/unconfigured app processes, verify the intended port, and restart the artifact workflow once.
