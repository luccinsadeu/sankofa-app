---
name: Expo Go native module crashes (Sankofa)
description: Which expo modules crash with "Invariant Violation: View config getter callback must be a function (received undefined)" in Expo Go for this project
---

## Rule
In this project's Expo Go build, the following modules are NOT linked and crash immediately when rendered:

| Module | Import | Replacement |
|--------|--------|-------------|
| `expo-linear-gradient` | `LinearGradient` | `GradientView` from `@/components/GradientView` (CSS on web, View on native) |
| `expo-blur` | `BlurView` | `View` with `rgba(...)` backgroundColor |
| `expo-symbols` | `SymbolView` | `Feather` icons from `@expo/vector-icons` |
| `expo-glass-effect` | `isLiquidGlassAvailable` | Remove entirely |
| `expo-router/unstable-native-tabs` | `NativeTabs`, `Icon`, `Label` | Remove entirely, use standard `Tabs` |

**Why:** Expo Go includes a fixed set of native modules. Any module not in that set causes `Invariant Violation: View config getter callback for component ViewManagerAdapter_X must be a function (received undefined)` — the same error pattern for all of them.

**How to apply:**
- When writing any new component that might be used on iOS via Expo Go, always check if the module is in Expo Go's included modules list
- `@expo/vector-icons` (Feather, MaterialIcons, etc.) → safe ✓
- `expo-haptics`, `expo-clipboard`, `expo-image-picker` → safe in Expo Go ✓
- `expo-av` via dynamic `await import()` → crashes deferred, safe at load time
- All crashed modules above → unsafe, use replacements

## Expo Modules Core Node shim

The workspace's Node 24 compatibility postinstall creates a minimal `expo-modules-core/build/index.js` shim for Node tooling. Metro must resolve `expo-modules-core` to its real `src/index.ts` instead; bundling the shim replaces native module accessors with no-op functions and can crash the Android app at startup.

**Why:** The Android development bundle contained the shim's empty `requireNativeModule` implementation, while Expo packages such as clipboard and image picker need the real native bridge.

**How to apply:** Keep Metro's targeted resolver for `expo-modules-core` when this workspace shim is present. Verify exported JS bundles do not contain the stub before treating a native startup issue as fixed.

**GradientView location:** `artifacts/sankofa-translate/components/GradientView.tsx`
- Web: uses expo-linear-gradient (CSS)
- Native: uses View with `backgroundColor: colors[0]`
