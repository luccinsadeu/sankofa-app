---
name: Sankofa auth return values
description: Why signup/login must return result objects and the stale closure trap
---

## Rule
`signup()` and `login()` in AppContext must return `{success, user?, error?}`. Callers must use the return value directly — never read `user` from React state immediately after an async auth call.

**Why:** React state updates (`setUserState`) are batched and don't take effect within the same synchronous closure. Reading `const currentUser = user` after `await signup()` gives the pre-signup null value even with a `setTimeout` delay.

## Correct pattern (welcome.tsx)
```typescript
const result = await signup(name, email);
if (result.success && result.user) {
  setUser({ ...result.user, avatar });
  router.replace("/(tabs)");
} else {
  setError(result.error || "Erreur");
}
```

## Wrong pattern (was breaking auth)
```typescript
await signup(name, email);
await new Promise(r => setTimeout(r, 500));
const currentUser = user;  // ← always null! stale closure
if (currentUser) { ... }
```
